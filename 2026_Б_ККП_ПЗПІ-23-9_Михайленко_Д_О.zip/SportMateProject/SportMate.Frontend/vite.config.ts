import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // Порт узгоджено з Cors:AllowedOrigins у appsettings.json backend
    // (там дозволено http://localhost:3000, а не стандартний порт Vite 5173).
    port: 3000,
    strictPort: true,
  },
});
