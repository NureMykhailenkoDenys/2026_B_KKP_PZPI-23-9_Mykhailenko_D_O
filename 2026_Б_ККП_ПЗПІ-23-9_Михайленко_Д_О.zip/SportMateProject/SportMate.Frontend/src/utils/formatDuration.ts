function getMinutesWord(minutes: number): string {
  const mod10 = minutes % 10;
  const mod100 = minutes % 100;

  if (mod10 === 1 && mod100 !== 11) {
    return "хвилина";
  }
  if (mod10 >= 2 && mod10 <= 4 && !(mod100 >= 12 && mod100 <= 14)) {
    return "хвилини";
  }
  return "хвилин";
}

export function formatDurationMinutes(minutes: number): string {
  return `${minutes} ${getMinutesWord(minutes)}`;
}
