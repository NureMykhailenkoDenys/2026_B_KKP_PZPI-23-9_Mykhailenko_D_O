export const MIN_AVATAR_ID = 1;
export const MAX_AVATAR_ID = 10;

export const AVATAR_IDS: number[] = Array.from(
  { length: MAX_AVATAR_ID - MIN_AVATAR_ID + 1 },
  (_, index) => MIN_AVATAR_ID + index,
);

function isValidAvatarId(avatarId: number): boolean {
  return (
    Number.isInteger(avatarId) &&
    avatarId >= MIN_AVATAR_ID &&
    avatarId <= MAX_AVATAR_ID
  );
}

export function getAvatarImagePath(
  avatarId: number | null | undefined,
): string | null {
  if (avatarId == null || !isValidAvatarId(avatarId)) {
    return null;
  }

  return `/images/avatars/avatar-${avatarId}.png`;
}
