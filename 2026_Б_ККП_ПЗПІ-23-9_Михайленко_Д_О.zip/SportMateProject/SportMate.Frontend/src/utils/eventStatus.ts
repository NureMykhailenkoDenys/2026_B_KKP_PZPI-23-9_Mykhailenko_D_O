import { EventStatus } from "../api/eventsApi";

const STATUS_LABELS: Record<EventStatus, string> = {
  [EventStatus.Planned]: "Заплановано",
  [EventStatus.Active]: "Активно",
  [EventStatus.Completed]: "Завершено",
  [EventStatus.Cancelled]: "Скасовано",
};

const STATUS_COLORS: Record<EventStatus, string> = {
  [EventStatus.Planned]: "var(--color-warning)",
  [EventStatus.Active]: "var(--color-success)",
  [EventStatus.Completed]: "var(--color-text-secondary)",
  [EventStatus.Cancelled]: "var(--color-danger)",
};

export function getEventStatusLabel(status: EventStatus): string {
  return STATUS_LABELS[status] ?? "Невідомий статус";
}

export function getEventStatusColor(status: EventStatus): string {
  return STATUS_COLORS[status] ?? "var(--color-text-secondary)";
}
