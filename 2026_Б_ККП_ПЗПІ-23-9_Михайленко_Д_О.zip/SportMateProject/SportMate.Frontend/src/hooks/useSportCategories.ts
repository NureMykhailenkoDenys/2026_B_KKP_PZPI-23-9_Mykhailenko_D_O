import { useEffect, useState } from "react";
import {
  getSportCategories,
  type SportCategoryResponse,
} from "../api/sportCategoriesApi";

type SportCategoriesState = "loading" | "success" | "error";

export function useSportCategories() {
  const [categories, setCategories] = useState<SportCategoryResponse[]>([]);
  const [state, setState] = useState<SportCategoriesState>("loading");

  useEffect(() => {
    let cancelled = false;

    getSportCategories()
      .then((data) => {
        if (!cancelled) {
          setCategories(data);
          setState("success");
        }
      })
      .catch(() => {
        if (!cancelled) {
          setState("error");
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return { categories, state };
}
