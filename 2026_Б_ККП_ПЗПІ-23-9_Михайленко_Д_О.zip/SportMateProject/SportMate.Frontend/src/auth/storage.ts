export type UserRole = "User" | "Administrator";

export interface StoredAuth {
  accessToken: string;
  userId: number;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  avatarId: number | null;
  rating: number;
}

const STORAGE_KEY = "sportmate.auth";

export function loadAuth(): StoredAuth | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return null;
    }
    return JSON.parse(raw) as StoredAuth;
  } catch {
    return null;
  }
}

export function saveAuth(auth: StoredAuth): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(auth));
  } catch {
  }
}

export function clearAuth(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
  }
}
