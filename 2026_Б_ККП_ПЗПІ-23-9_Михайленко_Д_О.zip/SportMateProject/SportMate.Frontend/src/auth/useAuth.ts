import { useContext } from "react";
import { AuthContext, type AuthContextValue } from "./context";

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth повинен використовуватись всередині AuthProvider.");
  }
  return context;
}
