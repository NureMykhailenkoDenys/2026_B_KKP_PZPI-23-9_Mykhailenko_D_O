import { useCallback, useMemo, useState, type ReactNode } from "react";
import {
  login as loginRequest,
  register as registerRequest,
  type AuthResponse,
  type RegisterRequest,
} from "../api/authApi";
import { AuthContext, type AuthContextValue } from "./context";
import { clearAuth, loadAuth, saveAuth, type StoredAuth } from "./storage";

function toStoredAuth(response: AuthResponse): StoredAuth {
  return {
    accessToken: response.accessToken,
    userId: response.userId,
    email: response.email,
    firstName: response.firstName,
    lastName: response.lastName,
    role: response.role,
    avatarId: response.avatarId,
    rating: response.rating,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<StoredAuth | null>(() => loadAuth());

  const login = useCallback(async (email: string, password: string) => {
    const response = await loginRequest({ email, password });
    const auth = toStoredAuth(response);
    saveAuth(auth);
    setUser(auth);
    return auth;
  }, []);

  const register = useCallback(async (data: RegisterRequest) => {
    const response = await registerRequest(data);
    const auth = toStoredAuth(response);
    saveAuth(auth);
    setUser(auth);
  }, []);

  const logout = useCallback(() => {
    clearAuth();
    setUser(null);
  }, []);

  const updateUserProfile = useCallback(
    (updates: Pick<StoredAuth, "firstName" | "lastName" | "avatarId">) => {
      setUser((prev) => {
        if (!prev) {
          return prev;
        }
        const next: StoredAuth = { ...prev, ...updates };
        saveAuth(next);
        return next;
      });
    },
    [],
  );

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isAuthenticated: user !== null,
      isAdministrator: user?.role === "Administrator",
      login,
      register,
      logout,
      updateUserProfile,
    }),
    [user, login, register, logout, updateUserProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
