import { createContext } from "react";
import type { RegisterRequest } from "../api/authApi";
import type { StoredAuth } from "./storage";

export interface AuthContextValue {
  user: StoredAuth | null;
  isAuthenticated: boolean;
  isAdministrator: boolean;
  login: (email: string, password: string) => Promise<StoredAuth>;
  register: (data: RegisterRequest) => Promise<void>;
  logout: () => void;
  updateUserProfile: (
    updates: Pick<StoredAuth, "firstName" | "lastName" | "avatarId">,
  ) => void;
}

export const AuthContext = createContext<AuthContextValue | null>(null);
