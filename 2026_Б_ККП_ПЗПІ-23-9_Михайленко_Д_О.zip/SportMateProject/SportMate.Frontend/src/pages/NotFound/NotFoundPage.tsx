import { Link } from "react-router-dom";
import styles from "./NotFoundPage.module.css";

export function NotFoundPage() {
  return (
    <section className={styles.wrapper}>
      <p className={styles.code}>404</p>
      <p className={styles.message}>Сторінку не знайдено.</p>
      <Link to="/" className={styles.link}>
        На головну
      </Link>
    </section>
  );
}
