import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { getLoginErrorMessage } from "../../api/authApi";
import { useAuth } from "../../auth/useAuth";
import { isValidEmail } from "../../utils/validation";
import styles from "./LoginPage.module.css";

interface FieldErrors {
  email?: string;
  password?: string;
}

export function LoginPage() {
  const { isAuthenticated, isAdministrator, login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (isAuthenticated) {
    return <Navigate to={isAdministrator ? "/admin/users" : "/"} replace />;
  }

  function validate(): boolean {
    const errors: FieldErrors = {};
    const trimmedEmail = email.trim();

    if (!trimmedEmail) {
      errors.email = "Введіть електронну пошту.";
    } else if (!isValidEmail(trimmedEmail)) {
      errors.email = "Некоректний формат електронної пошти.";
    }

    if (!password) {
      errors.password = "Введіть пароль.";
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }

    setFormError(null);

    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    try {
      const auth = await login(email.trim(), password);
      navigate(auth.role === "Administrator" ? "/admin/users" : "/", {
        replace: true,
      });
    } catch (error) {
      setFormError(getLoginErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section className={styles.wrapper}>
      <form className={styles.card} onSubmit={handleSubmit} noValidate>
        <h1 className={styles.title}>Вхід</h1>

        <label className={styles.field}>
          <span className={styles.label}>Електронна пошта</span>
          <input
            type="email"
            className={
              fieldErrors.email
                ? `${styles.input} ${styles.inputError}`
                : styles.input
            }
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            disabled={isSubmitting}
            autoComplete="email"
          />
          {fieldErrors.email && (
            <span className={styles.fieldError}>{fieldErrors.email}</span>
          )}
        </label>

        <label className={styles.field}>
          <span className={styles.label}>Пароль</span>
          <input
            type="password"
            className={
              fieldErrors.password
                ? `${styles.input} ${styles.inputError}`
                : styles.input
            }
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            disabled={isSubmitting}
            autoComplete="current-password"
          />
          {fieldErrors.password && (
            <span className={styles.fieldError}>{fieldErrors.password}</span>
          )}
        </label>

        {formError && <p className={styles.formError}>{formError}</p>}

        <button type="submit" className={styles.submit} disabled={isSubmitting}>
          {isSubmitting ? "Вхід..." : "Увійти"}
        </button>

        <p className={styles.footer}>
          Немає акаунту? <Link to="/register">Зареєструватися</Link>
        </p>
      </form>
    </section>
  );
}
