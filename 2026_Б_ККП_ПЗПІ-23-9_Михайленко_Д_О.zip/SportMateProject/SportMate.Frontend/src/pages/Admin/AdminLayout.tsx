import { NavLink, Outlet } from "react-router-dom";
import styles from "./AdminLayout.module.css";

export function AdminLayout() {
  return (
    <section>
      <header className={styles.header}>
        <h1 className={styles.title}>Адмін-панель</h1>
      </header>

      <nav className={styles.tabs}>
        <NavLink
          to="/admin/users"
          className={({ isActive }) =>
            isActive ? `${styles.tab} ${styles.tabActive}` : styles.tab
          }
        >
          Користувачі
        </NavLink>
        <NavLink
          to="/admin/events"
          className={({ isActive }) =>
            isActive ? `${styles.tab} ${styles.tabActive}` : styles.tab
          }
        >
          Події
        </NavLink>
      </nav>

      <div className={styles.content}>
        <Outlet />
      </div>
    </section>
  );
}
