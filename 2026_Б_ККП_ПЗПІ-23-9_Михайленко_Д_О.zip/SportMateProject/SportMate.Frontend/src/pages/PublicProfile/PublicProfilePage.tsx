import { useEffect, useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { ApiError } from "../../api/client";
import {
  getPublicProfileErrorMessage,
  getPublicUserProfile,
  type PublicUserProfileResponse,
} from "../../api/usersApi";
import { useAuth } from "../../auth/useAuth";
import { EventCard } from "../../components/EventCard/EventCard";
import { ProfileReviews } from "../../components/ProfileReviews/ProfileReviews";
import { getAvatarImagePath } from "../../utils/avatars";
import { getInitials } from "../../utils/initials";
import styles from "./PublicProfilePage.module.css";

type ProfileLoadState = "loading" | "success" | "notFound" | "error";

const VALID_ID_PATTERN = /^\d+$/;

export function PublicProfilePage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();

  const isValidId = id !== undefined && VALID_ID_PATTERN.test(id);
  const numericId = isValidId ? Number(id) : null;

  const [profile, setProfile] = useState<PublicUserProfileResponse | null>(
    null,
  );
  const [profileState, setProfileState] = useState<ProfileLoadState>(() =>
    isValidId ? "loading" : "notFound",
  );
  const [profileError, setProfileError] = useState<string | null>(null);

  useEffect(() => {
    if (numericId === null) {
      return;
    }

    const validId = numericId;
    const controller = new AbortController();

    async function loadProfile() {
      try {
        const data = await getPublicUserProfile(validId, {
          signal: controller.signal,
        });
        setProfile(data);
        setProfileState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        if (error instanceof ApiError && error.status === 404) {
          setProfileState("notFound");
        } else {
          setProfileError(getPublicProfileErrorMessage(error));
          setProfileState("error");
        }
      }
    }

    void loadProfile();

    return () => {
      controller.abort();
    };
  }, [numericId]);

  if (numericId !== null && user !== null && user.userId === numericId) {
    return <Navigate to="/profile" replace />;
  }

  const avatarPath = profile ? getAvatarImagePath(profile.avatarId) : null;

  return (
    <section>
      <Link to="/" className={styles.backLink}>
        ← Назад до подій
      </Link>

      {profileState === "loading" && (
        <p className={styles.status}>Завантаження профілю...</p>
      )}

      {profileState === "notFound" && (
        <div className={styles.notFound}>
          <p className={styles.notFoundTitle}>Користувача не знайдено.</p>
          <Link to="/" className={styles.notFoundLink}>
            Повернутися до всіх подій
          </Link>
        </div>
      )}

      {profileState === "error" && (
        <p className={styles.statusError}>
          {profileError ?? "Не вдалося завантажити профіль користувача."}
        </p>
      )}

      {profileState === "success" && profile && (
        <>
          <div className={styles.summaryCard}>
            <div className={styles.summaryLeft}>
              {avatarPath ? (
                <img src={avatarPath} alt="" className={styles.avatar} />
              ) : (
                <span className={styles.avatarFallback}>
                  {getInitials(profile.firstName, profile.lastName)}
                </span>
              )}

              <div>
                <p className={styles.name}>
                  {profile.firstName} {profile.lastName}
                </p>
                <p className={styles.rating}>★ {profile.rating.toFixed(1)}</p>
              </div>
            </div>

            <div className={styles.summaryRight}>
              <ProfileReviews userId={profile.userId} />
            </div>
          </div>

          <div className={styles.section}>
            <h2 className={styles.sectionTitle}>Створені події</h2>
            {profile.organizedEvents.length === 0 ? (
              <p className={styles.sectionEmpty}>
                Користувач ще не створював подій.
              </p>
            ) : (
              <div className={styles.grid}>
                {profile.organizedEvents.map((event) => (
                  <EventCard key={event.eventId} event={event} />
                ))}
              </div>
            )}
          </div>

          <div className={styles.section}>
            <h2 className={styles.sectionTitle}>
              Події, у яких бере участь
            </h2>
            {profile.participatingEvents.length === 0 ? (
              <p className={styles.sectionEmpty}>
                Користувач ще не бере участі в подіях.
              </p>
            ) : (
              <div className={styles.grid}>
                {profile.participatingEvents.map((event) => (
                  <EventCard key={event.eventId} event={event} />
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </section>
  );
}
