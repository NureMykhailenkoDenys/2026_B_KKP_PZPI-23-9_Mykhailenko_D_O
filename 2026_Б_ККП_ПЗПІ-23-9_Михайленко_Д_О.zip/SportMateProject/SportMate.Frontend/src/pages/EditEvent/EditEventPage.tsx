import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ApiError } from "../../api/client";
import {
  EventStatus,
  getEventById,
  getUpdateEventErrorMessage,
  updateEvent,
  type EventResponse,
} from "../../api/eventsApi";
import { useAuth } from "../../auth/useAuth";
import { LocationPicker } from "../../components/LocationPicker/LocationPicker";
import { useSportCategories } from "../../hooks/useSportCategories";
import { buildEventDateIso, splitEventDateIso } from "../../utils/formatDate";
import styles from "../CreateEvent/CreateEventPage.module.css";

type PageLoadState = "loading" | "success" | "notFound" | "error";

const MAX_TITLE_LENGTH = 200;
const MAX_DESCRIPTION_LENGTH = 2000;
const MAX_ADDRESS_LENGTH = 500;

interface FieldErrors {
  title?: string;
  description?: string;
  sportCategoryId?: string;
  date?: string;
  time?: string;
  durationMinutes?: string;
  maxParticipants?: string;
  address?: string;
  location?: string;
}

const VALID_ID_PATTERN = /^\d+$/;

export function EditEventPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();

  const isValidId = id !== undefined && VALID_ID_PATTERN.test(id);
  const numericId = isValidId ? Number(id) : null;

  const [event, setEvent] = useState<EventResponse | null>(null);
  const [pageState, setPageState] = useState<PageLoadState>(() =>
    isValidId ? "loading" : "notFound",
  );

  useEffect(() => {
    if (numericId === null) {
      return;
    }

    const validId = numericId;
    const controller = new AbortController();

    async function load() {
      try {
        const data = await getEventById(validId, { signal: controller.signal });
        setEvent(data);
        setPageState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        if (error instanceof ApiError && error.status === 404) {
          setPageState("notFound");
        } else {
          setPageState("error");
        }
      }
    }

    void load();

    return () => {
      controller.abort();
    };
  }, [numericId]);

  if (pageState === "loading") {
    return (
      <section className={styles.wrapper}>
        <p className={styles.hint}>Завантаження події...</p>
      </section>
    );
  }

  if (pageState === "notFound") {
    return (
      <section className={styles.wrapper}>
        <p className={styles.formError}>Подію не знайдено.</p>
        <Link to="/" className={styles.backLink}>
          ← Назад до подій
        </Link>
      </section>
    );
  }

  if (pageState === "error") {
    return (
      <section className={styles.wrapper}>
        <p className={styles.formError}>Не вдалося завантажити подію.</p>
        <Link to="/" className={styles.backLink}>
          ← Назад до подій
        </Link>
      </section>
    );
  }

  const loadedEvent = event as EventResponse;
  const isOrganizer =
    user !== null && loadedEvent.organizer.userId === user.userId;

  if (!isOrganizer) {
    return (
      <section className={styles.wrapper}>
        <p className={styles.formError}>
          У вас немає дозволу редагувати цю подію.
        </p>
        <Link to={`/events/${loadedEvent.eventId}`} className={styles.backLink}>
          ← Назад до сторінки події
        </Link>
      </section>
    );
  }

  if (
    loadedEvent.status === EventStatus.Completed ||
    loadedEvent.status === EventStatus.Cancelled
  ) {
    return (
      <section className={styles.wrapper}>
        <p className={styles.formError}>
          {loadedEvent.status === EventStatus.Completed
            ? "Подію вже завершено — редагування недоступне."
            : "Подію скасовано — редагування недоступне."}
        </p>
        <Link to={`/events/${loadedEvent.eventId}`} className={styles.backLink}>
          ← Назад до сторінки події
        </Link>
      </section>
    );
  }

  return <EditEventForm key={loadedEvent.eventId} event={loadedEvent} />;
}

interface EditEventFormProps {
  event: EventResponse;
}

function EditEventForm({ event }: EditEventFormProps) {
  const navigate = useNavigate();
  const { categories: sportCategories } = useSportCategories();

  const initialDateTime = splitEventDateIso(event.eventDate);

  const [title, setTitle] = useState(event.title);
  const [description, setDescription] = useState(event.description ?? "");
  const [sportCategoryId, setSportCategoryId] = useState(
    String(event.sportCategory.sportCategoryId),
  );
  const [date, setDate] = useState(initialDateTime.date);
  const [time, setTime] = useState(initialDateTime.time);
  const [durationMinutes, setDurationMinutes] = useState(
    String(event.durationMinutes),
  );
  const [maxParticipants, setMaxParticipants] = useState(
    String(event.maxParticipants),
  );
  const [address, setAddress] = useState(event.address);
  const [latitude, setLatitude] = useState<number | null>(event.latitude);
  const [longitude, setLongitude] = useState<number | null>(event.longitude);

  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  function handleLocationChange(lat: number, lng: number, foundAddress: string) {
    setLatitude(lat);
    setLongitude(lng);
    setAddress(foundAddress);
    setFieldErrors((prev) => ({
      ...prev,
      location: undefined,
      address: undefined,
    }));
  }

  function validate(): {
    errors: FieldErrors;
    eventDateIso: string | null;
    durationValue: number | null;
    maxParticipantsValue: number | null;
  } {
    const errors: FieldErrors = {};
    const trimmedTitle = title.trim();
    const trimmedDescription = description.trim();

    if (!trimmedTitle) {
      errors.title = "Введіть назву події.";
    } else if (trimmedTitle.length > MAX_TITLE_LENGTH) {
      errors.title = `Назва не повинна перевищувати ${MAX_TITLE_LENGTH} символів.`;
    }

    if (trimmedDescription.length > MAX_DESCRIPTION_LENGTH) {
      errors.description = `Опис не повинен перевищувати ${MAX_DESCRIPTION_LENGTH} символів.`;
    }

    if (!sportCategoryId) {
      errors.sportCategoryId = "Оберіть вид спорту.";
    }

    if (!date) {
      errors.date = "Оберіть дату.";
    }
    if (!time) {
      errors.time = "Оберіть час початку.";
    }

    const eventDateIso = date && time ? buildEventDateIso(date, time) : null;
    if (date && time) {
      if (!eventDateIso) {
        errors.date = "Некоректні дата або час.";
      } else if (new Date(eventDateIso).getTime() <= Date.now()) {
        errors.date = "Дата та час події повинні бути у майбутньому.";
      }
    }

    let durationValue: number | null = null;
    if (!durationMinutes) {
      errors.durationMinutes = "Вкажіть тривалість.";
    } else {
      durationValue = Number(durationMinutes);
      if (!Number.isInteger(durationValue) || durationValue <= 0) {
        errors.durationMinutes = "Тривалість повинна бути цілим числом більше 0.";
      }
    }

    let maxParticipantsValue: number | null = null;
    if (!maxParticipants) {
      errors.maxParticipants = "Вкажіть максимальну кількість учасників.";
    } else {
      maxParticipantsValue = Number(maxParticipants);
      if (!Number.isInteger(maxParticipantsValue) || maxParticipantsValue <= 0) {
        errors.maxParticipants = "Кількість учасників повинна бути цілим числом більше 0.";
      } else if (maxParticipantsValue < event.participantCount) {
        errors.maxParticipants = `Не можна встановити менше за поточну кількість учасників (${event.participantCount}).`;
      }
    }

    if (latitude === null || longitude === null) {
      errors.location = "Оберіть місце на карті.";
    } else if (!address.trim()) {
      errors.address =
        "Не вдалося визначити адресу для обраної точки. Спробуйте ще раз на карті.";
    }

    return {
      errors,
      eventDateIso,
      durationValue,
      maxParticipantsValue,
    };
  }

  async function handleSubmit(formEvent: FormEvent<HTMLFormElement>) {
    formEvent.preventDefault();

    if (isSubmitting) {
      return;
    }

    setFormError(null);

    const { errors, eventDateIso, durationValue, maxParticipantsValue } =
      validate();

    setFieldErrors(errors);

    if (
      Object.keys(errors).length > 0 ||
      eventDateIso === null ||
      durationValue === null ||
      maxParticipantsValue === null ||
      latitude === null ||
      longitude === null
    ) {
      return;
    }

    setIsSubmitting(true);
    try {
      await updateEvent(event.eventId, {
        title: title.trim(),
        description: description.trim() || undefined,
        sportCategoryId: Number(sportCategoryId),
        eventDate: eventDateIso,
        durationMinutes: durationValue,
        maxParticipants: maxParticipantsValue,
        address: address.trim(),
        latitude,
        longitude,
      });
      navigate(`/events/${event.eventId}`, { replace: true });
    } catch (error) {
      setFormError(getUpdateEventErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section className={styles.wrapper}>
      <Link to={`/events/${event.eventId}`} className={styles.backLink}>
        ← Назад до подій
      </Link>

      <form className={styles.card} onSubmit={handleSubmit} noValidate>
        <h1 className={styles.title}>Редагувати подію</h1>

        <label className={styles.field}>
          <span className={styles.label}>Назва події</span>
          <input
            type="text"
            className={
              fieldErrors.title
                ? `${styles.input} ${styles.inputError}`
                : styles.input
            }
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            disabled={isSubmitting}
            maxLength={MAX_TITLE_LENGTH}
          />
          {fieldErrors.title && (
            <span className={styles.fieldError}>{fieldErrors.title}</span>
          )}
        </label>

        <label className={styles.field}>
          <span className={styles.label}>Вид спорту</span>
          <select
            className={
              fieldErrors.sportCategoryId
                ? `${styles.select} ${styles.inputError}`
                : styles.select
            }
            value={sportCategoryId}
            onChange={(e) => setSportCategoryId(e.target.value)}
            disabled={isSubmitting}
          >
            <option value="">Оберіть вид спорту</option>
            {sportCategories.map((category) => (
              <option
                key={category.sportCategoryId}
                value={category.sportCategoryId}
              >
                {category.name}
              </option>
            ))}
          </select>
          {fieldErrors.sportCategoryId && (
            <span className={styles.fieldError}>
              {fieldErrors.sportCategoryId}
            </span>
          )}
        </label>

        <label className={styles.field}>
          <span className={styles.label}>Опис</span>
          <textarea
            className={
              fieldErrors.description
                ? `${styles.textarea} ${styles.inputError}`
                : styles.textarea
            }
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            disabled={isSubmitting}
            maxLength={MAX_DESCRIPTION_LENGTH}
          />
          {fieldErrors.description && (
            <span className={styles.fieldError}>
              {fieldErrors.description}
            </span>
          )}
        </label>

        <div className={styles.row}>
          <label className={styles.field}>
            <span className={styles.label}>Дата</span>
            <input
              type="date"
              className={
                fieldErrors.date
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={date}
              onChange={(e) => setDate(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.date && (
              <span className={styles.fieldError}>{fieldErrors.date}</span>
            )}
          </label>

          <label className={styles.field}>
            <span className={styles.label}>Час початку</span>
            <input
              type="time"
              className={
                fieldErrors.time
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={time}
              onChange={(e) => setTime(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.time && (
              <span className={styles.fieldError}>{fieldErrors.time}</span>
            )}
          </label>
        </div>

        <div className={styles.row}>
          <label className={styles.field}>
            <span className={styles.label}>Тривалість (хв)</span>
            <input
              type="number"
              min={1}
              step={1}
              className={
                fieldErrors.durationMinutes
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.durationMinutes && (
              <span className={styles.fieldError}>
                {fieldErrors.durationMinutes}
              </span>
            )}
          </label>

          <label className={styles.field}>
            <span className={styles.label}>Максимум учасників</span>
            <input
              type="number"
              min={1}
              step={1}
              className={
                fieldErrors.maxParticipants
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={maxParticipants}
              onChange={(e) => setMaxParticipants(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.maxParticipants && (
              <span className={styles.fieldError}>
                {fieldErrors.maxParticipants}
              </span>
            )}
          </label>
        </div>

        <div className={styles.field}>
          <span className={styles.label}>Місце проведення на карті</span>
          <LocationPicker
            latitude={latitude}
            longitude={longitude}
            onChange={handleLocationChange}
          />
          {fieldErrors.location && (
            <span className={styles.fieldError}>{fieldErrors.location}</span>
          )}
        </div>

        <label className={styles.field}>
          <span className={styles.label}>Адреса</span>
          <input
            type="text"
            className={
              fieldErrors.address
                ? `${styles.inputReadOnly} ${styles.inputError}`
                : styles.inputReadOnly
            }
            value={address}
            readOnly
            maxLength={MAX_ADDRESS_LENGTH}
          />
          <span className={styles.hint}>
            Адреса визначається автоматично за вибраною точкою на карті.
          </span>
          {fieldErrors.address && (
            <span className={styles.fieldError}>{fieldErrors.address}</span>
          )}
        </label>

        {formError && <p className={styles.formError}>{formError}</p>}

        <button type="submit" className={styles.submit} disabled={isSubmitting}>
          {isSubmitting ? "Збереження..." : "Зберегти зміни"}
        </button>
      </form>
    </section>
  );
}
