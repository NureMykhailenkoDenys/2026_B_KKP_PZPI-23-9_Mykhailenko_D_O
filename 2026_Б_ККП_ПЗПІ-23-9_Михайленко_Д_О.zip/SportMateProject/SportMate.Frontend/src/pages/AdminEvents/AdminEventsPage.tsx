import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  deleteAdminEvent,
  getAdminEvents,
  getAdminEventsErrorMessage,
  getDeleteEventErrorMessage,
  type EventAdminResponse,
} from "../../api/adminApi";
import { ConfirmDialog } from "../../components/ConfirmDialog/ConfirmDialog";
import { formatEventDateTime } from "../../utils/formatDate";
import { getEventStatusColor, getEventStatusLabel } from "../../utils/eventStatus";
import styles from "./AdminEventsPage.module.css";

type EventsLoadState = "loading" | "success" | "error";
type DeleteDialogState = "idle" | "pending";

export function AdminEventsPage() {
  const [events, setEvents] = useState<EventAdminResponse[]>([]);
  const [eventsState, setEventsState] = useState<EventsLoadState>("loading");
  const [eventsError, setEventsError] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<EventAdminResponse | null>(
    null,
  );
  const [deleteDialogState, setDeleteDialogState] =
    useState<DeleteDialogState>("idle");
  const [deleteDialogError, setDeleteDialogError] = useState<string | null>(
    null,
  );

  useEffect(() => {
    const controller = new AbortController();

    async function loadEvents() {
      try {
        const data = await getAdminEvents({ signal: controller.signal });
        setEvents(data);
        setEventsState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setEventsError(getAdminEventsErrorMessage(error));
        setEventsState("error");
      }
    }

    void loadEvents();

    return () => {
      controller.abort();
    };
  }, []);

  function handleOpenDeleteDialog(target: EventAdminResponse) {
    setDeleteDialogError(null);
    setDeleteTarget(target);
  }

  function handleCloseDeleteDialog() {
    if (deleteDialogState === "pending") {
      return;
    }
    setDeleteTarget(null);
    setDeleteDialogError(null);
  }

  async function handleConfirmDelete() {
    if (deleteTarget === null || deleteDialogState === "pending") {
      return;
    }

    const targetId = deleteTarget.eventId;
    setDeleteDialogState("pending");
    setDeleteDialogError(null);

    try {
      await deleteAdminEvent(targetId);
      setEvents((prev) => prev.filter((e) => e.eventId !== targetId));
      setDeleteTarget(null);
    } catch (error) {
      setDeleteDialogError(getDeleteEventErrorMessage(error));
    } finally {
      setDeleteDialogState("idle");
    }
  }

  return (
    <div>
      {eventsState === "loading" && (
        <p className={styles.status}>Завантаження подій...</p>
      )}

      {eventsState === "error" && (
        <p className={styles.statusError}>
          {eventsError ?? "Не вдалося завантажити події."}
        </p>
      )}

      {eventsState === "success" && events.length === 0 && (
        <p className={styles.status}>Подій не знайдено.</p>
      )}

      {eventsState === "success" && events.length > 0 && (
        <div className={styles.tableWrapper}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th className={styles.colId}>ID</th>
                <th>Назва</th>
                <th className={styles.colSport}>Вид спорту</th>
                <th>Організатор</th>
                <th className={styles.colDate}>Дата</th>
                <th className={styles.colParticipants}>Учасники</th>
                <th className={styles.colStatus}>Статус</th>
                <th className={styles.colAction}>Дія</th>
              </tr>
            </thead>
            <tbody>
              {events.map((event) => (
                <tr key={event.eventId}>
                  <td>{event.eventId}</td>
                  <td>
                    <Link
                      to={`/events/${event.eventId}`}
                      className={styles.titleLink}
                    >
                      {event.title}
                    </Link>
                  </td>
                  <td>{event.sportCategory.name}</td>
                  <td>
                    <Link
                      to={`/users/${event.organizer.userId}`}
                      className={styles.organizerLink}
                    >
                      {event.organizer.firstName} {event.organizer.lastName}
                    </Link>
                  </td>
                  <td>{formatEventDateTime(event.eventDate)}</td>
                  <td>
                    {event.participantCount} / {event.maxParticipants}
                  </td>
                  <td>
                    <span
                      className={styles.statusBadge}
                      style={{
                        backgroundColor: getEventStatusColor(event.status),
                      }}
                    >
                      {getEventStatusLabel(event.status)}
                    </span>
                  </td>
                  <td className={styles.colAction}>
                    <button
                      type="button"
                      className={styles.deleteButton}
                      onClick={() => handleOpenDeleteDialog(event)}
                    >
                      Видалити
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Видалити подію?"
          message={`«${deleteTarget.title}» буде остаточно видалено разом з учасниками, повідомленнями чату та відгуками. Цю дію не можна скасувати.`}
          confirmLabel={deleteDialogState === "pending" ? "Видалення..." : "Видалити"}
          cancelLabel="Скасувати"
          isBusy={deleteDialogState === "pending"}
          errorMessage={deleteDialogError}
          onConfirm={() => void handleConfirmDelete()}
          onCancel={handleCloseDeleteDialog}
        />
      )}
    </div>
  );
}
