import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  getCurrentUserProfile,
  getProfileErrorMessage,
  getUpdateProfileErrorMessage,
  updateCurrentUserProfile,
  type UserProfileResponse,
} from "../../api/usersApi";
import { useAuth } from "../../auth/useAuth";
import { AvatarPicker } from "../../components/AvatarPicker/AvatarPicker";
import styles from "./EditProfilePage.module.css";

type PageLoadState = "loading" | "success" | "error";

const MAX_NAME_LENGTH = 100;
const MIN_PASSWORD_LENGTH = 6;

interface FieldErrors {
  firstName?: string;
  lastName?: string;
  avatar?: string;
  password?: string;
}

export function EditProfilePage() {
  const [profile, setProfile] = useState<UserProfileResponse | null>(null);
  const [pageState, setPageState] = useState<PageLoadState>("loading");
  const [pageError, setPageError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        const data = await getCurrentUserProfile({
          signal: controller.signal,
        });
        setProfile(data);
        setPageState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setPageError(getProfileErrorMessage(error));
        setPageState("error");
      }
    }

    void load();

    return () => {
      controller.abort();
    };
  }, []);

  if (pageState === "loading") {
    return (
      <section className={styles.wrapper}>
        <p className={styles.status}>Завантаження профілю...</p>
      </section>
    );
  }

  if (pageState === "error" || !profile) {
    return (
      <section className={styles.wrapper}>
        <p className={styles.statusError}>
          {pageError ?? "Не вдалося завантажити профіль."}
        </p>
        <Link to="/profile" className={styles.backLink}>
          ← Назад до профілю
        </Link>
      </section>
    );
  }

  return <EditProfileForm profile={profile} />;
}

interface EditProfileFormProps {
  profile: UserProfileResponse;
}

function EditProfileForm({ profile }: EditProfileFormProps) {
  const navigate = useNavigate();
  const { updateUserProfile } = useAuth();

  const [firstName, setFirstName] = useState(profile.firstName);
  const [lastName, setLastName] = useState(profile.lastName);
  const [avatarId, setAvatarId] = useState<number | null>(profile.avatarId);
  const [password, setPassword] = useState("");

  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  function validate(): { errors: FieldErrors; avatarValue: number | null } {
    const errors: FieldErrors = {};
    const trimmedFirstName = firstName.trim();
    const trimmedLastName = lastName.trim();

    if (!trimmedFirstName) {
      errors.firstName = "Введіть ім'я.";
    } else if (trimmedFirstName.length > MAX_NAME_LENGTH) {
      errors.firstName = `Ім'я не повинно перевищувати ${MAX_NAME_LENGTH} символів.`;
    }

    if (!trimmedLastName) {
      errors.lastName = "Введіть прізвище.";
    } else if (trimmedLastName.length > MAX_NAME_LENGTH) {
      errors.lastName = `Прізвище не повинно перевищувати ${MAX_NAME_LENGTH} символів.`;
    }

    if (avatarId === null) {
      errors.avatar = "Оберіть аватар.";
    }

    if (password && password.length < MIN_PASSWORD_LENGTH) {
      errors.password = `Пароль повинен містити щонайменше ${MIN_PASSWORD_LENGTH} символів.`;
    }

    return { errors, avatarValue: avatarId };
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }

    setFormError(null);
    const { errors, avatarValue } = validate();
    setFieldErrors(errors);

    if (Object.keys(errors).length > 0 || avatarValue === null) {
      return;
    }

    setIsSubmitting(true);
    try {
      const trimmedPassword = password.trim();
      const updated = await updateCurrentUserProfile({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        avatarId: avatarValue,
        password: trimmedPassword || undefined,
      });

      updateUserProfile({
        firstName: updated.firstName,
        lastName: updated.lastName,
        avatarId: updated.avatarId,
      });

      navigate("/profile", { replace: true });
    } catch (error) {
      setFormError(getUpdateProfileErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleAvatarChange(id: number) {
    setAvatarId(id);
    if (fieldErrors.avatar) {
      setFieldErrors((prev) => ({ ...prev, avatar: undefined }));
    }
  }

  function handleCancel() {
    navigate("/profile");
  }

  return (
    <section className={styles.wrapper}>
      <Link to="/profile" className={styles.backLink}>
        ← Назад до профілю
      </Link>

      <form className={styles.card} onSubmit={handleSubmit} noValidate>
        <h1 className={styles.title}>Редагувати профіль</h1>

        <div className={styles.field}>
          <span className={styles.label}>Електронна пошта</span>
          <p className={styles.readonlyValue}>{profile.email}</p>
        </div>

        <div className={styles.row}>
          <label className={styles.field}>
            <span className={styles.label}>Ім'я</span>
            <input
              type="text"
              className={
                fieldErrors.firstName
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              disabled={isSubmitting}
              maxLength={MAX_NAME_LENGTH}
            />
            {fieldErrors.firstName && (
              <span className={styles.fieldError}>
                {fieldErrors.firstName}
              </span>
            )}
          </label>

          <label className={styles.field}>
            <span className={styles.label}>Прізвище</span>
            <input
              type="text"
              className={
                fieldErrors.lastName
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              disabled={isSubmitting}
              maxLength={MAX_NAME_LENGTH}
            />
            {fieldErrors.lastName && (
              <span className={styles.fieldError}>{fieldErrors.lastName}</span>
            )}
          </label>
        </div>

        <div className={styles.field}>
          <span className={styles.label}>Оберіть аватар</span>
          <AvatarPicker value={avatarId} onChange={handleAvatarChange} />
          {fieldErrors.avatar && (
            <span className={styles.fieldError}>{fieldErrors.avatar}</span>
          )}
        </div>

        <label className={styles.field}>
          <span className={styles.label}>Новий пароль</span>
          <input
            type="password"
            className={
              fieldErrors.password
                ? `${styles.input} ${styles.inputError}`
                : styles.input
            }
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={isSubmitting}
            placeholder="Залиште порожнім, щоб не змінювати"
            autoComplete="new-password"
          />
          <span className={styles.hint}>
            Залиште поле порожнім, якщо не хочете змінювати пароль.
          </span>
          {fieldErrors.password && (
            <span className={styles.fieldError}>{fieldErrors.password}</span>
          )}
        </label>

        {formError && <p className={styles.formError}>{formError}</p>}

        <div className={styles.actions}>
          <button
            type="button"
            className={styles.cancelButton}
            onClick={handleCancel}
            disabled={isSubmitting}
          >
            Скасувати
          </button>
          <button type="submit" className={styles.submit} disabled={isSubmitting}>
            {isSubmitting ? "Збереження..." : "Зберегти"}
          </button>
        </div>
      </form>
    </section>
  );
}
