import {
  HubConnectionState,
  HubConnectionBuilder,
  type HubConnection,
} from "@microsoft/signalr";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent,
} from "react";
import { Link, useParams } from "react-router-dom";
import {
  DEFAULT_CHAT_PAGE_SIZE,
  MAX_MESSAGE_LENGTH,
  getChatHistory,
  getChatHistoryErrorMessage,
  getChatHubErrorMessage,
  getChatHubUrl,
  type ChatMessageResponse,
  type SendMessageRequest,
} from "../../api/chatApi";
import { ApiError } from "../../api/client";
import { EventStatus, getEventById, type EventResponse } from "../../api/eventsApi";
import { loadAuth } from "../../auth/storage";
import { useAuth } from "../../auth/useAuth";
import { getAvatarImagePath } from "../../utils/avatars";
import { formatEventDateTime } from "../../utils/formatDate";
import { getInitials } from "../../utils/initials";
import styles from "./EventChatPage.module.css";

type MessagesLoadState = "loading" | "success" | "error";
type EventLoadState = "loading" | "success" | "error";
type ConnectionState = "connecting" | "connected" | "reconnecting" | "disconnected";
type PendingScrollAction = "none" | "toBottom" | "preserveOffset";

const VALID_ID_PATTERN = /^\d+$/;
const NEAR_BOTTOM_THRESHOLD_PX = 80;

export function EventChatPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();

  const isValidId = id !== undefined && VALID_ID_PATTERN.test(id);
  const numericId = isValidId ? Number(id) : null;

  const [event, setEvent] = useState<EventResponse | null>(null);
  const [eventState, setEventState] = useState<EventLoadState>(() =>
    isValidId ? "loading" : "error",
  );

  const [messages, setMessages] = useState<ChatMessageResponse[]>([]);
  const [messagesState, setMessagesState] = useState<MessagesLoadState>(() =>
    isValidId ? "loading" : "error",
  );
  const [messagesError, setMessagesError] = useState<string | null>(null);

  const [oldestLoadedPage, setOldestLoadedPage] = useState<number | null>(
    null,
  );
  const [isLoadingOlder, setIsLoadingOlder] = useState(false);
  const [loadOlderError, setLoadOlderError] = useState<string | null>(null);

  const [connectionState, setConnectionState] =
    useState<ConnectionState>("connecting");
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [connectionAttempt, setConnectionAttempt] = useState(0);

  const [draftMessage, setDraftMessage] = useState("");
  const [sendError, setSendError] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);

  const connectionRef = useRef<HubConnection | null>(null);
  const messageListRef = useRef<HTMLUListElement | null>(null);
  const pendingScrollActionRef = useRef<PendingScrollAction>("none");
  const previousScrollHeightRef = useRef(0);

  const isNearBottom = useCallback((): boolean => {
    const el = messageListRef.current;
    if (!el) {
      return true;
    }
    return (
      el.scrollHeight - el.scrollTop - el.clientHeight < NEAR_BOTTOM_THRESHOLD_PX
    );
  }, []);

  useEffect(() => {
    if (numericId === null) {
      return;
    }

    const validId = numericId;
    const controller = new AbortController();

    async function loadEvent() {
      try {
        const data = await getEventById(validId, { signal: controller.signal });
        setEvent(data);
        setEventState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setEventState("error");
      }
    }

    void loadEvent();

    return () => {
      controller.abort();
    };
  }, [numericId]);

  useEffect(() => {
    if (numericId === null) {
      return;
    }

    const validId = numericId;
    const controller = new AbortController();

    async function loadInitialMessages() {
      setMessagesState("loading");
      try {
        const firstPage = await getChatHistory(
          validId,
          { page: 1, pageSize: DEFAULT_CHAT_PAGE_SIZE },
          { signal: controller.signal },
        );

        if (firstPage.totalPages <= 1) {
          pendingScrollActionRef.current = "toBottom";
          setMessages(firstPage.items);
          setOldestLoadedPage(1);
          setMessagesState("success");
          return;
        }

        const lastPage = await getChatHistory(
          validId,
          { page: firstPage.totalPages, pageSize: DEFAULT_CHAT_PAGE_SIZE },
          { signal: controller.signal },
        );
        pendingScrollActionRef.current = "toBottom";
        setMessages(lastPage.items);
        setOldestLoadedPage(lastPage.page);
        setMessagesState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setMessagesError(getChatHistoryErrorMessage(error));
        setMessagesState("error");
      }
    }

    void loadInitialMessages();

    return () => {
      controller.abort();
    };
  }, [numericId]);

  useEffect(() => {
    const el = messageListRef.current;
    if (!el) {
      return;
    }
    const action = pendingScrollActionRef.current;
    pendingScrollActionRef.current = "none";

    if (action === "toBottom") {
      el.scrollTop = el.scrollHeight;
    } else if (action === "preserveOffset") {
      el.scrollTop += el.scrollHeight - previousScrollHeightRef.current;
    }
  }, [messages]);

  async function handleLoadOlderMessages() {
    if (
      numericId === null ||
      oldestLoadedPage === null ||
      oldestLoadedPage <= 1 ||
      isLoadingOlder
    ) {
      return;
    }

    setIsLoadingOlder(true);
    setLoadOlderError(null);

    try {
      const previousPage = oldestLoadedPage - 1;
      const data = await getChatHistory(numericId, {
        page: previousPage,
        pageSize: DEFAULT_CHAT_PAGE_SIZE,
      });
      previousScrollHeightRef.current = messageListRef.current?.scrollHeight ?? 0;
      pendingScrollActionRef.current = "preserveOffset";
      setMessages((prev) => [...data.items, ...prev]);
      setOldestLoadedPage(previousPage);
    } catch (error) {
      if (error instanceof ApiError) {
        setLoadOlderError(getChatHistoryErrorMessage(error));
      } else {
        setLoadOlderError("Не вдалося завантажити попередні повідомлення.");
      }
    } finally {
      setIsLoadingOlder(false);
    }
  }

  useEffect(() => {
    if (numericId === null) {
      return;
    }

    const validId = numericId;
    let isCancelled = false;

    const connection = new HubConnectionBuilder()
      .withUrl(getChatHubUrl(), {
        accessTokenFactory: () => loadAuth()?.accessToken ?? "",
      })
      .withAutomaticReconnect()
      .build();

    connectionRef.current = connection;

    connection.on("ReceiveMessage", (message: ChatMessageResponse) => {
      pendingScrollActionRef.current = isNearBottom() ? "toBottom" : "none";
      setMessages((prev) => {
        if (prev.some((m) => m.chatMessageId === message.chatMessageId)) {
          return prev;
        }
        return [...prev, message];
      });
    });

    connection.onreconnecting(() => {
      if (!isCancelled) {
        setConnectionState("reconnecting");
      }
    });

    connection.onreconnected(() => {
      void (async () => {
        try {
          await connection.invoke("JoinEventChat", validId);
          if (!isCancelled) {
            setConnectionState("connected");
            setConnectionError(null);
          }
        } catch (error) {
          if (!isCancelled) {
            setConnectionState("disconnected");
            setConnectionError(getChatHubErrorMessage(error));
          }
        }
      })();
    });

    connection.onclose(() => {
      if (!isCancelled) {
        setConnectionState("disconnected");
      }
    });

    async function connectAndJoin() {
      setConnectionState("connecting");
      setConnectionError(null);
      try {
        await connection.start();
        await connection.invoke("JoinEventChat", validId);
        if (!isCancelled) {
          setConnectionState("connected");
        }
      } catch (error) {
        if (!isCancelled) {
          setConnectionState("disconnected");
          setConnectionError(getChatHubErrorMessage(error));
        }
      }
    }

    void connectAndJoin();

    return () => {
      isCancelled = true;
      connection.off("ReceiveMessage");
      if (connection.state === HubConnectionState.Connected) {
        connection.invoke("LeaveEventChat", validId).catch(() => {});
      }
      connection.stop().catch(() => {});
      connectionRef.current = null;
    };
  }, [numericId, connectionAttempt, isNearBottom]);

  function handleRetryConnection() {
    setConnectionAttempt((n) => n + 1);
  }

  const eventStatus = event?.status;
  const isEventClosedForSending =
    eventStatus === EventStatus.Completed || eventStatus === EventStatus.Cancelled;
  const isComposerEnabled =
    connectionState === "connected" && !isEventClosedForSending;

  const sendCurrentDraft = useCallback(async () => {
    if (numericId === null || isSending || !isComposerEnabled) {
      return;
    }

    const trimmed = draftMessage.trim();
    if (trimmed.length === 0) {
      setSendError("Повідомлення не може бути порожнім.");
      return;
    }

    const connection = connectionRef.current;
    if (!connection || connection.state !== HubConnectionState.Connected) {
      setSendError("З'єднання з чатом втрачено.");
      return;
    }

    setSendError(null);
    setIsSending(true);
    try {
      const request: SendMessageRequest = { messageText: trimmed };
      await connection.invoke("SendMessage", numericId, request);
      setDraftMessage("");
    } catch (error) {
      setSendError(getChatHubErrorMessage(error));
    } finally {
      setIsSending(false);
    }
  }, [numericId, isSending, isComposerEnabled, draftMessage]);

  function handleComposerSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void sendCurrentDraft();
  }

  function handleComposerKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
      event.preventDefault();
      void sendCurrentDraft();
    }
  }

  const canLoadOlder =
    messagesState === "success" &&
    oldestLoadedPage !== null &&
    oldestLoadedPage > 1;

  return (
    <section>
      {numericId !== null && (
        <Link to={`/events/${numericId}`} className={styles.backLink}>
          ← Назад до події
        </Link>
      )}

      <header className={styles.header}>
        <h1 className={styles.title}>Чат події</h1>
        {eventState === "success" && event && (
          <p className={styles.eventTitle}>{event.title}</p>
        )}
      </header>

      <div className={styles.chatCard}>
        {canLoadOlder && (
          <div className={styles.loadOlderRow}>
            <button
              type="button"
              className={styles.loadOlderButton}
              onClick={handleLoadOlderMessages}
              disabled={isLoadingOlder}
            >
              {isLoadingOlder
                ? "Завантаження..."
                : "Завантажити попередні повідомлення"}
            </button>
            {loadOlderError && (
              <p className={styles.loadOlderError}>{loadOlderError}</p>
            )}
          </div>
        )}

        <div className={styles.messageArea}>
          {messagesState === "loading" && (
            <p className={styles.messagesPlaceholder}>
              Завантаження повідомлень...
            </p>
          )}

          {messagesState === "error" && (
            <p className={styles.messagesPlaceholderError}>
              {messagesError ?? "Не вдалося завантажити повідомлення."}
            </p>
          )}

          {messagesState === "success" && messages.length === 0 && (
            <p className={styles.messagesPlaceholder}>
              У чаті поки немає повідомлень.
            </p>
          )}

          {messagesState === "success" && messages.length > 0 && (
            <ul className={styles.messageList} ref={messageListRef}>
              {messages.map((message) => {
                const avatarPath = getAvatarImagePath(message.avatarId);
                const isOwn = user !== null && message.userId === user.userId;
                const nameParts = message.senderName.trim().split(" ");
                const senderFirstName = nameParts[0] ?? "";
                const senderLastName =
                  nameParts.length > 1 ? nameParts[nameParts.length - 1] : "";

                return (
                  <li
                    key={message.chatMessageId}
                    className={
                      isOwn
                        ? `${styles.messageRow} ${styles.messageRowOwn}`
                        : styles.messageRow
                    }
                  >
                    {avatarPath ? (
                      <img
                        src={avatarPath}
                        alt=""
                        className={styles.messageAvatar}
                      />
                    ) : (
                      <span className={styles.messageAvatarFallback}>
                        {getInitials(senderFirstName, senderLastName)}
                      </span>
                    )}

                    <div
                      className={
                        isOwn
                          ? `${styles.messageBubble} ${styles.messageBubbleOwn}`
                          : styles.messageBubble
                      }
                    >
                      <div className={styles.messageMeta}>
                        <span className={styles.senderName}>
                          {message.senderName}
                        </span>
                        <span className={styles.sentAt}>
                          {formatEventDateTime(message.sentAt)}
                        </span>
                      </div>
                      <p className={styles.messageText}>
                        {message.messageText}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className={styles.composerArea}>
          {isEventClosedForSending && (
            <p className={styles.composerNote}>
              {eventStatus === EventStatus.Completed
                ? "Подію завершено. Надсилання повідомлень недоступне."
                : "Подію скасовано. Надсилання повідомлень недоступне."}
            </p>
          )}

          {!isEventClosedForSending && connectionState === "connecting" && (
            <p className={styles.status}>Підключення до чату...</p>
          )}

          {!isEventClosedForSending && connectionState === "reconnecting" && (
            <p className={styles.connectionWarning}>
              З'єднання втрачено. Відновлення...
            </p>
          )}

          {!isEventClosedForSending && connectionState === "disconnected" && (
            <div className={styles.connectionErrorRow}>
              <p className={styles.connectionError}>
                {connectionError ?? "З'єднання з чатом втрачено."}
              </p>
              <button
                type="button"
                className={styles.retryButton}
                onClick={handleRetryConnection}
              >
                Повторити підключення
              </button>
            </div>
          )}

          <form className={styles.composer} onSubmit={handleComposerSubmit}>
            <textarea
              className={styles.composerInput}
              value={draftMessage}
              onChange={(e) => setDraftMessage(e.target.value)}
              onKeyDown={handleComposerKeyDown}
              placeholder="Напишіть повідомлення..."
              maxLength={MAX_MESSAGE_LENGTH}
              disabled={!isComposerEnabled || isSending}
              rows={2}
            />
            {sendError && <p className={styles.fieldError}>{sendError}</p>}
            <button
              type="submit"
              className={styles.sendButton}
              disabled={!isComposerEnabled || isSending}
            >
              {isSending ? "Надсилання..." : "Надіслати"}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
