import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { getRegisterErrorMessage } from "../../api/authApi";
import { useAuth } from "../../auth/useAuth";
import { AvatarPicker } from "../../components/AvatarPicker/AvatarPicker";
import { isValidEmail } from "../../utils/validation";
import styles from "./RegisterPage.module.css";

const MAX_NAME_LENGTH = 100;
const MAX_EMAIL_LENGTH = 255;
const MIN_PASSWORD_LENGTH = 6;

interface FieldErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  avatar?: string;
}

export function RegisterPage() {
  const { isAuthenticated, register } = useAuth();
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [avatarId, setAvatarId] = useState<number | null>(null);
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  function validate(): boolean {
    const errors: FieldErrors = {};
    const trimmedFirstName = firstName.trim();
    const trimmedLastName = lastName.trim();
    const trimmedEmail = email.trim();

    if (!trimmedFirstName) {
      errors.firstName = "Введіть ім'я.";
    } else if (trimmedFirstName.length > MAX_NAME_LENGTH) {
      errors.firstName = `Ім'я не повинно перевищувати ${MAX_NAME_LENGTH} символів.`;
    }

    if (!trimmedLastName) {
      errors.lastName = "Введіть прізвище.";
    } else if (trimmedLastName.length > MAX_NAME_LENGTH) {
      errors.lastName = `Прізвище не повинно перевищувати ${MAX_NAME_LENGTH} символів.`;
    }

    if (!trimmedEmail) {
      errors.email = "Введіть електронну пошту.";
    } else if (!isValidEmail(trimmedEmail)) {
      errors.email = "Некоректний формат електронної пошти.";
    } else if (trimmedEmail.length > MAX_EMAIL_LENGTH) {
      errors.email = `Електронна пошта не повинна перевищувати ${MAX_EMAIL_LENGTH} символів.`;
    }

    if (!password) {
      errors.password = "Введіть пароль.";
    } else if (password.length < MIN_PASSWORD_LENGTH) {
      errors.password = `Пароль повинен містити щонайменше ${MIN_PASSWORD_LENGTH} символів.`;
    }

    if (avatarId === null) {
      errors.avatar = "Оберіть аватар.";
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }

    setFormError(null);

    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    try {
      await register({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        password,
        avatarId,
      });
      navigate("/", { replace: true });
    } catch (error) {
      setFormError(getRegisterErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleAvatarChange(id: number) {
    setAvatarId(id);
    if (fieldErrors.avatar) {
      setFieldErrors((prev) => ({ ...prev, avatar: undefined }));
    }
  }

  return (
    <section className={styles.wrapper}>
      <form className={styles.card} onSubmit={handleSubmit} noValidate>
        <h1 className={styles.title}>Реєстрація</h1>

        <div className={styles.row}>
          <label className={styles.field}>
            <span className={styles.label}>Ім'я</span>
            <input
              type="text"
              className={
                fieldErrors.firstName
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={firstName}
              onChange={(event) => setFirstName(event.target.value)}
              disabled={isSubmitting}
              autoComplete="given-name"
              maxLength={MAX_NAME_LENGTH}
            />
            {fieldErrors.firstName && (
              <span className={styles.fieldError}>{fieldErrors.firstName}</span>
            )}
          </label>

          <label className={styles.field}>
            <span className={styles.label}>Прізвище</span>
            <input
              type="text"
              className={
                fieldErrors.lastName
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={lastName}
              onChange={(event) => setLastName(event.target.value)}
              disabled={isSubmitting}
              autoComplete="family-name"
              maxLength={MAX_NAME_LENGTH}
            />
            {fieldErrors.lastName && (
              <span className={styles.fieldError}>{fieldErrors.lastName}</span>
            )}
          </label>
        </div>

        <label className={styles.field}>
          <span className={styles.label}>Електронна пошта</span>
          <input
            type="email"
            className={
              fieldErrors.email
                ? `${styles.input} ${styles.inputError}`
                : styles.input
            }
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            disabled={isSubmitting}
            autoComplete="email"
            maxLength={MAX_EMAIL_LENGTH}
          />
          {fieldErrors.email && (
            <span className={styles.fieldError}>{fieldErrors.email}</span>
          )}
        </label>

        <label className={styles.field}>
          <span className={styles.label}>Пароль</span>
          <input
            type="password"
            className={
              fieldErrors.password
                ? `${styles.input} ${styles.inputError}`
                : styles.input
            }
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            disabled={isSubmitting}
            autoComplete="new-password"
          />
          {fieldErrors.password && (
            <span className={styles.fieldError}>{fieldErrors.password}</span>
          )}
        </label>

        <div className={styles.field}>
          <span className={styles.label}>Оберіть аватар</span>
          <AvatarPicker value={avatarId} onChange={handleAvatarChange} />
          {fieldErrors.avatar && (
            <span className={styles.fieldError}>{fieldErrors.avatar}</span>
          )}
        </div>

        {formError && <p className={styles.formError}>{formError}</p>}

        <button type="submit" className={styles.submit} disabled={isSubmitting}>
          {isSubmitting ? "Реєстрація..." : "Зареєструватися"}
        </button>

        <p className={styles.footer}>
          Вже маєте акаунт? <Link to="/login">Увійти</Link>
        </p>
      </form>
    </section>
  );
}
