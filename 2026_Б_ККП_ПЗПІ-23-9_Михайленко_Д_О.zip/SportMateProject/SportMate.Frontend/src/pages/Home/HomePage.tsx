import { useEffect, useMemo, useState } from "react";
import {
  EventStatus,
  getEvents,
  type EventListItemResponse,
  type EventsQueryParams,
} from "../../api/eventsApi";
import { EventCard } from "../../components/EventCard/EventCard";
import { EventFilters } from "../../components/EventFilters/EventFilters";
import styles from "./HomePage.module.css";

type LoadState = "loading" | "success" | "error";

const ADDRESS_DEBOUNCE_MS = 400;

export function HomePage() {
  const [sportCategoryId, setSportCategoryId] = useState("");
  const [status, setStatus] = useState("");
  const [date, setDate] = useState("");
  const [addressInput, setAddressInput] = useState("");
  const [debouncedAddress, setDebouncedAddress] = useState("");

  const [events, setEvents] = useState<EventListItemResponse[]>([]);
  const [state, setState] = useState<LoadState>("loading");

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedAddress(addressInput.trim());
    }, ADDRESS_DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [addressInput]);

  const filters = useMemo<EventsQueryParams>(() => {
    const result: EventsQueryParams = {};
    if (sportCategoryId) {
      result.sportCategoryId = Number(sportCategoryId);
    }
    if (status !== "") {
      result.status = Number(status) as EventStatus;
    }
    if (date) {
      result.date = date;
    }
    if (debouncedAddress) {
      result.address = debouncedAddress;
    }
    return result;
  }, [sportCategoryId, status, date, debouncedAddress]);

  const hasActiveFilters = Object.keys(filters).length > 0;

  useEffect(() => {
    const controller = new AbortController();
    let cancelled = false;

    async function loadEvents() {
      setState("loading");
      try {
        const data = await getEvents(filters, { signal: controller.signal });
        if (!cancelled) {
          setEvents(data);
          setState("success");
        }
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        if (!cancelled) {
          setState("error");
        }
      }
    }

    loadEvents();

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [filters]);

  function handleReset() {
    setSportCategoryId("");
    setStatus("");
    setDate("");
    setAddressInput("");
    setDebouncedAddress("");
  }

  return (
    <section>
      <header className={styles.header}>
        <h1 className={styles.title}>Спортивні події</h1>
        <p className={styles.subtitle}>
          Знайдіть подію та приєднуйтеся до активних людей поруч.
        </p>
      </header>

      <EventFilters
        sportCategoryId={sportCategoryId}
        status={status}
        date={date}
        addressInput={addressInput}
        onSportCategoryIdChange={setSportCategoryId}
        onStatusChange={setStatus}
        onDateChange={setDate}
        onAddressInputChange={setAddressInput}
        onReset={handleReset}
      />

      {state === "loading" && (
        <p className={styles.status}>Завантаження подій...</p>
      )}

      {state === "error" && (
        <p className={styles.statusError}>
          Не вдалося завантажити події. Спробуйте оновити сторінку пізніше.
        </p>
      )}

      {state === "success" && events.length === 0 && (
        <p className={styles.status}>
          {hasActiveFilters
            ? "За заданими фільтрами подій не знайдено."
            : "Подій поки немає."}
        </p>
      )}

      {state === "success" && events.length > 0 && (
        <div className={styles.grid}>
          {events.map((event) => (
            <EventCard key={event.eventId} event={event} />
          ))}
        </div>
      )}
    </section>
  );
}
