import { useEffect, useState } from "react";
import {
  blockUser,
  getAdminUsers,
  getAdminUsersErrorMessage,
  getBlockUserErrorMessage,
  getUnblockUserErrorMessage,
  unblockUser,
  type UserAdminResponse,
} from "../../api/adminApi";
import { useAuth } from "../../auth/useAuth";
import { ConfirmDialog } from "../../components/ConfirmDialog/ConfirmDialog";
import { formatEventDateTime } from "../../utils/formatDate";
import styles from "./AdminUsersPage.module.css";

type UsersLoadState = "loading" | "success" | "error";
type BlockDialogState = "idle" | "pending";

export function AdminUsersPage() {
  const { user: currentUser } = useAuth();

  const [users, setUsers] = useState<UserAdminResponse[]>([]);
  const [usersState, setUsersState] = useState<UsersLoadState>("loading");
  const [usersError, setUsersError] = useState<string | null>(null);

  const [pendingUserIds, setPendingUserIds] = useState<Set<number>>(
    () => new Set(),
  );
  const [rowErrors, setRowErrors] = useState<Map<number, string>>(
    () => new Map(),
  );

  const [blockTarget, setBlockTarget] = useState<UserAdminResponse | null>(
    null,
  );
  const [blockDialogState, setBlockDialogState] =
    useState<BlockDialogState>("idle");
  const [blockDialogError, setBlockDialogError] = useState<string | null>(
    null,
  );

  useEffect(() => {
    const controller = new AbortController();

    async function loadUsers() {
      try {
        const data = await getAdminUsers({ signal: controller.signal });
        setUsers(data);
        setUsersState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setUsersError(getAdminUsersErrorMessage(error));
        setUsersState("error");
      }
    }

    void loadUsers();

    return () => {
      controller.abort();
    };
  }, []);

  function setRowError(userId: number, message: string | null) {
    setRowErrors((prev) => {
      const next = new Map(prev);
      if (message === null) {
        next.delete(userId);
      } else {
        next.set(userId, message);
      }
      return next;
    });
  }

  function setPending(userId: number, isPending: boolean) {
    setPendingUserIds((prev) => {
      const next = new Set(prev);
      if (isPending) {
        next.add(userId);
      } else {
        next.delete(userId);
      }
      return next;
    });
  }

  function handleOpenBlockDialog(target: UserAdminResponse) {
    setBlockDialogError(null);
    setBlockTarget(target);
  }

  function handleCloseBlockDialog() {
    if (blockDialogState === "pending") {
      return;
    }
    setBlockTarget(null);
    setBlockDialogError(null);
  }

  async function handleConfirmBlock() {
    if (blockTarget === null || blockDialogState === "pending") {
      return;
    }

    const targetId = blockTarget.userId;
    setBlockDialogState("pending");
    setBlockDialogError(null);

    try {
      await blockUser(targetId);
      setUsers((prev) =>
        prev.map((u) => (u.userId === targetId ? { ...u, isBlocked: true } : u)),
      );
      setBlockTarget(null);
    } catch (error) {
      setBlockDialogError(getBlockUserErrorMessage(error));
    } finally {
      setBlockDialogState("idle");
    }
  }

  async function handleUnblock(target: UserAdminResponse) {
    if (pendingUserIds.has(target.userId)) {
      return;
    }

    setPending(target.userId, true);
    setRowError(target.userId, null);

    try {
      await unblockUser(target.userId);
      setUsers((prev) =>
        prev.map((u) =>
          u.userId === target.userId ? { ...u, isBlocked: false } : u,
        ),
      );
    } catch (error) {
      setRowError(target.userId, getUnblockUserErrorMessage(error));
    } finally {
      setPending(target.userId, false);
    }
  }

  return (
    <div>
      {usersState === "loading" && (
        <p className={styles.status}>Завантаження користувачів...</p>
      )}

      {usersState === "error" && (
        <p className={styles.statusError}>
          {usersError ?? "Не вдалося завантажити користувачів."}
        </p>
      )}

      {usersState === "success" && users.length === 0 && (
        <p className={styles.status}>Користувачів не знайдено.</p>
      )}

      {usersState === "success" && users.length > 0 && (
        <div className={styles.tableWrapper}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th className={styles.colId}>ID</th>
                <th>Ім'я</th>
                <th>Email</th>
                <th className={styles.colRole}>Роль</th>
                <th className={styles.colRating}>Рейтинг</th>
                <th className={styles.colStatus}>Статус</th>
                <th className={styles.colCreated}>Створено</th>
                <th className={styles.colAction}>Дія</th>
              </tr>
            </thead>
            <tbody>
              {users.map((rowUser) => {
                const isSelf = currentUser?.userId === rowUser.userId;
                const isPending = pendingUserIds.has(rowUser.userId);
                const rowError = rowErrors.get(rowUser.userId);

                return (
                  <tr key={rowUser.userId}>
                    <td>{rowUser.userId}</td>
                    <td>
                      {rowUser.firstName} {rowUser.lastName}
                    </td>
                    <td>{rowUser.email}</td>
                    <td>{rowUser.role}</td>
                    <td>★ {rowUser.rating.toFixed(1)}</td>
                    <td>
                      <span
                        className={
                          rowUser.isBlocked
                            ? styles.badgeBlocked
                            : styles.badgeActive
                        }
                      >
                        {rowUser.isBlocked ? "Заблокований" : "Активний"}
                      </span>
                    </td>
                    <td>{formatEventDateTime(rowUser.createdAt)}</td>
                    <td className={styles.colAction}>
                      <div className={styles.actionCell}>
                        {isSelf ? (
                          <span className={styles.selfNote}>Ваш обліковий запис</span>
                        ) : rowUser.isBlocked ? (
                          <button
                            type="button"
                            className={styles.unblockButton}
                            onClick={() => void handleUnblock(rowUser)}
                            disabled={isPending}
                          >
                            {isPending ? "Розблокування..." : "Розблокувати"}
                          </button>
                        ) : (
                          <button
                            type="button"
                            className={styles.blockButton}
                            onClick={() => handleOpenBlockDialog(rowUser)}
                            disabled={isPending}
                          >
                            Заблокувати
                          </button>
                        )}
                        {rowError && (
                          <p className={styles.rowError}>{rowError}</p>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {blockTarget && (
        <ConfirmDialog
          title="Заблокувати користувача?"
          message={`${blockTarget.firstName} ${blockTarget.lastName} · ${blockTarget.email}`}
          confirmLabel={
            blockDialogState === "pending" ? "Блокування..." : "Заблокувати"
          }
          cancelLabel="Скасувати"
          isBusy={blockDialogState === "pending"}
          errorMessage={blockDialogError}
          onConfirm={() => void handleConfirmBlock()}
          onCancel={handleCloseBlockDialog}
        />
      )}
    </div>
  );
}
