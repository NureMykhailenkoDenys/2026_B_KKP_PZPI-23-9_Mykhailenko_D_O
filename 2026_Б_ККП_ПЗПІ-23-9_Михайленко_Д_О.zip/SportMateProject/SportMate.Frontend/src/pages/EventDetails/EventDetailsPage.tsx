import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Link, useParams } from "react-router-dom";
import { ApiError } from "../../api/client";
import {
  EventStatus,
  cancelEvent,
  getCancelEventErrorMessage,
  getEventById,
  type EventResponse,
} from "../../api/eventsApi";
import {
  getEventParticipants,
  getParticipationErrorMessage,
  joinEvent,
  leaveEvent,
  type EventParticipantResponse,
} from "../../api/participationApi";
import {
  createRating,
  getCreateRatingErrorMessage,
  getEventRatings,
  type RatingResponse,
} from "../../api/ratingsApi";
import { useAuth } from "../../auth/useAuth";
import { ConfirmDialog } from "../../components/ConfirmDialog/ConfirmDialog";
import { EventMap } from "../../components/EventMap/EventMap";
import { SportCategoryImage } from "../../components/SportCategoryImage/SportCategoryImage";
import { getAvatarImagePath } from "../../utils/avatars";
import { formatDurationMinutes } from "../../utils/formatDuration";
import { formatEventDateTime } from "../../utils/formatDate";
import { getEventStatusColor, getEventStatusLabel } from "../../utils/eventStatus";
import { getInitials } from "../../utils/initials";
import styles from "./EventDetailsPage.module.css";

type EventLoadState = "loading" | "success" | "notFound" | "error";
type ParticipantsLoadState = "loading" | "success" | "error";
type JoinLeaveState = "idle" | "pending";
type CancelEventState = "idle" | "pending";
type GivenRatingsState = "idle" | "loading" | "success" | "error";

const VALID_ID_PATTERN = /^\d+$/;

type ActionMode =
  | "guest"
  | "participants-loading"
  | "participants-error"
  | "organizer"
  | "completed"
  | "cancelled"
  | "started"
  | "leave"
  | "full"
  | "join";

export function EventDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const { user, isAuthenticated } = useAuth();

  const isValidId = id !== undefined && VALID_ID_PATTERN.test(id);
  const numericId = isValidId ? Number(id) : null;

  const [event, setEvent] = useState<EventResponse | null>(null);
  const [eventState, setEventState] = useState<EventLoadState>(() =>
    isValidId ? "loading" : "notFound",
  );

  const [participants, setParticipants] = useState<EventParticipantResponse[]>(
    [],
  );
  const [participantsState, setParticipantsState] =
    useState<ParticipantsLoadState>(() => (isValidId ? "loading" : "error"));

  const [joinLeaveState, setJoinLeaveState] = useState<JoinLeaveState>("idle");
  const [joinLeaveError, setJoinLeaveError] = useState<string | null>(null);

  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false);
  const [cancelState, setCancelState] = useState<CancelEventState>("idle");
  const [cancelError, setCancelError] = useState<string | null>(null);

  const [givenRatings, setGivenRatings] = useState<RatingResponse[]>([]);
  const [givenRatingsState, setGivenRatingsState] =
    useState<GivenRatingsState>("idle");

  const [ratingModalParticipant, setRatingModalParticipant] =
    useState<EventParticipantResponse | null>(null);
  const [extraRatedIds, setExtraRatedIds] = useState<Set<number>>(
    () => new Set(),
  );

  const [pageLoadedAt] = useState(() => Date.now());

  const loadEvent = useCallback(
    async (eventId: number, signal?: AbortSignal) => {
      try {
        const data = await getEventById(eventId, { signal });
        setEvent(data);
        setEventState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        if (error instanceof ApiError && error.status === 404) {
          setEventState("notFound");
        } else {
          setEventState("error");
        }
      }
    },
    [],
  );

  const loadParticipants = useCallback(
    async (eventId: number, signal?: AbortSignal) => {
      try {
        const data = await getEventParticipants(eventId, { signal });
        setParticipants(data);
        setParticipantsState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setParticipantsState("error");
      }
    },
    [],
  );

  useEffect(() => {
    if (numericId === null) {
      return;
    }

    const validId = numericId;
    const controller = new AbortController();

    async function loadEventPage() {
      await Promise.all([
        loadEvent(validId, controller.signal),
        loadParticipants(validId, controller.signal),
      ]);
    }

    void loadEventPage();

    return () => {
      controller.abort();
    };
  }, [numericId, loadEvent, loadParticipants]);

  async function handleJoin() {
    if (numericId === null || joinLeaveState === "pending") {
      return;
    }

    setJoinLeaveState("pending");
    setJoinLeaveError(null);

    try {
      const response = await joinEvent(numericId);
      setEvent((prev) =>
        prev
          ? {
              ...prev,
              participantCount: response.participantCount,
              freeSlots: response.freeSlots,
            }
          : prev,
      );
      await loadParticipants(numericId);
    } catch (error) {
      setJoinLeaveError(getParticipationErrorMessage(error));
      await Promise.all([loadEvent(numericId), loadParticipants(numericId)]);
    } finally {
      setJoinLeaveState("idle");
    }
  }

  async function handleLeave() {
    if (numericId === null || joinLeaveState === "pending") {
      return;
    }

    setJoinLeaveState("pending");
    setJoinLeaveError(null);

    try {
      await leaveEvent(numericId);
      await Promise.all([loadEvent(numericId), loadParticipants(numericId)]);
    } catch (error) {
      setJoinLeaveError(getParticipationErrorMessage(error));
      await Promise.all([loadEvent(numericId), loadParticipants(numericId)]);
    } finally {
      setJoinLeaveState("idle");
    }
  }

  function handleOpenCancelDialog() {
    setCancelError(null);
    setIsCancelDialogOpen(true);
  }

  function handleCloseCancelDialog() {
    if (cancelState === "pending") {
      return;
    }
    setIsCancelDialogOpen(false);
    setCancelError(null);
  }

  async function handleConfirmCancel() {
    if (numericId === null || cancelState === "pending") {
      return;
    }

    setCancelState("pending");
    setCancelError(null);

    try {
      await cancelEvent(numericId);
      await loadEvent(numericId);
      setIsCancelDialogOpen(false);
    } catch (error) {
      setCancelError(getCancelEventErrorMessage(error));
    } finally {
      setCancelState("idle");
    }
  }

  const organizerAvatarPath = event
    ? getAvatarImagePath(event.organizer.avatarId)
    : null;

  const isOrganizer =
    user !== null && event !== null && event.organizer.userId === user.userId;
  const isParticipant =
    user !== null && participants.some((p) => p.userId === user.userId);
  const hasStarted = event
    ? new Date(event.eventDate).getTime() <= pageLoadedAt
    : false;
  const canModifyParticipation =
    event !== null && event.status === EventStatus.Planned && !hasStarted;
  const canManageEvent =
    event !== null &&
    event.status !== EventStatus.Completed &&
    event.status !== EventStatus.Cancelled;
  const canRateParticipants =
    isAuthenticated &&
    event !== null &&
    event.status === EventStatus.Completed &&
    isParticipant;

  useEffect(() => {
    if (!canRateParticipants || numericId === null) {
      return;
    }

    const validId = numericId;
    const controller = new AbortController();

    async function loadGivenRatings() {
      setGivenRatingsState("loading");
      try {
        const data = await getEventRatings(validId, {
          signal: controller.signal,
        });
        setGivenRatings(data);
        setGivenRatingsState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setGivenRatingsState("error");
      }
    }

    void loadGivenRatings();

    return () => {
      controller.abort();
    };
  }, [canRateParticipants, numericId]);

  function getActionMode(): ActionMode {
    if (!isAuthenticated) {
      return "guest";
    }
    if (isOrganizer) {
      return "organizer";
    }
    if (participantsState === "loading") {
      return "participants-loading";
    }
    if (participantsState === "error") {
      return "participants-error";
    }
    if (!canModifyParticipation && event) {
      if (event.status === EventStatus.Completed) {
        return "completed";
      }
      if (event.status === EventStatus.Cancelled) {
        return "cancelled";
      }
      return "started";
    }
    if (isParticipant) {
      return "leave";
    }
    if (event && event.freeSlots === 0) {
      return "full";
    }
    return "join";
  }

  const actionMode = event ? getActionMode() : "participants-loading";

  const ratedTargetUserIds =
    user && givenRatingsState === "success"
      ? new Set(
          givenRatings
            .filter((r) => r.author.userId === user.userId)
            .map((r) => r.targetUser.userId),
        )
      : new Set<number>();

  return (
    <section>
      <Link to="/" className={styles.backLink}>
        ← Назад до подій
      </Link>

      {eventState === "loading" && (
        <p className={styles.status}>Завантаження події...</p>
      )}

      {eventState === "notFound" && (
        <div className={styles.notFound}>
          <p className={styles.notFoundTitle}>Подію не знайдено.</p>
          <Link to="/" className={styles.notFoundLink}>
            Повернутися до всіх подій
          </Link>
        </div>
      )}

      {eventState === "error" && (
        <p className={styles.statusError}>Не вдалося завантажити подію.</p>
      )}

      {eventState === "success" && event && (
        <div className={styles.layout}>
          <div className={styles.main}>
            <div className={styles.heroCard}>
              <div className={styles.heroImageWrapper}>
                <SportCategoryImage
                  imagePath={event.sportCategory.imagePath}
                  name={event.sportCategory.name}
                  className={styles.heroImage}
                  fallbackClassName={styles.heroImageFallback}
                />
                <span
                  className={styles.statusBadge}
                  style={{ backgroundColor: getEventStatusColor(event.status) }}
                >
                  {getEventStatusLabel(event.status)}
                </span>
              </div>

              <div className={styles.heroBody}>
                <span className={styles.sportName}>
                  {event.sportCategory.name}
                </span>
                <h1 className={styles.title}>{event.title}</h1>

                <div className={styles.metaRow}>
                  <span className={styles.metaItem}>
                    <strong>{formatEventDateTime(event.eventDate)}</strong>
                  </span>
                  <span className={styles.metaItem}>
                    {formatDurationMinutes(event.durationMinutes)}
                  </span>
                </div>

                <div className={styles.participantsRow}>
                  <span className={styles.participants}>
                    {event.participantCount} / {event.maxParticipants} учасників
                  </span>
                  <span className={styles.freeSlots}>
                    Вільно місць: {event.freeSlots}
                  </span>
                </div>
              </div>
            </div>

            <div className={styles.section}>
              <h2 className={styles.sectionTitle}>Опис</h2>
              {event.description ? (
                <p className={styles.sectionText}>{event.description}</p>
              ) : (
                <p className={styles.sectionTextMuted}>Опис відсутній.</p>
              )}
            </div>

            <div className={styles.section}>
              <h2 className={styles.sectionTitle}>Місце проведення</h2>
              <p className={styles.sectionText}>{event.address}</p>
              <EventMap
                latitude={event.latitude}
                longitude={event.longitude}
                address={event.address}
              />
            </div>

            <div className={styles.section}>
              <h2 className={styles.sectionTitle}>Учасники</h2>

              {participantsState === "loading" && (
                <p className={styles.sectionTextMuted}>
                  Завантаження учасників...
                </p>
              )}

              {participantsState === "error" && (
                <p className={styles.sectionTextMuted}>
                  Не вдалося завантажити список учасників.
                </p>
              )}

              {participantsState === "success" && participants.length === 0 && (
                <p className={styles.sectionTextMuted}>
                  Учасників поки немає.
                </p>
              )}

              {participantsState === "success" && participants.length > 0 && (
                <ul className={styles.participantsList}>
                  {participants.map((participant) => {
                    const avatarPath = getAvatarImagePath(
                      participant.avatarId,
                    );
                    const isSelf =
                      user !== null && participant.userId === user.userId;
                    const canRateThis = canRateParticipants && !isSelf;
                    const isRatedByMe =
                      ratedTargetUserIds.has(participant.userId) ||
                      extraRatedIds.has(participant.userId);

                    return (
                      <li
                        key={participant.userId}
                        className={styles.participantRow}
                      >
                        <Link
                          to={`/users/${participant.userId}`}
                          className={styles.participantLink}
                        >
                          {avatarPath ? (
                            <img
                              src={avatarPath}
                              alt=""
                              className={styles.participantAvatar}
                            />
                          ) : (
                            <span className={styles.participantAvatarFallback}>
                              {getInitials(
                                participant.firstName,
                                participant.lastName,
                              )}
                            </span>
                          )}
                          <span className={styles.participantName}>
                            {participant.firstName} {participant.lastName}
                          </span>
                          <span className={styles.participantRating}>
                            ★ {participant.rating.toFixed(1)}
                          </span>
                        </Link>

                        {canRateThis &&
                          (isRatedByMe ? (
                            <span className={styles.ratedBadge}>Оцінено</span>
                          ) : (
                            <button
                              type="button"
                              className={styles.rateButton}
                              onClick={() =>
                                setRatingModalParticipant(participant)
                              }
                            >
                              Оцінити
                            </button>
                          ))}
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>

          <div className={styles.sidebar}>
            <div className={styles.section}>
              <h2 className={styles.sectionTitle}>Організатор</h2>
              <Link
                to={`/users/${event.organizer.userId}`}
                className={styles.organizerRow}
              >
                {organizerAvatarPath ? (
                  <img
                    src={organizerAvatarPath}
                    alt=""
                    className={styles.organizerAvatar}
                  />
                ) : (
                  <span className={styles.organizerAvatarFallback}>
                    {getInitials(
                      event.organizer.firstName,
                      event.organizer.lastName,
                    )}
                  </span>
                )}
                <div>
                  <p className={styles.organizerName}>
                    {event.organizer.firstName} {event.organizer.lastName}
                  </p>
                  <p className={styles.organizerRating}>
                    ★ {event.organizer.rating.toFixed(1)}
                  </p>
                </div>
              </Link>
            </div>

            {isAuthenticated && isParticipant && (
              <div className={styles.section}>
                <Link
                  to={`/events/${event.eventId}/chat`}
                  className={styles.chatLink}
                >
                  Чат події
                </Link>
              </div>
            )}

            <div className={styles.actionCard}>
              {actionMode === "guest" && (
                <>
                  <p className={styles.actionText}>
                    Увійдіть, щоб приєднатися до події.
                  </p>
                  <Link to="/login" className={styles.actionLoginLink}>
                    Увійти
                  </Link>
                </>
              )}

              {actionMode === "participants-loading" && (
                <p className={styles.actionText}>Перевірка участі...</p>
              )}

              {actionMode === "participants-error" && (
                <p className={styles.actionText}>
                  Не вдалося визначити статус участі.
                </p>
              )}

              {actionMode === "organizer" && (
                <>
                  <p className={styles.actionText}>
                    Ви є організатором цієї події.
                  </p>
                  {canManageEvent && (
                    <div className={styles.organizerActions}>
                      <Link
                        to={`/events/${event.eventId}/edit`}
                        className={styles.editLink}
                      >
                        Редагувати
                      </Link>
                      <button
                        type="button"
                        className={styles.cancelEventButton}
                        onClick={handleOpenCancelDialog}
                      >
                        Скасувати подію
                      </button>
                    </div>
                  )}
                </>
              )}

              {actionMode === "completed" && (
                <p className={styles.actionText}>Подія вже завершена.</p>
              )}

              {actionMode === "cancelled" && (
                <p className={styles.actionText}>Подію скасовано.</p>
              )}

              {actionMode === "started" && (
                <p className={styles.actionText}>Подія вже розпочалась.</p>
              )}

              {actionMode === "full" && (
                <p className={styles.actionText}>
                  У події немає вільних місць.
                </p>
              )}

              {actionMode === "join" && (
                <button
                  type="button"
                  className={styles.joinButton}
                  onClick={handleJoin}
                  disabled={joinLeaveState === "pending"}
                >
                  {joinLeaveState === "pending"
                    ? "Приєднання..."
                    : "Приєднатися"}
                </button>
              )}

              {actionMode === "leave" && (
                <button
                  type="button"
                  className={styles.leaveButton}
                  onClick={handleLeave}
                  disabled={joinLeaveState === "pending"}
                >
                  {joinLeaveState === "pending" ? "Вихід..." : "Вийти з події"}
                </button>
              )}

              {joinLeaveError && (
                <p className={styles.actionError}>{joinLeaveError}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {isCancelDialogOpen && (
        <ConfirmDialog
          title="Скасувати подію?"
          message="Цю дію не можна буде скасувати."
          confirmLabel={
            cancelState === "pending" ? "Скасування..." : "Скасувати подію"
          }
          cancelLabel="Назад"
          isBusy={cancelState === "pending"}
          errorMessage={cancelError}
          onConfirm={handleConfirmCancel}
          onCancel={handleCloseCancelDialog}
        />
      )}

      {ratingModalParticipant && event && (
        <RatingModal
          eventId={event.eventId}
          participant={ratingModalParticipant}
          onClose={() => setRatingModalParticipant(null)}
          onRated={() => {
            setExtraRatedIds((prev) => {
              const next = new Set(prev);
              next.add(ratingModalParticipant.userId);
              return next;
            });
            setRatingModalParticipant(null);
          }}
        />
      )}
    </section>
  );
}

const STAR_VALUES = [1, 2, 3, 4, 5];
const MAX_COMMENT_LENGTH = 1000;

interface RatingModalProps {
  eventId: number;
  participant: EventParticipantResponse;
  onRated: () => void;
  onClose: () => void;
}

function RatingModal({
  eventId,
  participant,
  onRated,
  onClose,
}: RatingModalProps) {
  const [score, setScore] = useState(0);
  const [comment, setComment] = useState("");
  const [scoreError, setScoreError] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const avatarPath = getAvatarImagePath(participant.avatarId);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, []);

  function handleClose() {
    if (isSubmitting) {
      return;
    }
    onClose();
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }

    setSubmitError(null);

    if (score === 0) {
      setScoreError("Оберіть оцінку.");
      return;
    }
    setScoreError(null);

    setIsSubmitting(true);
    try {
      await createRating({
        eventId,
        targetUserId: participant.userId,
        score,
        comment: comment.trim() || undefined,
      });
      onRated();
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        onRated();
      } else {
        setSubmitError(getCreateRatingErrorMessage(error));
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className={styles.modalOverlay} onClick={handleClose}>
      <div
        className={styles.modalCard}
        role="dialog"
        aria-modal="true"
        aria-labelledby="rating-modal-title"
        onClick={(event) => event.stopPropagation()}
      >
        <button
          type="button"
          className={styles.modalCloseButton}
          onClick={handleClose}
          disabled={isSubmitting}
          aria-label="Закрити"
        >
          ×
        </button>

        <h2 id="rating-modal-title" className={styles.modalTitle}>
          Оцінити учасника
        </h2>

        <div className={styles.modalParticipant}>
          {avatarPath ? (
            <img
              src={avatarPath}
              alt=""
              className={styles.participantAvatar}
            />
          ) : (
            <span className={styles.participantAvatarFallback}>
              {getInitials(participant.firstName, participant.lastName)}
            </span>
          )}
          <div>
            <p className={styles.participantName}>
              {participant.firstName} {participant.lastName}
            </p>
            <p className={styles.participantRating}>
              ★ {participant.rating.toFixed(1)}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className={styles.modalForm} noValidate>
          <div className={styles.starRow}>
            {STAR_VALUES.map((value) => (
              <button
                key={value}
                type="button"
                className={value <= score ? styles.starFilled : styles.star}
                onClick={() => {
                  setScore(value);
                  setScoreError(null);
                }}
                disabled={isSubmitting}
                aria-label={`Оцінка ${value} з 5`}
                aria-pressed={value <= score}
              >
                ★
              </button>
            ))}
          </div>
          {scoreError && (
            <span className={styles.fieldError}>{scoreError}</span>
          )}

          <textarea
            className={styles.commentInput}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            disabled={isSubmitting}
            maxLength={MAX_COMMENT_LENGTH}
            placeholder="Коментар (необов'язково)"
          />

          {submitError && <p className={styles.fieldError}>{submitError}</p>}

          <div className={styles.modalActions}>
            <button
              type="button"
              className={styles.cancelRatingButton}
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Скасувати
            </button>
            <button
              type="submit"
              className={styles.submitRatingButton}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Надсилання..." : "Надіслати відгук"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
