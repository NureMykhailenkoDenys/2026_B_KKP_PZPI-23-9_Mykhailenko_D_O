import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createEvent, getCreateEventErrorMessage } from "../../api/eventsApi";
import { useSportCategories } from "../../hooks/useSportCategories";
import { LocationPicker } from "../../components/LocationPicker/LocationPicker";
import { buildEventDateIso } from "../../utils/formatDate";
import styles from "./CreateEventPage.module.css";

const MAX_TITLE_LENGTH = 200;
const MAX_DESCRIPTION_LENGTH = 2000;
const MAX_ADDRESS_LENGTH = 500;

interface FieldErrors {
  title?: string;
  description?: string;
  sportCategoryId?: string;
  date?: string;
  time?: string;
  durationMinutes?: string;
  maxParticipants?: string;
  address?: string;
  location?: string;
}

export function CreateEventPage() {
  const navigate = useNavigate();
  const { categories: sportCategories } = useSportCategories();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [sportCategoryId, setSportCategoryId] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [durationMinutes, setDurationMinutes] = useState("");
  const [maxParticipants, setMaxParticipants] = useState("");
  const [address, setAddress] = useState("");
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);

  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  function handleLocationChange(lat: number, lng: number, foundAddress: string) {
    setLatitude(lat);
    setLongitude(lng);
    setAddress(foundAddress);
    setFieldErrors((prev) => ({
      ...prev,
      location: undefined,
      address: undefined,
    }));
  }

  function validate(): {
    errors: FieldErrors;
    eventDateIso: string | null;
    durationValue: number | null;
    maxParticipantsValue: number | null;
  } {
    const errors: FieldErrors = {};
    const trimmedTitle = title.trim();
    const trimmedDescription = description.trim();

    if (!trimmedTitle) {
      errors.title = "Введіть назву події.";
    } else if (trimmedTitle.length > MAX_TITLE_LENGTH) {
      errors.title = `Назва не повинна перевищувати ${MAX_TITLE_LENGTH} символів.`;
    }

    if (trimmedDescription.length > MAX_DESCRIPTION_LENGTH) {
      errors.description = `Опис не повинен перевищувати ${MAX_DESCRIPTION_LENGTH} символів.`;
    }

    if (!sportCategoryId) {
      errors.sportCategoryId = "Оберіть вид спорту.";
    }

    if (!date) {
      errors.date = "Оберіть дату.";
    }
    if (!time) {
      errors.time = "Оберіть час початку.";
    }

    const eventDateIso = date && time ? buildEventDateIso(date, time) : null;
    if (date && time) {
      if (!eventDateIso) {
        errors.date = "Некоректні дата або час.";
      } else if (new Date(eventDateIso).getTime() <= Date.now()) {
        errors.date = "Дата та час події повинні бути у майбутньому.";
      }
    }

    let durationValue: number | null = null;
    if (!durationMinutes) {
      errors.durationMinutes = "Вкажіть тривалість.";
    } else {
      durationValue = Number(durationMinutes);
      if (!Number.isInteger(durationValue) || durationValue <= 0) {
        errors.durationMinutes = "Тривалість повинна бути цілим числом більше 0.";
      }
    }

    let maxParticipantsValue: number | null = null;
    if (!maxParticipants) {
      errors.maxParticipants = "Вкажіть максимальну кількість учасників.";
    } else {
      maxParticipantsValue = Number(maxParticipants);
      if (!Number.isInteger(maxParticipantsValue) || maxParticipantsValue <= 0) {
        errors.maxParticipants = "Кількість учасників повинна бути цілим числом більше 0.";
      }
    }

    if (latitude === null || longitude === null) {
      errors.location = "Оберіть місце на карті.";
    } else if (!address.trim()) {
      errors.address =
        "Не вдалося визначити адресу для обраної точки. Спробуйте ще раз на карті.";
    }

    return {
      errors,
      eventDateIso,
      durationValue,
      maxParticipantsValue,
    };
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }

    setFormError(null);

    const { errors, eventDateIso, durationValue, maxParticipantsValue } =
      validate();

    setFieldErrors(errors);

    if (
      Object.keys(errors).length > 0 ||
      eventDateIso === null ||
      durationValue === null ||
      maxParticipantsValue === null ||
      latitude === null ||
      longitude === null
    ) {
      return;
    }

    setIsSubmitting(true);
    try {
      const createdEvent = await createEvent({
        title: title.trim(),
        description: description.trim() || undefined,
        sportCategoryId: Number(sportCategoryId),
        eventDate: eventDateIso,
        durationMinutes: durationValue,
        maxParticipants: maxParticipantsValue,
        address: address.trim(),
        latitude,
        longitude,
      });
      navigate(`/events/${createdEvent.eventId}`, { replace: true });
    } catch (error) {
      setFormError(getCreateEventErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section className={styles.wrapper}>
      <Link to="/" className={styles.backLink}>
        ← Назад до подій
      </Link>

      <form className={styles.card} onSubmit={handleSubmit} noValidate>
        <h1 className={styles.title}>Створити подію</h1>

        <label className={styles.field}>
          <span className={styles.label}>Назва події</span>
          <input
            type="text"
            className={
              fieldErrors.title
                ? `${styles.input} ${styles.inputError}`
                : styles.input
            }
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            disabled={isSubmitting}
            maxLength={MAX_TITLE_LENGTH}
          />
          {fieldErrors.title && (
            <span className={styles.fieldError}>{fieldErrors.title}</span>
          )}
        </label>

        <label className={styles.field}>
          <span className={styles.label}>Вид спорту</span>
          <select
            className={
              fieldErrors.sportCategoryId
                ? `${styles.select} ${styles.inputError}`
                : styles.select
            }
            value={sportCategoryId}
            onChange={(e) => setSportCategoryId(e.target.value)}
            disabled={isSubmitting}
          >
            <option value="">Оберіть вид спорту</option>
            {sportCategories.map((category) => (
              <option
                key={category.sportCategoryId}
                value={category.sportCategoryId}
              >
                {category.name}
              </option>
            ))}
          </select>
          {fieldErrors.sportCategoryId && (
            <span className={styles.fieldError}>
              {fieldErrors.sportCategoryId}
            </span>
          )}
        </label>

        <label className={styles.field}>
          <span className={styles.label}>Опис</span>
          <textarea
            className={
              fieldErrors.description
                ? `${styles.textarea} ${styles.inputError}`
                : styles.textarea
            }
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            disabled={isSubmitting}
            maxLength={MAX_DESCRIPTION_LENGTH}
          />
          {fieldErrors.description && (
            <span className={styles.fieldError}>
              {fieldErrors.description}
            </span>
          )}
        </label>

        <div className={styles.row}>
          <label className={styles.field}>
            <span className={styles.label}>Дата</span>
            <input
              type="date"
              className={
                fieldErrors.date
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={date}
              onChange={(e) => setDate(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.date && (
              <span className={styles.fieldError}>{fieldErrors.date}</span>
            )}
          </label>

          <label className={styles.field}>
            <span className={styles.label}>Час початку</span>
            <input
              type="time"
              className={
                fieldErrors.time
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={time}
              onChange={(e) => setTime(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.time && (
              <span className={styles.fieldError}>{fieldErrors.time}</span>
            )}
          </label>
        </div>

        <div className={styles.row}>
          <label className={styles.field}>
            <span className={styles.label}>Тривалість (хв)</span>
            <input
              type="number"
              min={1}
              step={1}
              className={
                fieldErrors.durationMinutes
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.durationMinutes && (
              <span className={styles.fieldError}>
                {fieldErrors.durationMinutes}
              </span>
            )}
          </label>

          <label className={styles.field}>
            <span className={styles.label}>Максимум учасників</span>
            <input
              type="number"
              min={1}
              step={1}
              className={
                fieldErrors.maxParticipants
                  ? `${styles.input} ${styles.inputError}`
                  : styles.input
              }
              value={maxParticipants}
              onChange={(e) => setMaxParticipants(e.target.value)}
              disabled={isSubmitting}
            />
            {fieldErrors.maxParticipants && (
              <span className={styles.fieldError}>
                {fieldErrors.maxParticipants}
              </span>
            )}
          </label>
        </div>

        <div className={styles.field}>
          <span className={styles.label}>Місце проведення на карті</span>
          <LocationPicker
            latitude={latitude}
            longitude={longitude}
            onChange={handleLocationChange}
          />
          {fieldErrors.location && (
            <span className={styles.fieldError}>{fieldErrors.location}</span>
          )}
        </div>

        <label className={styles.field}>
          <span className={styles.label}>Адреса</span>
          <input
            type="text"
            className={
              fieldErrors.address
                ? `${styles.inputReadOnly} ${styles.inputError}`
                : styles.inputReadOnly
            }
            value={address}
            readOnly
            maxLength={MAX_ADDRESS_LENGTH}
          />
          <span className={styles.hint}>
            Адреса визначається автоматично за вибраною точкою на карті.
          </span>
          {fieldErrors.address && (
            <span className={styles.fieldError}>{fieldErrors.address}</span>
          )}
        </label>

        {formError && <p className={styles.formError}>{formError}</p>}

        <button type="submit" className={styles.submit} disabled={isSubmitting}>
          {isSubmitting ? "Створення..." : "Створити подію"}
        </button>
      </form>
    </section>
  );
}
