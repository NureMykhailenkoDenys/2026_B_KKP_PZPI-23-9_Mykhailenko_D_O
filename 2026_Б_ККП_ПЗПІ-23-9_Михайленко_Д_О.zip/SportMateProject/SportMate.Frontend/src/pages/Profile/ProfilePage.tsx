import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  getCurrentUserProfile,
  getProfileErrorMessage,
  type UserProfileResponse,
} from "../../api/usersApi";
import { EventCard } from "../../components/EventCard/EventCard";
import { ProfileReviews } from "../../components/ProfileReviews/ProfileReviews";
import { getAvatarImagePath } from "../../utils/avatars";
import { getInitials } from "../../utils/initials";
import styles from "./ProfilePage.module.css";

type LoadState = "loading" | "success" | "error";

export function ProfilePage() {
  const [profile, setProfile] = useState<UserProfileResponse | null>(null);
  const [state, setState] = useState<LoadState>("loading");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    async function loadProfile() {
      try {
        const data = await getCurrentUserProfile({ signal: controller.signal });
        setProfile(data);
        setState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setErrorMessage(getProfileErrorMessage(error));
        setState("error");
      }
    }

    void loadProfile();

    return () => {
      controller.abort();
    };
  }, []);

  const avatarPath = profile ? getAvatarImagePath(profile.avatarId) : null;

  return (
    <section>
      <header className={styles.header}>
        <h1 className={styles.title}>Мій профіль</h1>
      </header>

      {state === "loading" && (
        <p className={styles.status}>Завантаження профілю...</p>
      )}

      {state === "error" && (
        <p className={styles.statusError}>
          {errorMessage ?? "Не вдалося завантажити профіль."}
        </p>
      )}

      {state === "success" && profile && (
        <>
          <div className={styles.summaryCard}>
            <div className={styles.summaryLeft}>
              {avatarPath ? (
                <img src={avatarPath} alt="" className={styles.avatar} />
              ) : (
                <span className={styles.avatarFallback}>
                  {getInitials(profile.firstName, profile.lastName)}
                </span>
              )}

              <div>
                <p className={styles.name}>
                  {profile.firstName} {profile.lastName}
                </p>
                <p className={styles.email}>{profile.email}</p>

                <div className={styles.statsRow}>
                  <span className={styles.statItem}>
                    <span className={styles.rating}>
                      ★ {profile.rating.toFixed(1)}
                    </span>
                  </span>
                  <span className={styles.statItem}>
                    <span className={styles.statLabel}>Завершені події: </span>
                    {profile.completedEventsCount}
                  </span>
                </div>

                <Link to="/profile/edit" className={styles.editLink}>
                  Редагувати профіль
                </Link>
              </div>
            </div>

            <div className={styles.summaryRight}>
              <ProfileReviews userId={profile.userId} />
            </div>
          </div>

          <div className={styles.section}>
            <h2 className={styles.sectionTitle}>Створені події</h2>
            {profile.organizedEvents.length === 0 ? (
              <p className={styles.sectionEmpty}>
                Ви ще не створювали подій.
              </p>
            ) : (
              <div className={styles.grid}>
                {profile.organizedEvents.map((event) => (
                  <EventCard key={event.eventId} event={event} />
                ))}
              </div>
            )}
          </div>

          <div className={styles.section}>
            <h2 className={styles.sectionTitle}>
              Події, у яких ви берете участь
            </h2>
            {profile.participatingEvents.length === 0 ? (
              <p className={styles.sectionEmpty}>
                Ви ще не приєдналися до жодної події.
              </p>
            ) : (
              <div className={styles.grid}>
                {profile.participatingEvents.map((event) => (
                  <EventCard key={event.eventId} event={event} />
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </section>
  );
}
