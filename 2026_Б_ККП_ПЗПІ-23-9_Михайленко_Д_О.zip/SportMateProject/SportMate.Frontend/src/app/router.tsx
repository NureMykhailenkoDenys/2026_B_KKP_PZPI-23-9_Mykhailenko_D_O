import { createBrowserRouter, Navigate } from "react-router-dom";
import { AdminRoute, ProtectedRoute } from "../auth/RouteGuards";
import { Layout } from "../components/layout/Layout";
import { AdminLayout } from "../pages/Admin/AdminLayout";
import { AdminEventsPage } from "../pages/AdminEvents/AdminEventsPage";
import { AdminUsersPage } from "../pages/AdminUsers/AdminUsersPage";
import { CreateEventPage } from "../pages/CreateEvent/CreateEventPage";
import { EditEventPage } from "../pages/EditEvent/EditEventPage";
import { EditProfilePage } from "../pages/EditProfile/EditProfilePage";
import { EventChatPage } from "../pages/EventChat/EventChatPage";
import { EventDetailsPage } from "../pages/EventDetails/EventDetailsPage";
import { HomePage } from "../pages/Home/HomePage";
import { LoginPage } from "../pages/Login/LoginPage";
import { NotFoundPage } from "../pages/NotFound/NotFoundPage";
import { ProfilePage } from "../pages/Profile/ProfilePage";
import { PublicProfilePage } from "../pages/PublicProfile/PublicProfilePage";
import { RegisterPage } from "../pages/Register/RegisterPage";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "login", element: <LoginPage /> },
      { path: "register", element: <RegisterPage /> },
      { path: "events/:id", element: <EventDetailsPage /> },
      { path: "users/:id", element: <PublicProfilePage /> },
      {
        element: <ProtectedRoute />,
        children: [
          { path: "events/create", element: <CreateEventPage /> },
          { path: "events/:id/edit", element: <EditEventPage /> },
          { path: "events/:id/chat", element: <EventChatPage /> },
          { path: "profile", element: <ProfilePage /> },
          { path: "profile/edit", element: <EditProfilePage /> },
        ],
      },
      {
        element: <AdminRoute />,
        children: [
          {
            path: "admin",
            element: <AdminLayout />,
            children: [
              { index: true, element: <Navigate to="users" replace /> },
              { path: "users", element: <AdminUsersPage /> },
              { path: "events", element: <AdminEventsPage /> },
            ],
          },
        ],
      },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);
