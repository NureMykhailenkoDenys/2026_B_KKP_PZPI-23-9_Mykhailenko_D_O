const rawApiBaseUrl = import.meta.env.VITE_API_BASE_URL;

if (!rawApiBaseUrl) {
  // eslint-disable-next-line no-console
  console.warn(
    "VITE_API_BASE_URL не задано. Створіть файл .env на основі .env.example.",
  );
}

export const API_BASE_URL = (rawApiBaseUrl ?? "http://localhost:5243").replace(
  /\/+$/,
  "",
);
