import { apiRequest, ApiError } from "./client";

export const EventStatus = {
  Planned: 0,
  Active: 1,
  Completed: 2,
  Cancelled: 3,
} as const;

export type EventStatus = (typeof EventStatus)[keyof typeof EventStatus];

export interface EventSportCategory {
  sportCategoryId: number;
  name: string;
  imagePath: string | null;
}

export interface EventListItemResponse {
  eventId: number;
  title: string;
  eventDate: string;
  durationMinutes: number;
  address: string;
  sportCategory: EventSportCategory;
  status: EventStatus;
  maxParticipants: number;
  participantCount: number;
  freeSlots: number;
}

export interface EventOrganizer {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId: number | null;
  rating: number;
}

export interface EventResponse {
  eventId: number;
  title: string;
  description: string | null;
  address: string;
  latitude: number | null;
  longitude: number | null;
  eventDate: string;
  durationMinutes: number;
  maxParticipants: number;
  status: EventStatus;
  createdAt: string;
  organizer: EventOrganizer;
  sportCategory: EventSportCategory;
  participantCount: number;
  freeSlots: number;
}

export interface EventsQueryParams {
  sportCategoryId?: number;
  status?: EventStatus;
  date?: string;
  address?: string;
}

export function getEvents(
  params: EventsQueryParams = {},
  options: { signal?: AbortSignal } = {},
): Promise<EventListItemResponse[]> {
  const query = new URLSearchParams();

  if (params.sportCategoryId !== undefined) {
    query.set("sportCategoryId", String(params.sportCategoryId));
  }
  if (params.status !== undefined) {
    query.set("status", String(params.status));
  }
  if (params.date) {
    query.set("date", params.date);
  }
  if (params.address) {
    query.set("address", params.address);
  }

  const queryString = query.toString();
  const path = queryString ? `/api/events?${queryString}` : "/api/events";

  return apiRequest<EventListItemResponse[]>(path, { signal: options.signal });
}

export function getEventById(
  id: number,
  options: { signal?: AbortSignal } = {},
): Promise<EventResponse> {
  return apiRequest<EventResponse>(`/api/events/${id}`, {
    signal: options.signal,
  });
}

export interface CreateEventRequest {
  title: string;
  description?: string;
  sportCategoryId: number;
  eventDate: string;
  durationMinutes: number;
  maxParticipants: number;
  address: string;
  latitude: number;
  longitude: number;
}

export function createEvent(request: CreateEventRequest): Promise<EventResponse> {
  return apiRequest<EventResponse>("/api/events", {
    method: "POST",
    body: JSON.stringify(request),
  });
}

export function getCreateEventErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      return "Ваш обліковий запис заблоковано.";
    }
    if (error.status === 404) {
      return "Обрану категорію спорту не знайдено. Оновіть сторінку і спробуйте ще раз.";
    }
    if (error.status === 400) {
      return "Перевірте правильність заповнення форми та спробуйте ще раз.";
    }
  }

  return "Не вдалося створити подію. Спробуйте ще раз пізніше.";
}

export interface UpdateEventRequest {
  title: string;
  description?: string;
  sportCategoryId: number;
  eventDate: string;
  durationMinutes: number;
  maxParticipants: number;
  address: string;
  latitude: number;
  longitude: number;
}

export function updateEvent(
  id: number,
  request: UpdateEventRequest,
): Promise<EventResponse> {
  return apiRequest<EventResponse>(`/api/events/${id}`, {
    method: "PUT",
    body: JSON.stringify(request),
  });
}

export function getUpdateEventErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      if (error.message.toLowerCase().includes("blocked")) {
        return "Ваш обліковий запис заблоковано.";
      }
      return "У вас немає дозволу редагувати цю подію.";
    }
    if (error.status === 404) {
      return "Подію або обрану категорію спорту не знайдено.";
    }
    if (error.status === 400) {
      return "Зміни неможливо зберегти — дані події вже застаріли. Оновіть сторінку.";
    }
  }

  return "Не вдалося зберегти зміни. Спробуйте ще раз пізніше.";
}

export function cancelEvent(id: number): Promise<void> {
  return apiRequest<void>(`/api/events/${id}`, {
    method: "DELETE",
  });
}

export function getCancelEventErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      if (error.message.toLowerCase().includes("blocked")) {
        return "Ваш обліковий запис заблоковано.";
      }
      return "У вас немає дозволу скасувати цю подію.";
    }
    if (error.status === 404) {
      return "Подію не знайдено.";
    }
    if (error.status === 400) {
      return "Подію неможливо скасувати — дані вже змінилися. Інформацію оновлено.";
    }
  }

  return "Не вдалося скасувати подію. Спробуйте ще раз пізніше.";
}
