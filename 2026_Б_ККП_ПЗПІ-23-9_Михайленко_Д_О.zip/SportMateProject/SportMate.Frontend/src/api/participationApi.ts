import { apiRequest, ApiError } from "./client";

export interface EventParticipantResponse {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId: number | null;
  rating: number;
  joinedAt: string;
}

export function getEventParticipants(
  eventId: number,
  options: { signal?: AbortSignal } = {},
): Promise<EventParticipantResponse[]> {
  return apiRequest<EventParticipantResponse[]>(
    `/api/events/${eventId}/participants`,
    { signal: options.signal },
  );
}

export interface JoinEventResponse {
  eventId: number;
  userId: number;
  participantCount: number;
  maxParticipants: number;
  freeSlots: number;
  joinedAt: string;
}

export function joinEvent(eventId: number): Promise<JoinEventResponse> {
  return apiRequest<JoinEventResponse>(`/api/events/${eventId}/join`, {
    method: "POST",
  });
}

export function leaveEvent(eventId: number): Promise<void> {
  return apiRequest<void>(`/api/events/${eventId}/leave`, {
    method: "DELETE",
  });
}

export function getParticipationErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      if (error.message.toLowerCase().includes("blocked")) {
        return "Ваш обліковий запис заблоковано.";
      }
      return "У вас немає дозволу на цю дію.";
    }
    if (error.status === 404) {
      return "Подію не знайдено.";
    }
    if (error.status === 400) {
      return "Дію неможливо виконати — дані події вже змінилися. Інформацію оновлено.";
    }
  }

  return "Сталася помилка. Спробуйте ще раз пізніше.";
}
