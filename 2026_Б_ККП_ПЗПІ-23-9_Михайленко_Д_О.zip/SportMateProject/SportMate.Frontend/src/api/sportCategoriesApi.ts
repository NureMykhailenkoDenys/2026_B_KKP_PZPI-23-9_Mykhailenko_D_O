import { apiRequest } from "./client";

export interface SportCategoryResponse {
  sportCategoryId: number;
  name: string;
  imagePath: string | null;
}

export function getSportCategories(): Promise<SportCategoryResponse[]> {
  return apiRequest<SportCategoryResponse[]>("/api/sport-categories");
}
