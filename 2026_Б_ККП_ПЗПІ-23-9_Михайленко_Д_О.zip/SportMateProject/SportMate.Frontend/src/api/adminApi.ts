import { apiRequest, ApiError } from "./client";
import type { EventStatus } from "./eventsApi";

export interface UserAdminResponse {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  avatarId: number | null;
  role: string;
  rating: number;
  isBlocked: boolean;
  createdAt: string;
}

export function getAdminUsers(
  options: { signal?: AbortSignal } = {},
): Promise<UserAdminResponse[]> {
  return apiRequest<UserAdminResponse[]>("/api/admin/users", {
    signal: options.signal,
  });
}

export function getAdminUsersErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      return "У вас немає доступу до адмін-панелі.";
    }
  }
  return "Не вдалося завантажити користувачів.";
}

export function blockUser(userId: number): Promise<void> {
  return apiRequest<void>(`/api/admin/users/${userId}/block`, {
    method: "PUT",
  });
}

export function unblockUser(userId: number): Promise<void> {
  return apiRequest<void>(`/api/admin/users/${userId}/unblock`, {
    method: "PUT",
  });
}

export function getBlockUserErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      return "У вас немає доступу до цієї дії.";
    }
    if (error.status === 404) {
      return "Користувача не знайдено.";
    }
    if (error.status === 400) {
      if (error.message.toLowerCase().includes("cannot block themselves")) {
        return "Ви не можете заблокувати самого себе.";
      }
      return "Не вдалося виконати цю дію.";
    }
  }
  return "Не вдалося заблокувати користувача. Спробуйте ще раз пізніше.";
}

export function getUnblockUserErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      return "У вас немає доступу до цієї дії.";
    }
    if (error.status === 404) {
      return "Користувача не знайдено.";
    }
  }
  return "Не вдалося розблокувати користувача. Спробуйте ще раз пізніше.";
}

export interface EventAdminOrganizerInfo {
  userId: number;
  firstName: string;
  lastName: string;
}

export interface EventAdminSportCategoryInfo {
  sportCategoryId: number;
  name: string;
}

export interface EventAdminResponse {
  eventId: number;
  title: string;
  eventDate: string;
  status: EventStatus;
  organizer: EventAdminOrganizerInfo;
  sportCategory: EventAdminSportCategoryInfo;
  participantCount: number;
  maxParticipants: number;
}

export function getAdminEvents(
  options: { signal?: AbortSignal } = {},
): Promise<EventAdminResponse[]> {
  return apiRequest<EventAdminResponse[]>("/api/admin/events", {
    signal: options.signal,
  });
}

export function getAdminEventsErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      return "У вас немає доступу до адмін-панелі.";
    }
  }
  return "Не вдалося завантажити події.";
}

export function deleteAdminEvent(eventId: number): Promise<void> {
  return apiRequest<void>(`/api/admin/events/${eventId}`, {
    method: "DELETE",
  });
}

export function getDeleteEventErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      return "У вас немає доступу до цієї дії.";
    }
    if (error.status === 404) {
      return "Подію не знайдено. Можливо, її вже видалено.";
    }
  }
  return "Не вдалося видалити подію. Спробуйте ще раз пізніше.";
}
