import { loadAuth } from "../auth/storage";
import { API_BASE_URL } from "./config";

export class ApiError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

interface BackendErrorResponse {
  message?: string;
}

async function parseErrorMessage(response: Response): Promise<string> {
  try {
    const data = (await response.clone().json()) as BackendErrorResponse;
    if (data && typeof data.message === "string" && data.message.length > 0) {
      return data.message;
    }
  } catch {
  }

  const text = await response.text().catch(() => "");
  return text || response.statusText || "Unknown error";
}

export async function apiRequest<TResponse>(
  path: string,
  options: RequestInit = {},
): Promise<TResponse> {
  const auth = loadAuth();

  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...(auth?.accessToken
      ? { Authorization: `Bearer ${auth.accessToken}` }
      : {}),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const message = await parseErrorMessage(response);
    throw new ApiError(response.status, message);
  }

  if (response.status === 204) {
    return undefined as TResponse;
  }

  return (await response.json()) as TResponse;
}
