import { apiRequest, ApiError } from "./client";
import { API_BASE_URL } from "./config";

export interface ChatMessageResponse {
  chatMessageId: number;
  eventId: number;
  userId: number;
  senderName: string;
  avatarId: number | null;
  messageText: string;
  sentAt: string;
}

export interface ChatHistoryResponse {
  items: ChatMessageResponse[];
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export const DEFAULT_CHAT_PAGE_SIZE = 50;

export function getChatHistory(
  eventId: number,
  params: { page?: number; pageSize?: number } = {},
  options: { signal?: AbortSignal } = {},
): Promise<ChatHistoryResponse> {
  const query = new URLSearchParams();
  if (params.page !== undefined) {
    query.set("page", String(params.page));
  }
  if (params.pageSize !== undefined) {
    query.set("pageSize", String(params.pageSize));
  }

  const queryString = query.toString();
  const path = queryString
    ? `/api/events/${eventId}/chat/messages?${queryString}`
    : `/api/events/${eventId}/chat/messages`;

  return apiRequest<ChatHistoryResponse>(path, { signal: options.signal });
}

export function getChatHistoryErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 403) {
      return "Чат доступний лише учасникам цієї події.";
    }
    if (error.status === 404) {
      return "Подію не знайдено.";
    }
  }
  return "Не вдалося завантажити повідомлення.";
}

export const CHAT_HUB_PATH = "/hubs/event-chat";

export function getChatHubUrl(): string {
  return `${API_BASE_URL}${CHAT_HUB_PATH}`;
}

export interface SendMessageRequest {
  messageText: string;
}

export const MAX_MESSAGE_LENGTH = 2000;

export function getChatHubErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : "";
  const lower = message.toLowerCase();

  if (lower.includes("cannot be empty")) {
    return "Повідомлення не може бути порожнім.";
  }
  if (lower.includes("cannot exceed")) {
    return `Повідомлення занадто довге (максимум ${MAX_MESSAGE_LENGTH} символів).`;
  }
  if (lower.includes("blocked")) {
    return "Ваш обліковий запис заблоковано.";
  }
  if (lower.includes("not a participant")) {
    return "Чат доступний лише учасникам цієї події.";
  }
  if (lower.includes("completed events")) {
    return "Подію завершено. Надсилання повідомлень недоступне.";
  }
  if (lower.includes("cancelled events")) {
    return "Подію скасовано. Надсилання повідомлень недоступне.";
  }
  if (lower.includes("not found")) {
    return "Подію не знайдено.";
  }
  return "Не вдалося виконати цю дію в чаті. Спробуйте ще раз.";
}
