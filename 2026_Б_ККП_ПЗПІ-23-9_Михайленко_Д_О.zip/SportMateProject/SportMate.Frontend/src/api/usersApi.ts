import { apiRequest, ApiError } from "./client";
import type { EventListItemResponse } from "./eventsApi";

export interface UserProfileResponse {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  avatarId: number | null;
  rating: number;
  role: string;
  createdAt: string;
  completedEventsCount: number;
  organizedEvents: EventListItemResponse[];
  participatingEvents: EventListItemResponse[];
}

export function getCurrentUserProfile(
  options: { signal?: AbortSignal } = {},
): Promise<UserProfileResponse> {
  return apiRequest<UserProfileResponse>("/api/users/me", {
    signal: options.signal,
  });
}

export function getProfileErrorMessage(error: unknown): string {
  if (error instanceof ApiError && error.status === 401) {
    return "Сесія закінчилася. Увійдіть знову.";
  }
  return "Не вдалося завантажити профіль.";
}

export interface UpdateProfileRequest {
  firstName: string;
  lastName: string;
  avatarId: number;
  password?: string;
}

export function updateCurrentUserProfile(
  request: UpdateProfileRequest,
): Promise<UserProfileResponse> {
  return apiRequest<UserProfileResponse>("/api/users/me", {
    method: "PUT",
    body: JSON.stringify(request),
  });
}

export function getUpdateProfileErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Сесія закінчилася. Увійдіть знову.";
    }
    if (error.status === 404) {
      return "Обліковий запис не знайдено.";
    }
    if (error.status === 400) {
      return "Перевірте правильність заповнення форми.";
    }
  }
  return "Не вдалося зберегти зміни профілю. Спробуйте ще раз пізніше.";
}

export interface PublicUserProfileResponse {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId: number | null;
  rating: number;
  organizedEvents: EventListItemResponse[];
  participatingEvents: EventListItemResponse[];
}

export function getPublicUserProfile(
  id: number,
  options: { signal?: AbortSignal } = {},
): Promise<PublicUserProfileResponse> {
  return apiRequest<PublicUserProfileResponse>(`/api/users/${id}`, {
    signal: options.signal,
  });
}

export function getPublicProfileErrorMessage(error: unknown): string {
  if (error instanceof ApiError && error.status === 404) {
    return "Користувача не знайдено.";
  }
  return "Не вдалося завантажити профіль користувача.";
}
