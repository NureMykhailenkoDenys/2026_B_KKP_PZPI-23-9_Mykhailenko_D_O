import { apiRequest, ApiError } from "./client";

export interface RatingUserInfo {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId: number | null;
  rating: number;
}

export interface RatingResponse {
  ratingId: number;
  eventId: number;
  author: RatingUserInfo;
  targetUser: RatingUserInfo;
  score: number;
  comment: string | null;
  createdAt: string;
}

export function getUserReceivedRatings(
  userId: number,
  options: { signal?: AbortSignal } = {},
): Promise<RatingResponse[]> {
  return apiRequest<RatingResponse[]>(`/api/ratings/user/${userId}`, {
    signal: options.signal,
  });
}

export function getEventRatings(
  eventId: number,
  options: { signal?: AbortSignal } = {},
): Promise<RatingResponse[]> {
  return apiRequest<RatingResponse[]>(`/api/ratings/event/${eventId}`, {
    signal: options.signal,
  });
}

export interface CreateRatingRequest {
  eventId: number;
  targetUserId: number;
  score: number;
  comment?: string;
}

export function createRating(
  request: CreateRatingRequest,
): Promise<RatingResponse> {
  return apiRequest<RatingResponse>("/api/ratings", {
    method: "POST",
    body: JSON.stringify(request),
  });
}

export function getCreateRatingErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 409) {
      return "Ви вже оцінили цього учасника.";
    }
    if (error.status === 403) {
      if (error.message.toLowerCase().includes("blocked")) {
        return "Ваш обліковий запис заблоковано.";
      }
      return "Ви не можете залишити відгук для цієї події.";
    }
    if (error.status === 404) {
      return "Подію або учасника не знайдено.";
    }
    if (error.status === 400) {
      const message = error.message.toLowerCase();
      if (message.includes("cannot rate yourself")) {
        return "Ви не можете оцінити самого себе.";
      }
      if (message.includes("event not found")) {
        return "Подію не знайдено.";
      }
      if (message.includes("user not found")) {
        return "Учасника не знайдено.";
      }
      return "Наразі неможливо залишити відгук цьому учаснику.";
    }
  }
  return "Не вдалося надіслати відгук. Спробуйте ще раз пізніше.";
}
