import type { UserRole } from "../auth/storage";
import { ApiError, apiRequest } from "./client";

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  avatarId: number | null;
}

export interface AuthResponse {
  accessToken: string;
  userId: number;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  avatarId: number | null;
  rating: number;
}

export function login(request: LoginRequest): Promise<AuthResponse> {
  return apiRequest<AuthResponse>("/api/auth/login", {
    method: "POST",
    body: JSON.stringify(request),
  });
}

export function register(request: RegisterRequest): Promise<AuthResponse> {
  return apiRequest<AuthResponse>("/api/auth/register", {
    method: "POST",
    body: JSON.stringify(request),
  });
}

export function getLoginErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return "Невірна електронна пошта або пароль.";
    }
    if (error.status === 403) {
      return "Ваш обліковий запис заблоковано.";
    }
  }

  return "Не вдалося виконати вхід. Спробуйте ще раз пізніше.";
}

export function getRegisterErrorMessage(error: unknown): string {
  if (error instanceof ApiError && error.status === 400) {
    return "Користувач з такою електронною поштою вже існує.";
  }

  return "Не вдалося зареєструватися. Спробуйте ще раз пізніше.";
}
