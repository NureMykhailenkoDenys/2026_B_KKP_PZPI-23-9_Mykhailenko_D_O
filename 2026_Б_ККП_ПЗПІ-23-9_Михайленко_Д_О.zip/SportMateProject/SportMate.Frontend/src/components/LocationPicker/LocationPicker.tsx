import { useCallback, useEffect, useRef, useState } from "react";
import { loadGoogleMaps } from "../../utils/googleMapsLoader";
import styles from "./LocationPicker.module.css";

type PickerState = "loading" | "success" | "error";
type GeocodeState = "idle" | "loading" | "success" | "error";

const DEFAULT_CENTER = { lat: 50.4501, lng: 30.5234 };

interface LocationPickerProps {
  latitude: number | null;
  longitude: number | null;
  onChange: (latitude: number, longitude: number, address: string) => void;
}

export function LocationPicker({
  latitude,
  longitude,
  onChange,
}: LocationPickerProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.Marker | null>(null);
  const geocoderRef = useRef<google.maps.Geocoder | null>(null);
  const onChangeRef = useRef(onChange);

  const geocodeRequestIdRef = useRef(0);

  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  const hasSelection = latitude !== null && longitude !== null;

  const [state, setState] = useState<PickerState>(() =>
    apiKey ? "loading" : "error",
  );
  const [geocodeState, setGeocodeState] = useState<GeocodeState>("idle");

  useEffect(() => {
    onChangeRef.current = onChange;
  }, [onChange]);

  const reverseGeocode = useCallback(async (lat: number, lng: number) => {
    const requestId = ++geocodeRequestIdRef.current;
    setGeocodeState("loading");

    if (!geocoderRef.current) {
      geocoderRef.current = new google.maps.Geocoder();
    }

    try {
      const response = await geocoderRef.current.geocode({
        location: { lat, lng },
      });

      if (requestId !== geocodeRequestIdRef.current) {
        return;
      }

      const address = response.results[0]?.formatted_address;
      if (address) {
        setGeocodeState("success");
        onChangeRef.current(lat, lng, address);
      } else {
        setGeocodeState("error");
      }
    } catch {
      if (requestId === geocodeRequestIdRef.current) {
        setGeocodeState("error");
      }
    }
  }, []);

  useEffect(() => {
    if (!apiKey || !containerRef.current) {
      return;
    }

    let cancelled = false;

    loadGoogleMaps(apiKey)
      .then(() => {
        if (cancelled || !containerRef.current) {
          return;
        }

        const hasInitialPosition = latitude !== null && longitude !== null;
        const map = new google.maps.Map(containerRef.current, {
          center: hasInitialPosition
            ? { lat: latitude, lng: longitude }
            : DEFAULT_CENTER,
          zoom: hasInitialPosition ? 13 : 6,
        });

        map.addListener("click", (event: google.maps.MapMouseEvent) => {
          if (!event.latLng) {
            return;
          }
          const lat = event.latLng.lat();
          const lng = event.latLng.lng();

          onChangeRef.current(lat, lng, "");
          void reverseGeocode(lat, lng);
        });

        mapRef.current = map;
        setState("success");
      })
      .catch(() => {
        if (!cancelled) {
          setState("error");
        }
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiKey, reverseGeocode]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) {
      return;
    }

    if (latitude === null || longitude === null) {
      markerRef.current?.setMap(null);
      markerRef.current = null;
      return;
    }

    const position = { lat: latitude, lng: longitude };

    if (markerRef.current) {
      markerRef.current.setPosition(position);
    } else {
      markerRef.current = new google.maps.Marker({ position, map });
    }
  }, [latitude, longitude]);

  function renderHint() {
    if (geocodeState === "loading") {
      return <p className={styles.status}>Визначення адреси...</p>;
    }
    if (geocodeState === "error") {
      return (
        <p className={styles.statusError}>
          Не вдалося визначити адресу для вибраної точки. Оберіть інше
          місце на карті.
        </p>
      );
    }
    return (
      <p className={hasSelection ? styles.selectedHint : styles.hint}>
        {hasSelection
          ? "Точку вибрано."
          : "Натисніть на карту, щоб обрати місце проведення."}
      </p>
    );
  }

  return (
    <div className={styles.wrapper}>
      {state === "loading" && (
        <p className={styles.status}>Завантаження карти...</p>
      )}
      {state === "error" && (
        <p className={styles.statusError}>Не вдалося завантажити карту.</p>
      )}

      <div ref={containerRef} className={styles.map} />

      {state === "success" && renderHint()}
    </div>
  );
}
