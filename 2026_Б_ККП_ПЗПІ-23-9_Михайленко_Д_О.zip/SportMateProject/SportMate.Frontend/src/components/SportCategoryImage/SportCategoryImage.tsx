import { useState } from "react";

interface SportCategoryImageProps {
  imagePath: string | null;
  name: string;
  className?: string;
  fallbackClassName?: string;
}

export function SportCategoryImage({
  imagePath,
  name,
  className,
  fallbackClassName,
}: SportCategoryImageProps) {
  const [failed, setFailed] = useState(false);
  const showImage = Boolean(imagePath) && !failed;

  if (showImage) {
    return (
      <img
        src={imagePath ?? undefined}
        alt={name}
        className={className}
        onError={() => setFailed(true)}
      />
    );
  }

  return (
    <span className={fallbackClassName} aria-hidden="true">
      {name.charAt(0).toUpperCase()}
    </span>
  );
}
