import { Link } from "react-router-dom";
import type { EventListItemResponse } from "../../api/eventsApi";
import { SportCategoryImage } from "../SportCategoryImage/SportCategoryImage";
import { formatEventDateTime } from "../../utils/formatDate";
import { getEventStatusColor, getEventStatusLabel } from "../../utils/eventStatus";
import styles from "./EventCard.module.css";

interface EventCardProps {
  event: EventListItemResponse;
}

export function EventCard({ event }: EventCardProps) {
  return (
    <Link to={`/events/${event.eventId}`} className={styles.card}>
      <div className={styles.imageWrapper}>
        <SportCategoryImage
          imagePath={event.sportCategory.imagePath}
          name={event.sportCategory.name}
          className={styles.image}
          fallbackClassName={styles.imageFallback}
        />

        <span
          className={styles.statusBadge}
          style={{ backgroundColor: getEventStatusColor(event.status) }}
        >
          {getEventStatusLabel(event.status)}
        </span>
      </div>

      <div className={styles.body}>
        <span className={styles.sportName}>{event.sportCategory.name}</span>
        <h3 className={styles.title}>{event.title}</h3>
        <p className={styles.meta}>{formatEventDateTime(event.eventDate)}</p>
        <p className={styles.meta}>{event.address}</p>

        <div className={styles.footer}>
          <span className={styles.participants}>
            {event.participantCount} / {event.maxParticipants} учасників
          </span>
          <span className={styles.freeSlots}>Вільно: {event.freeSlots}</span>
        </div>
      </div>
    </Link>
  );
}
