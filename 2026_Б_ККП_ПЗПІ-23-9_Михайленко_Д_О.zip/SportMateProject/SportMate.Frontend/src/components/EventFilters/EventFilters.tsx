import { EventStatus } from "../../api/eventsApi";
import { useSportCategories } from "../../hooks/useSportCategories";
import styles from "./EventFilters.module.css";

const STATUS_OPTIONS: { value: EventStatus; label: string }[] = [
  { value: EventStatus.Planned, label: "Заплановано" },
  { value: EventStatus.Active, label: "Активно" },
  { value: EventStatus.Completed, label: "Завершено" },
  { value: EventStatus.Cancelled, label: "Скасовано" },
];

interface EventFiltersProps {
  sportCategoryId: string;
  status: string;
  date: string;
  addressInput: string;
  onSportCategoryIdChange: (value: string) => void;
  onStatusChange: (value: string) => void;
  onDateChange: (value: string) => void;
  onAddressInputChange: (value: string) => void;
  onReset: () => void;
}

export function EventFilters({
  sportCategoryId,
  status,
  date,
  addressInput,
  onSportCategoryIdChange,
  onStatusChange,
  onDateChange,
  onAddressInputChange,
  onReset,
}: EventFiltersProps) {
  const { categories: sportCategories } = useSportCategories();

  return (
    <div className={styles.panel}>
      <label className={`${styles.field} ${styles.addressField}`}>
        <span className={styles.label}>Пошук за адресою</span>
        <input
          type="text"
          className={styles.input}
          placeholder="Наприклад, вул. Хрещатик"
          value={addressInput}
          onChange={(event) => onAddressInputChange(event.target.value)}
        />
      </label>

      <label className={styles.field}>
        <span className={styles.label}>Вид спорту</span>
        <select
          className={styles.select}
          value={sportCategoryId}
          onChange={(event) => onSportCategoryIdChange(event.target.value)}
        >
          <option value="">Усі види спорту</option>
          {sportCategories.map((category) => (
            <option
              key={category.sportCategoryId}
              value={category.sportCategoryId}
            >
              {category.name}
            </option>
          ))}
        </select>
      </label>

      <label className={styles.field}>
        <span className={styles.label}>Статус</span>
        <select
          className={styles.select}
          value={status}
          onChange={(event) => onStatusChange(event.target.value)}
        >
          <option value="">Усі статуси</option>
          {STATUS_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </label>

      <label className={styles.field}>
        <span className={styles.label}>Дата</span>
        <input
          type="date"
          className={styles.input}
          value={date}
          onChange={(event) => onDateChange(event.target.value)}
        />
      </label>

      <button type="button" className={styles.resetButton} onClick={onReset}>
        Скинути фільтри
      </button>
    </div>
  );
}
