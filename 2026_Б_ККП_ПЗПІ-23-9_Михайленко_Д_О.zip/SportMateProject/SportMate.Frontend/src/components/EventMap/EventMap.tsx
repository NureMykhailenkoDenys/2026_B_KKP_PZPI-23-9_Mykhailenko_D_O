import { useEffect, useRef, useState } from "react";
import { loadGoogleMaps } from "../../utils/googleMapsLoader";
import styles from "./EventMap.module.css";

type MapState = "loading" | "success" | "error";

interface EventMapProps {
  latitude: number | null;
  longitude: number | null;
  address?: string;
}

export function EventMap({ latitude, longitude, address }: EventMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [state, setState] = useState<MapState>("loading");

  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  const hasCoordinates = latitude !== null && longitude !== null;

  useEffect(() => {
    if (!hasCoordinates || !apiKey || !containerRef.current) {
      return;
    }

    let cancelled = false;
    setState("loading");

    loadGoogleMaps(apiKey)
      .then(() => {
        if (cancelled || !containerRef.current) {
          return;
        }

        const position = { lat: latitude, lng: longitude };
        const map = new google.maps.Map(containerRef.current, {
          center: position,
          zoom: 15,
        });

        new google.maps.Marker({
          position,
          map,
          title: address,
        });

        setState("success");
      })
      .catch(() => {
        if (!cancelled) {
          setState("error");
        }
      });

    return () => {
      cancelled = true;
    };
  }, [hasCoordinates, latitude, longitude, apiKey, address]);

  if (!hasCoordinates) {
    return <p className={styles.fallback}>Координати місця не вказані.</p>;
  }

  if (!apiKey) {
    return <p className={styles.fallback}>Карта тимчасово недоступна.</p>;
  }

  return (
    <div className={styles.wrapper}>
      {state === "loading" && (
        <p className={styles.status}>Завантаження карти...</p>
      )}
      {state === "error" && (
        <p className={styles.statusError}>Не вдалося завантажити карту.</p>
      )}
      <div ref={containerRef} className={styles.map} />
    </div>
  );
}
