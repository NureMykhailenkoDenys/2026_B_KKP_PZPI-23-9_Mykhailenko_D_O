import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getUserReceivedRatings, type RatingResponse } from "../../api/ratingsApi";
import { getAvatarImagePath } from "../../utils/avatars";
import { formatEventDateTime } from "../../utils/formatDate";
import { getInitials } from "../../utils/initials";
import styles from "./ProfileReviews.module.css";

type ReviewsLoadState = "loading" | "success" | "error";

interface ProfileReviewsProps {
  userId: number;
}

export function ProfileReviews({ userId }: ProfileReviewsProps) {
  const [reviews, setReviews] = useState<RatingResponse[]>([]);
  const [state, setState] = useState<ReviewsLoadState>("loading");

  useEffect(() => {
    const controller = new AbortController();

    async function loadReviews() {
      setState("loading");
      try {
        const data = await getUserReceivedRatings(userId, {
          signal: controller.signal,
        });
        setReviews(data);
        setState("success");
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setState("error");
      }
    }

    void loadReviews();

    return () => {
      controller.abort();
    };
  }, [userId]);

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>Відгуки</h2>

      {state === "loading" && (
        <p className={styles.status}>Завантаження відгуків...</p>
      )}

      {state === "error" && (
        <p className={styles.status}>Не вдалося завантажити відгуки.</p>
      )}

      {state === "success" && reviews.length === 0 && (
        <p className={styles.status}>Відгуків поки немає.</p>
      )}

      {state === "success" && reviews.length > 0 && (
        <ul className={styles.list}>
          {reviews.map((review) => {
            const avatarPath = getAvatarImagePath(review.author.avatarId);
            return (
              <li key={review.ratingId} className={styles.item}>
                <Link
                  to={`/users/${review.author.userId}`}
                  className={styles.itemHeader}
                >
                  {avatarPath ? (
                    <img
                      src={avatarPath}
                      alt=""
                      className={styles.avatar}
                    />
                  ) : (
                    <span className={styles.avatarFallback}>
                      {getInitials(
                        review.author.firstName,
                        review.author.lastName,
                      )}
                    </span>
                  )}
                  <span className={styles.authorName}>
                    {review.author.firstName} {review.author.lastName}
                  </span>
                  <span className={styles.score}>★ {review.score}</span>
                </Link>
                <p className={styles.date}>
                  {formatEventDateTime(review.createdAt)}
                </p>
                {review.comment && (
                  <p className={styles.comment}>{review.comment}</p>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
