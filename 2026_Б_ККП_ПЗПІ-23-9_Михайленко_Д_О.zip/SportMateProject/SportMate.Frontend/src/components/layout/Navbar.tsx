import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../../auth/useAuth";
import { getAvatarImagePath } from "../../utils/avatars";
import { getInitials } from "../../utils/initials";
import styles from "./Navbar.module.css";

export function Navbar() {
  const { user, isAuthenticated, isAdministrator, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate("/", { replace: true });
  }

  const avatarPath = user ? getAvatarImagePath(user.avatarId) : null;

  return (
    <header className={styles.navbar}>
      <div className={styles.inner}>
        <div className={styles.left}>
          <Link to={isAdministrator ? "/admin/users" : "/"} className={styles.brand}>
            Sport<span className={styles.brandAccent}>Mate</span>
          </Link>

          {!isAdministrator && (
            <nav className={styles.links}>
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  isActive ? `${styles.link} ${styles.linkActive}` : styles.link
                }
              >
                Всі події
              </NavLink>
            </nav>
          )}
        </div>

        <div className={styles.actions}>
          {isAuthenticated && user ? (
            <div className={styles.userInfo}>
              {!isAdministrator && (
                <NavLink to="/events/create" className={styles.createEventLink}>
                  Створити подію
                </NavLink>
              )}
              {isAdministrator && (
                <NavLink to="/admin/users" className={styles.adminLink}>
                  Адмін-панель
                </NavLink>
              )}
              <NavLink to="/profile" className={styles.profileLink}>
                {avatarPath ? (
                  <img src={avatarPath} alt="" className={styles.avatar} />
                ) : (
                  <span className={styles.avatarFallback}>
                    {getInitials(user.firstName, user.lastName)}
                  </span>
                )}
                <span className={styles.userName}>
                  {user.firstName} {user.lastName}
                </span>
              </NavLink>
              <button
                type="button"
                className={styles.logoutButton}
                onClick={handleLogout}
              >
                Вийти
              </button>
            </div>
          ) : (
            <>
              <NavLink to="/register" className={styles.registerLink}>
                Реєстрація
              </NavLink>
              <NavLink to="/login" className={styles.loginLink}>
                Увійти
              </NavLink>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
