import { Outlet, useLocation } from "react-router-dom";
import { Navbar } from "./Navbar";
import styles from "./Layout.module.css";

export function Layout() {
  const location = useLocation();
  const isAdminSection = location.pathname.startsWith("/admin");

  const contentClassName = isAdminSection
    ? `${styles.content} ${styles.contentWide}`
    : styles.content;

  return (
    <div className={styles.page}>
      <Navbar />
      <main className={contentClassName}>
        <Outlet />
      </main>
    </div>
  );
}
