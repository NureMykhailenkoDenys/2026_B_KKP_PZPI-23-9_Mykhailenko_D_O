import { AVATAR_IDS, getAvatarImagePath } from "../../utils/avatars";
import styles from "./AvatarPicker.module.css";

interface AvatarPickerProps {
  value: number | null;
  onChange: (avatarId: number) => void;
}

export function AvatarPicker({ value, onChange }: AvatarPickerProps) {
  return (
    <div className={styles.grid}>
      {AVATAR_IDS.map((avatarId) => {
        const imagePath = getAvatarImagePath(avatarId);
        const isSelected = value === avatarId;

        return (
          <button
            key={avatarId}
            type="button"
            className={
              isSelected ? `${styles.option} ${styles.selected}` : styles.option
            }
            onClick={() => onChange(avatarId)}
            aria-pressed={isSelected}
            aria-label={`Аватар ${avatarId}`}
          >
            {imagePath && (
              <img src={imagePath} alt="" className={styles.image} />
            )}
          </button>
        );
      })}
    </div>
  );
}
