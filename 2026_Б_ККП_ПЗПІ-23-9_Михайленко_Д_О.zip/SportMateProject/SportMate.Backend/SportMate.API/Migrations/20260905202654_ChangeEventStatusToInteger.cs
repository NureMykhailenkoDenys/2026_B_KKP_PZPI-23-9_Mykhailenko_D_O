﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SportMate.API.Migrations
{
    /// <inheritdoc />
    public partial class ChangeEventStatusToInteger : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Step 1: Drop the default value
            migrationBuilder.Sql(@"
                ALTER TABLE ""Events""
                ALTER COLUMN ""Status"" DROP DEFAULT;
            ");

            // Step 2: Convert text enum values to integers
            migrationBuilder.Sql(@"
                UPDATE ""Events""
                SET ""Status"" = CASE
                    WHEN ""Status"" = 'Planned' THEN '0'
                    WHEN ""Status"" = 'Active' THEN '1'
                    WHEN ""Status"" = 'Completed' THEN '2'
                    WHEN ""Status"" = 'Cancelled' THEN '3'
                    ELSE ""Status""
                END;
            ");

            // Step 3: Convert the column type
            migrationBuilder.Sql(@"
                ALTER TABLE ""Events""
                ALTER COLUMN ""Status"" TYPE integer
                USING ""Status""::integer;
            ");

            // Step 4: Set new default value
            migrationBuilder.Sql(@"
                ALTER TABLE ""Events""
                ALTER COLUMN ""Status"" SET DEFAULT 0;
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Events",
                type: "text",
                nullable: false,
                defaultValue: "Planned",
                oldClrType: typeof(int),
                oldType: "integer",
                oldDefaultValue: 0);
        }
    }
}
