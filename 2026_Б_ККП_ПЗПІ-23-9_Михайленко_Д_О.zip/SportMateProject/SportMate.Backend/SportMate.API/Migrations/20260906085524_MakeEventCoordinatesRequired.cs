﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SportMate.API.Migrations
{
    /// <inheritdoc />
    public partial class MakeEventCoordinatesRequired : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<double>(
                name: "Longitude",
                table: "Events",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0,
                oldClrType: typeof(double),
                oldType: "double precision",
                oldNullable: true);

            migrationBuilder.AlterColumn<double>(
                name: "Latitude",
                table: "Events",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0,
                oldClrType: typeof(double),
                oldType: "double precision",
                oldNullable: true);

            migrationBuilder.AddCheckConstraint(
                name: "CK_Event_Latitude",
                table: "Events",
                sql: "\"Latitude\" >= -90 AND \"Latitude\" <= 90");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Event_Longitude",
                table: "Events",
                sql: "\"Longitude\" >= -180 AND \"Longitude\" <= 180");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_Event_Latitude",
                table: "Events");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Event_Longitude",
                table: "Events");

            migrationBuilder.AlterColumn<double>(
                name: "Longitude",
                table: "Events",
                type: "double precision",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "double precision");

            migrationBuilder.AlterColumn<double>(
                name: "Latitude",
                table: "Events",
                type: "double precision",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "double precision");
        }
    }
}
