using FluentValidation;
using SportMate.API.DTOs.Chat;

namespace SportMate.API.Validators;

public class SendMessageRequestValidator : AbstractValidator<SendMessageRequest>
{
    public SendMessageRequestValidator()
    {
        RuleFor(x => x.MessageText)
            .NotEmpty()
            .WithMessage("Message text is required.")
            .MaximumLength(2000)
            .WithMessage("Message text cannot exceed 2000 characters.")
            .Must(text => !string.IsNullOrWhiteSpace(text))
            .WithMessage("Message text cannot be empty or whitespace only.");
    }
}
