using FluentValidation;
using SportMate.API.DTOs.Users;

namespace SportMate.API.Validators;

public class UpdateProfileRequestValidator : AbstractValidator<UpdateProfileRequest>
{
    public UpdateProfileRequestValidator()
    {
        RuleFor(x => x.FirstName)
            .NotEmpty().WithMessage("First name is required.")
            .MaximumLength(100).WithMessage("First name cannot exceed 100 characters.");

        RuleFor(x => x.LastName)
            .NotEmpty().WithMessage("Last name is required.")
            .MaximumLength(100).WithMessage("Last name cannot exceed 100 characters.");

        RuleFor(x => x.AvatarId)
            .InclusiveBetween(1, 10).WithMessage("Avatar ID must be between 1 and 10.")
            .When(x => x.AvatarId.HasValue);

        RuleFor(x => x.Password)
            .MinimumLength(6).WithMessage("Password must be at least 6 characters long.")
            .When(x => !string.IsNullOrEmpty(x.Password));
    }
}
