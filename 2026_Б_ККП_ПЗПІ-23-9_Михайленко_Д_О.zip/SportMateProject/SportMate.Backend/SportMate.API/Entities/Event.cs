using SportMate.API.Entities.Enums;

namespace SportMate.API.Entities;

public class Event
{
    public int EventId { get; set; }
    public string Title { get; set; } = null!;
    public string? Description { get; set; }
    public string Address { get; set; } = null!;
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public DateTime EventDate { get; set; }
    public int DurationMinutes { get; set; }
    public int MaxParticipants { get; set; }
    public EventStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }

    public int OrganizerId { get; set; }
    public int SportCategoryId { get; set; }

    public User Organizer { get; set; } = null!;
    public SportCategory SportCategory { get; set; } = null!;
    public ICollection<EventParticipant> Participants { get; set; } = new List<EventParticipant>();
    public ICollection<ChatMessage> ChatMessages { get; set; } = new List<ChatMessage>();
    public ICollection<Rating> Ratings { get; set; } = new List<Rating>();
}
