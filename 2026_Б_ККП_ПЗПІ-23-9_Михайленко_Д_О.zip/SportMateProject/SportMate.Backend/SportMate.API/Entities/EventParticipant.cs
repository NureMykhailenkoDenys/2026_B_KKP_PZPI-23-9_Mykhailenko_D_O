namespace SportMate.API.Entities;

public class EventParticipant
{
    public int EventParticipantId { get; set; }
    public DateTime JoinedAt { get; set; }

    public int UserId { get; set; }
    public int EventId { get; set; }

    public User User { get; set; } = null!;
    public Event Event { get; set; } = null!;
}
