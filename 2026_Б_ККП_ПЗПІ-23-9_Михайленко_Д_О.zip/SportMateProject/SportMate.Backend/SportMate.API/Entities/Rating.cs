namespace SportMate.API.Entities;

public class Rating
{
    public int RatingId { get; set; }
    public int Score { get; set; }
    public string? Comment { get; set; }
    public DateTime CreatedAt { get; set; }

    public int EventId { get; set; }
    public int AuthorId { get; set; }
    public int TargetUserId { get; set; }

    public Event Event { get; set; } = null!;
    public User Author { get; set; } = null!;
    public User TargetUser { get; set; } = null!;
}
