using SportMate.API.Entities.Enums;

namespace SportMate.API.Entities;

public class User
{
    public int Id { get; set; }
    public string FirstName { get; set; } = null!;
    public string LastName { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string PasswordHash { get; set; } = null!;
    public int? AvatarId { get; set; }
    public UserRole Role { get; set; }
    public double Rating { get; set; }
    public bool IsBlocked { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public ICollection<Event> OrganizedEvents { get; set; } = new List<Event>();
    public ICollection<EventParticipant> EventParticipations { get; set; } = new List<EventParticipant>();
    public ICollection<ChatMessage> ChatMessages { get; set; } = new List<ChatMessage>();
    public ICollection<Rating> AuthoredRatings { get; set; } = new List<Rating>();
    public ICollection<Rating> ReceivedRatings { get; set; } = new List<Rating>();
}
