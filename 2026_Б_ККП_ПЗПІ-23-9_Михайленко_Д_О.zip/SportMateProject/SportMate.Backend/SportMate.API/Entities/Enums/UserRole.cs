namespace SportMate.API.Entities.Enums;

/// <summary>
/// User role for authorization
/// </summary>
public enum UserRole
{
    /// <summary>
    /// Regular user (can create events, participate, rate, chat)
    /// </summary>
    User = 0,

    /// <summary>
    /// Administrator (full access including user blocking and event deletion)
    /// </summary>
    Administrator = 1
}
