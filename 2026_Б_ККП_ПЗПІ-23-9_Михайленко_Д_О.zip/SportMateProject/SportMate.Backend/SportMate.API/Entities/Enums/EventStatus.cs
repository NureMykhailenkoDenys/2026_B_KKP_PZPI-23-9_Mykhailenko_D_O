namespace SportMate.API.Entities.Enums;

/// <summary>
/// Event lifecycle status
/// </summary>
public enum EventStatus
{
    /// <summary>
    /// Event is scheduled but has not started yet
    /// </summary>
    Planned = 0,

    /// <summary>
    /// Event is currently in progress
    /// </summary>
    Active = 1,

    /// <summary>
    /// Event has finished
    /// </summary>
    Completed = 2,

    /// <summary>
    /// Event has been cancelled by organizer or admin
    /// </summary>
    Cancelled = 3
}
