namespace SportMate.API.Entities;

public class SportCategory
{
    public int SportCategoryId { get; set; }
    public string Name { get; set; } = null!;
    public string? ImagePath { get; set; }

    public ICollection<Event> Events { get; set; } = new List<Event>();
}
