namespace SportMate.API.Entities;

public class ChatMessage
{
    public int ChatMessageId { get; set; }
    public string MessageText { get; set; } = null!;
    public DateTime SentAt { get; set; }

    public int UserId { get; set; }
    public int EventId { get; set; }

    public User User { get; set; } = null!;
    public Event Event { get; set; } = null!;
}
