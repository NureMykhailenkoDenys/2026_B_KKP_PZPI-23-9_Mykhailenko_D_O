using Microsoft.EntityFrameworkCore;
using SportMate.API.Data;
using SportMate.API.DTOs.Ratings;
using SportMate.API.Entities;
using SportMate.API.Entities.Enums;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Services;

public class RatingService : IRatingService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<RatingService> _logger;

    public RatingService(ApplicationDbContext context, ILogger<RatingService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<RatingResponse> CreateRatingAsync(int authorId, CreateRatingRequest request)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();

        try
        {
            var eventEntity = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == request.EventId);

            if (eventEntity == null)
            {
                throw new InvalidOperationException("Event not found.");
            }

            if (eventEntity.Status != EventStatus.Completed)
            {
                throw new InvalidOperationException("Ratings can only be created for completed events.");
            }

            var author = await _context.Users.FindAsync(authorId);
            if (author == null)
            {
                throw new InvalidOperationException("Author not found.");
            }

            if (author.IsBlocked)
            {
                throw new UnauthorizedAccessException("Blocked users cannot create ratings.");
            }

            var targetUser = await _context.Users.FindAsync(request.TargetUserId);
            if (targetUser == null)
            {
                throw new InvalidOperationException("Target user not found.");
            }

            if (authorId == request.TargetUserId)
            {
                throw new InvalidOperationException("You cannot rate yourself.");
            }

            var isAuthorParticipant = await IsUserParticipantAsync(request.EventId, authorId);
            if (!isAuthorParticipant)
            {
                throw new UnauthorizedAccessException("You must be a participant of this event to create ratings.");
            }

            var isTargetParticipant = await IsUserParticipantAsync(request.EventId, request.TargetUserId);
            if (!isTargetParticipant)
            {
                throw new InvalidOperationException("Target user must be a participant of this event.");
            }

            var existingRating = await _context.Ratings
                .FirstOrDefaultAsync(r => r.EventId == request.EventId
                    && r.AuthorId == authorId
                    && r.TargetUserId == request.TargetUserId);

            if (existingRating != null)
            {
                throw new InvalidOperationException("You have already rated this user for this event.");
            }

            var rating = new Rating
            {
                EventId = request.EventId,
                AuthorId = authorId,
                TargetUserId = request.TargetUserId,
                Score = request.Score,
                Comment = request.Comment?.Trim(),
                CreatedAt = DateTime.UtcNow
            };

            _context.Ratings.Add(rating);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Rating {RatingId} created by User {AuthorId} for User {TargetUserId} in Event {EventId}.",
                rating.RatingId, authorId, request.TargetUserId, request.EventId);

            await RecalculateUserRatingAsync(request.TargetUserId);

            await transaction.CommitAsync();

            _logger.LogInformation("User {UserId} rating recalculated after new rating.", request.TargetUserId);

            var response = await GetRatingResponseAsync(rating.RatingId);
            return response;
        }
        catch (DbUpdateException ex) when (ex.InnerException?.Message?.Contains("duplicate key") == true
            || ex.InnerException?.Message?.Contains("unique constraint") == true)
        {
            await transaction.RollbackAsync();
            _logger.LogWarning("Duplicate rating attempt by User {AuthorId} for User {TargetUserId} in Event {EventId}.",
                authorId, request.TargetUserId, request.EventId);
            throw new InvalidOperationException("You have already rated this user for this event.");
        }
        catch
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    public async Task<List<RatingResponse>> GetEventRatingsAsync(int eventId)
    {
        var ratings = await _context.Ratings
            .Include(r => r.Author)
            .Include(r => r.TargetUser)
            .Where(r => r.EventId == eventId)
            .OrderByDescending(r => r.CreatedAt)
            .AsNoTracking()
            .Select(r => new RatingResponse
            {
                RatingId = r.RatingId,
                EventId = r.EventId,
                Author = new RatingUserInfo
                {
                    UserId = r.Author.Id,
                    FirstName = r.Author.FirstName,
                    LastName = r.Author.LastName,
                    AvatarId = r.Author.AvatarId,
                    Rating = r.Author.Rating
                },
                TargetUser = new RatingUserInfo
                {
                    UserId = r.TargetUser.Id,
                    FirstName = r.TargetUser.FirstName,
                    LastName = r.TargetUser.LastName,
                    AvatarId = r.TargetUser.AvatarId,
                    Rating = r.TargetUser.Rating
                },
                Score = r.Score,
                Comment = r.Comment,
                CreatedAt = r.CreatedAt
            })
            .ToListAsync();

        return ratings;
    }

    public async Task<List<RatingResponse>> GetUserReceivedRatingsAsync(int userId)
    {
        var ratings = await _context.Ratings
            .Include(r => r.Author)
            .Include(r => r.TargetUser)
            .Where(r => r.TargetUserId == userId)
            .OrderByDescending(r => r.CreatedAt)
            .AsNoTracking()
            .Select(r => new RatingResponse
            {
                RatingId = r.RatingId,
                EventId = r.EventId,
                Author = new RatingUserInfo
                {
                    UserId = r.Author.Id,
                    FirstName = r.Author.FirstName,
                    LastName = r.Author.LastName,
                    AvatarId = r.Author.AvatarId,
                    Rating = r.Author.Rating
                },
                TargetUser = new RatingUserInfo
                {
                    UserId = r.TargetUser.Id,
                    FirstName = r.TargetUser.FirstName,
                    LastName = r.TargetUser.LastName,
                    AvatarId = r.TargetUser.AvatarId,
                    Rating = r.TargetUser.Rating
                },
                Score = r.Score,
                Comment = r.Comment,
                CreatedAt = r.CreatedAt
            })
            .ToListAsync();

        return ratings;
    }

    private async Task<bool> IsUserParticipantAsync(int eventId, int userId)
    {
        var isOrganizer = await _context.Events
            .AnyAsync(e => e.EventId == eventId && e.OrganizerId == userId);

        if (isOrganizer)
        {
            return true;
        }

        var isParticipant = await _context.EventParticipants
            .AnyAsync(ep => ep.EventId == eventId && ep.UserId == userId);

        return isParticipant;
    }

    private async Task RecalculateUserRatingAsync(int userId)
    {
        var averageRating = await _context.Ratings
            .Where(r => r.TargetUserId == userId)
            .AverageAsync(r => (double?)r.Score) ?? 0.0;

        averageRating = Math.Round(averageRating, 2);

        var user = await _context.Users.FindAsync(userId);
        if (user != null)
        {
            user.Rating = averageRating;
            user.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();
        }
    }

    private async Task<RatingResponse> GetRatingResponseAsync(int ratingId)
    {
        var response = await _context.Ratings
            .Include(r => r.Author)
            .Include(r => r.TargetUser)
            .Where(r => r.RatingId == ratingId)
            .AsNoTracking()
            .Select(r => new RatingResponse
            {
                RatingId = r.RatingId,
                EventId = r.EventId,
                Author = new RatingUserInfo
                {
                    UserId = r.Author.Id,
                    FirstName = r.Author.FirstName,
                    LastName = r.Author.LastName,
                    AvatarId = r.Author.AvatarId,
                    Rating = r.Author.Rating
                },
                TargetUser = new RatingUserInfo
                {
                    UserId = r.TargetUser.Id,
                    FirstName = r.TargetUser.FirstName,
                    LastName = r.TargetUser.LastName,
                    AvatarId = r.TargetUser.AvatarId,
                    Rating = r.TargetUser.Rating
                },
                Score = r.Score,
                Comment = r.Comment,
                CreatedAt = r.CreatedAt
            })
            .FirstAsync();

        return response;
    }
}
