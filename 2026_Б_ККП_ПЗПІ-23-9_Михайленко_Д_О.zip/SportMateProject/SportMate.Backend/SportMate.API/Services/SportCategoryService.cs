using Microsoft.EntityFrameworkCore;
using SportMate.API.Data;
using SportMate.API.DTOs.Common;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Services;

public class SportCategoryService : ISportCategoryService
{
    private readonly ApplicationDbContext _context;

    public SportCategoryService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<SportCategoryResponse>> GetAllAsync()
    {
        var categories = await _context.SportCategories
            .AsNoTracking()
            .OrderBy(sc => sc.Name)
            .Select(sc => new SportCategoryResponse
            {
                SportCategoryId = sc.SportCategoryId,
                Name = sc.Name,
                ImagePath = sc.ImagePath
            })
            .ToListAsync();

        return categories;
    }
}
