using Microsoft.EntityFrameworkCore;
using SportMate.API.Data;
using SportMate.API.DTOs.Chat;
using SportMate.API.Entities;
using SportMate.API.Entities.Enums;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Services;

public class ChatService : IChatService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<ChatService> _logger;

    public ChatService(ApplicationDbContext context, ILogger<ChatService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ChatHistoryResponse> GetChatHistoryAsync(int eventId, int userId, int page, int pageSize)
    {
        if (!await IsUserParticipantAsync(eventId, userId))
        {
            throw new UnauthorizedAccessException("User is not a participant of this event.");
        }

        if (page < 1) page = 1;
        if (pageSize < 1) pageSize = 50;
        if (pageSize > 100) pageSize = 100;

        var query = _context.ChatMessages
            .Include(m => m.User)
            .Where(m => m.EventId == eventId)
            .OrderBy(m => m.SentAt);

        var totalCount = await query.CountAsync();
        var skip = (page - 1) * pageSize;

        var messages = await query
            .Skip(skip)
            .Take(pageSize)
            .Select(m => new ChatMessageResponse
            {
                ChatMessageId = m.ChatMessageId,
                EventId = m.EventId,
                UserId = m.UserId,
                SenderName = m.User.FirstName + " " + m.User.LastName,
                AvatarId = m.User.AvatarId,
                MessageText = m.MessageText,
                SentAt = m.SentAt
            })
            .ToListAsync();

        _logger.LogInformation("Retrieved {Count} messages for Event {EventId}, page {Page}.", messages.Count, eventId, page);

        return new ChatHistoryResponse
        {
            Items = messages,
            Page = page,
            PageSize = pageSize,
            TotalCount = totalCount
        };
    }

    public async Task<ChatMessageResponse> SaveMessageAsync(int eventId, int userId, string messageText)
    {
        var eventEntity = await _context.Events
            .FirstOrDefaultAsync(e => e.EventId == eventId);

        if (eventEntity == null)
        {
            throw new InvalidOperationException("Event not found.");
        }

        if (eventEntity.Status == EventStatus.Cancelled || eventEntity.Status == EventStatus.Completed)
        {
            throw new InvalidOperationException($"Cannot send messages to {eventEntity.Status} events.");
        }

        var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null)
        {
            throw new InvalidOperationException("User not found.");
        }

        if (user.IsBlocked)
        {
            throw new UnauthorizedAccessException("Blocked users cannot send messages.");
        }

        if (!await IsUserParticipantAsync(eventId, userId))
        {
            throw new UnauthorizedAccessException("User is not a participant of this event.");
        }

        var chatMessage = new ChatMessage
        {
            EventId = eventId,
            UserId = userId,
            MessageText = messageText.Trim(),
            SentAt = DateTime.UtcNow
        };

        _context.ChatMessages.Add(chatMessage);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Message {MessageId} saved for Event {EventId} by User {UserId}.",
            chatMessage.ChatMessageId, eventId, userId);

        return new ChatMessageResponse
        {
            ChatMessageId = chatMessage.ChatMessageId,
            EventId = chatMessage.EventId,
            UserId = chatMessage.UserId,
            SenderName = user.FirstName + " " + user.LastName,
            AvatarId = user.AvatarId,
            MessageText = chatMessage.MessageText,
            SentAt = chatMessage.SentAt
        };
    }

    public async Task<bool> IsUserParticipantAsync(int eventId, int userId)
    {
        var isOrganizer = await _context.Events
            .AnyAsync(e => e.EventId == eventId && e.OrganizerId == userId);

        if (isOrganizer)
        {
            return true;
        }

        var isParticipant = await _context.EventParticipants
            .AnyAsync(ep => ep.EventId == eventId && ep.UserId == userId);

        return isParticipant;
    }
}
