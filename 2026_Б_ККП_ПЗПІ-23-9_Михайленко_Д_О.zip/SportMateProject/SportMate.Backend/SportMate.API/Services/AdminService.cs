using Microsoft.EntityFrameworkCore;
using SportMate.API.Data;
using SportMate.API.DTOs.Admin;
using SportMate.API.Entities.Enums;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Services;

public class AdminService : IAdminService
{
    private readonly ApplicationDbContext _context;

    public AdminService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<UserAdminResponse>> GetUsersAsync()
    {
        var users = await _context.Users
            .AsNoTracking()
            .OrderBy(u => u.CreatedAt)
            .Select(u => new UserAdminResponse
            {
                UserId = u.Id,
                FirstName = u.FirstName,
                LastName = u.LastName,
                Email = u.Email,
                AvatarId = u.AvatarId,
                Role = u.Role.ToString(),
                Rating = u.Rating,
                IsBlocked = u.IsBlocked,
                CreatedAt = u.CreatedAt
            })
            .ToListAsync();

        return users;
    }

    public async Task BlockUserAsync(int userId, int adminId)
    {
        if (userId == adminId)
        {
            throw new InvalidOperationException("Administrator cannot block themselves.");
        }

        var user = await _context.Users.FindAsync(userId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        user.IsBlocked = true;
        user.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
    }

    public async Task UnblockUserAsync(int userId)
    {
        var user = await _context.Users.FindAsync(userId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        user.IsBlocked = false;
        user.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
    }

    public async Task<List<EventAdminResponse>> GetEventsAsync()
    {
        var events = await _context.Events
            .Include(e => e.Organizer)
            .Include(e => e.SportCategory)
            .Include(e => e.Participants)
            .AsNoTracking()
            .OrderByDescending(e => e.CreatedAt)
            .Select(e => new EventAdminResponse
            {
                EventId = e.EventId,
                Title = e.Title,
                EventDate = e.EventDate,
                Status = e.Status,
                Organizer = new OrganizerInfo
                {
                    UserId = e.Organizer.Id,
                    FirstName = e.Organizer.FirstName,
                    LastName = e.Organizer.LastName
                },
                SportCategory = new SportCategoryInfo
                {
                    SportCategoryId = e.SportCategory.SportCategoryId,
                    Name = e.SportCategory.Name
                },
                ParticipantCount = e.Participants.Count,
                MaxParticipants = e.MaxParticipants
            })
            .ToListAsync();

        return events;
    }

    public async Task DeleteEventAsync(int eventId)
    {
        var eventEntity = await _context.Events
            .FirstOrDefaultAsync(e => e.EventId == eventId);

        if (eventEntity == null)
        {
            throw new KeyNotFoundException("Event not found.");
        }

        _context.Events.Remove(eventEntity);
        await _context.SaveChangesAsync();
    }
}
