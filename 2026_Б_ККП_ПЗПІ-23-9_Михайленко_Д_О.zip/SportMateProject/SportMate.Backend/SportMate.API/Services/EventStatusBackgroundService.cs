using Microsoft.EntityFrameworkCore;
using SportMate.API.Data;
using SportMate.API.Entities.Enums;

namespace SportMate.API.Services;

public class EventStatusBackgroundService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<EventStatusBackgroundService> _logger;
    private readonly TimeSpan _checkInterval = TimeSpan.FromSeconds(30);

    public EventStatusBackgroundService(
        IServiceScopeFactory scopeFactory,
        ILogger<EventStatusBackgroundService> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Event Status Background Service started.");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await UpdateEventStatusesAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while updating event statuses.");
            }

            await Task.Delay(_checkInterval, stoppingToken);
        }

        _logger.LogInformation("Event Status Background Service stopped.");
    }

    private async Task UpdateEventStatusesAsync(CancellationToken cancellationToken)
    {
        await using var scope = _scopeFactory.CreateAsyncScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        var now = DateTime.UtcNow;

        await TransitionPlannedToActiveAsync(dbContext, now, cancellationToken);

        await TransitionActiveToCompletedAsync(dbContext, now, cancellationToken);
    }

    private async Task TransitionPlannedToActiveAsync(
        ApplicationDbContext dbContext,
        DateTime now,
        CancellationToken cancellationToken)
    {
        var eventsToActivate = await dbContext.Events
            .Where(e => e.Status == EventStatus.Planned && e.EventDate <= now)
            .ToListAsync(cancellationToken);

        _logger.LogInformation("Found {Count} events to activate (Planned -> Active).", eventsToActivate.Count);

        foreach (var eventEntity in eventsToActivate)
        {
            eventEntity.Status = EventStatus.Active;
            _logger.LogInformation("Event {EventId} status changed from Planned to Active.", eventEntity.EventId);
        }

        if (eventsToActivate.Any())
        {
            await dbContext.SaveChangesAsync(cancellationToken);
            _logger.LogInformation("Saved {Count} status changes to database.", eventsToActivate.Count);
        }
    }

    private async Task TransitionActiveToCompletedAsync(
        ApplicationDbContext dbContext,
        DateTime now,
        CancellationToken cancellationToken)
    {
        var eventsToComplete = await dbContext.Events
            .Where(e => e.Status == EventStatus.Active)
            .ToListAsync(cancellationToken);

        var completedEvents = eventsToComplete
            .Where(e => e.EventDate.AddMinutes(e.DurationMinutes) <= now)
            .ToList();

        _logger.LogInformation("Found {Count} events to complete (Active -> Completed).", completedEvents.Count);

        foreach (var eventEntity in completedEvents)
        {
            eventEntity.Status = EventStatus.Completed;
            _logger.LogInformation("Event {EventId} status changed from Active to Completed.", eventEntity.EventId);
        }

        if (completedEvents.Any())
        {
            await dbContext.SaveChangesAsync(cancellationToken);
            _logger.LogInformation("Saved {Count} status changes to database.", completedEvents.Count);
        }
    }
}
