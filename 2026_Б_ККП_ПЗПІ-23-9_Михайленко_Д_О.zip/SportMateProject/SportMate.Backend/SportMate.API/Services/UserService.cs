using Microsoft.EntityFrameworkCore;
using SportMate.API.Data;
using SportMate.API.DTOs.Events;
using SportMate.API.DTOs.Users;
using SportMate.API.Entities;
using SportMate.API.Entities.Enums;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Services;

public class UserService : IUserService
{
    private readonly ApplicationDbContext _context;

    public UserService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<UserProfileResponse> GetCurrentUserProfileAsync(int userId)
    {
        var user = await _context.Users
            .FirstOrDefaultAsync(u => u.Id == userId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        return await BuildUserProfileResponseAsync(user);
    }

    public async Task<UserProfileResponse> UpdateCurrentUserProfileAsync(int userId, UpdateProfileRequest request)
    {
        var user = await _context.Users
            .FirstOrDefaultAsync(u => u.Id == userId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        user.FirstName = request.FirstName;
        user.LastName = request.LastName;
        user.AvatarId = request.AvatarId;

        if (!string.IsNullOrEmpty(request.Password))
        {
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
        }

        user.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return await BuildUserProfileResponseAsync(user);
    }

    public async Task<PublicUserProfileResponse> GetPublicUserProfileAsync(int userId)
    {
        var user = await _context.Users
            .FirstOrDefaultAsync(u => u.Id == userId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        var (organizedEvents, participatingEvents) = await GetOrganizerAndParticipantEventsAsync(user.Id);

        return new PublicUserProfileResponse
        {
            UserId = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            AvatarId = user.AvatarId,
            Rating = user.Rating,
            OrganizedEvents = MapToEventListItems(organizedEvents),
            ParticipatingEvents = MapToEventListItems(participatingEvents)
        };
    }

    private async Task<UserProfileResponse> BuildUserProfileResponseAsync(User user)
    {
        var (organizedEvents, participatingEvents) = await GetOrganizerAndParticipantEventsAsync(user.Id);

        var completedEventsCount = await _context.Events
            .Where(e => e.Status == EventStatus.Completed
                && (e.OrganizerId == user.Id || e.Participants.Any(p => p.UserId == user.Id)))
            .CountAsync();

        return new UserProfileResponse
        {
            UserId = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email,
            AvatarId = user.AvatarId,
            Rating = user.Rating,
            Role = user.Role.ToString(),
            CreatedAt = user.CreatedAt,
            CompletedEventsCount = completedEventsCount,
            OrganizedEvents = MapToEventListItems(organizedEvents),
            ParticipatingEvents = MapToEventListItems(participatingEvents)
        };
    }

    private async Task<(List<Event> Organized, List<Event> Participating)> GetOrganizerAndParticipantEventsAsync(int userId)
    {
        var organizedEvents = await _context.Events
            .Where(e => e.OrganizerId == userId)
            .Include(e => e.SportCategory)
            .Include(e => e.Participants)
            .AsNoTracking()
            .OrderByDescending(e => e.EventDate)
            .ToListAsync();

        var participatingEvents = await _context.Events
            .Where(e => e.Participants.Any(p => p.UserId == userId))
            .Include(e => e.SportCategory)
            .Include(e => e.Participants)
            .AsNoTracking()
            .OrderByDescending(e => e.EventDate)
            .ToListAsync();

        return (organizedEvents, participatingEvents);
    }

    private static List<EventListItemResponse> MapToEventListItems(List<Event> events)
    {
        return events.Select(e => new EventListItemResponse
        {
            EventId = e.EventId,
            Title = e.Title,
            EventDate = e.EventDate,
            DurationMinutes = e.DurationMinutes,
            Address = e.Address,
            SportCategory = new SportCategoryInfo
            {
                SportCategoryId = e.SportCategory.SportCategoryId,
                Name = e.SportCategory.Name,
                ImagePath = e.SportCategory.ImagePath
            },
            Status = e.Status,
            MaxParticipants = e.MaxParticipants,
            ParticipantCount = e.Participants.Count,
            FreeSlots = Math.Max(0, e.MaxParticipants - e.Participants.Count)
        }).ToList();
    }
}
