using SportMate.API.DTOs.Common;

namespace SportMate.API.Services.Interfaces;

public interface ISportCategoryService
{
    Task<List<SportCategoryResponse>> GetAllAsync();
}
