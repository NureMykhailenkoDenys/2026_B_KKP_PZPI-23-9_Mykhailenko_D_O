using SportMate.API.DTOs.Events;
using SportMate.API.Entities.Enums;

namespace SportMate.API.Services.Interfaces;

public interface IEventService
{
    Task<EventResponse> CreateEventAsync(CreateEventRequest request, int organizerId);
    Task<List<EventListItemResponse>> GetEventsAsync(int? sportCategoryId, EventStatus? status, DateTime? date, string? address);
    Task<EventResponse> GetEventByIdAsync(int eventId);
    Task<EventResponse> UpdateEventAsync(int eventId, UpdateEventRequest request, int currentUserId);
    Task CancelEventAsync(int eventId, int currentUserId);
}
