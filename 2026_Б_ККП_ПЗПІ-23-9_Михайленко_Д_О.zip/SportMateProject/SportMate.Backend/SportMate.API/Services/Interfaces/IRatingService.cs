using SportMate.API.DTOs.Ratings;

namespace SportMate.API.Services.Interfaces;

public interface IRatingService
{
    Task<RatingResponse> CreateRatingAsync(int authorId, CreateRatingRequest request);
    Task<List<RatingResponse>> GetEventRatingsAsync(int eventId);
    Task<List<RatingResponse>> GetUserReceivedRatingsAsync(int userId);
}
