using SportMate.API.DTOs.Admin;

namespace SportMate.API.Services.Interfaces;

public interface IAdminService
{
    Task<List<UserAdminResponse>> GetUsersAsync();
    Task BlockUserAsync(int userId, int adminId);
    Task UnblockUserAsync(int userId);
    Task<List<EventAdminResponse>> GetEventsAsync();
    Task DeleteEventAsync(int eventId);
}
