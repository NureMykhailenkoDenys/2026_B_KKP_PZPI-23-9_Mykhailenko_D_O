using SportMate.API.DTOs.Users;

namespace SportMate.API.Services.Interfaces;

public interface IUserService
{
    Task<UserProfileResponse> GetCurrentUserProfileAsync(int userId);
    Task<UserProfileResponse> UpdateCurrentUserProfileAsync(int userId, UpdateProfileRequest request);
    Task<PublicUserProfileResponse> GetPublicUserProfileAsync(int userId);
}
