using SportMate.API.DTOs.Chat;

namespace SportMate.API.Services.Interfaces;

public interface IChatService
{
    Task<ChatHistoryResponse> GetChatHistoryAsync(int eventId, int userId, int page, int pageSize);
    Task<ChatMessageResponse> SaveMessageAsync(int eventId, int userId, string messageText);
    Task<bool> IsUserParticipantAsync(int eventId, int userId);
}
