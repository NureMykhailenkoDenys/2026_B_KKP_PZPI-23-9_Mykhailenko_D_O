using SportMate.API.DTOs.Participation;

namespace SportMate.API.Services.Interfaces;

public interface IParticipationService
{
    Task<JoinEventResponse> JoinEventAsync(int eventId, int userId);
    Task LeaveEventAsync(int eventId, int userId);
    Task<List<EventParticipantResponse>> GetParticipantsAsync(int eventId);
}
