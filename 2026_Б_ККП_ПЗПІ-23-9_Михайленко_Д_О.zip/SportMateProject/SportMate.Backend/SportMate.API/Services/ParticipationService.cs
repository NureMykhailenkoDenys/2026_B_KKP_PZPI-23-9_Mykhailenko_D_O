using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Npgsql;
using SportMate.API.Data;
using SportMate.API.DTOs.Participation;
using SportMate.API.Entities;
using SportMate.API.Entities.Enums;
using SportMate.API.Services.Interfaces;
using System.Data;

namespace SportMate.API.Services;

public class ParticipationService : IParticipationService
{
    private readonly ApplicationDbContext _context;

    private const int MaxJoinAttempts = 10;

    public ParticipationService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<JoinEventResponse> JoinEventAsync(int eventId, int userId)
    {
        for (var attempt = 1; attempt <= MaxJoinAttempts; attempt++)
        {
            try
            {
                return await TryJoinEventOnceAsync(eventId, userId);
            }
            catch (Exception ex) when (attempt < MaxJoinAttempts && IsSerializationFailure(ex))
            {
                _context.ChangeTracker.Clear();

                var backoffMs = Math.Min(200, Random.Shared.Next(5, 20) * attempt);
                await Task.Delay(backoffMs);
            }
        }

        throw new InvalidOperationException("Unable to join the event due to repeated concurrency conflicts. Please try again.");
    }

    private async Task<JoinEventResponse> TryJoinEventOnceAsync(int eventId, int userId)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);

        try
        {
            var user = await _context.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null)
            {
                throw new KeyNotFoundException("User not found.");
            }

            if (user.IsBlocked)
            {
                throw new UnauthorizedAccessException("Blocked user cannot join events.");
            }

            var eventEntity = await _context.Events
                .Include(e => e.Participants)
                .FirstOrDefaultAsync(e => e.EventId == eventId);

            if (eventEntity == null)
            {
                throw new KeyNotFoundException("Event not found.");
            }

            if (eventEntity.Status == EventStatus.Completed)
            {
                throw new InvalidOperationException("Cannot join a completed event.");
            }

            if (eventEntity.Status == EventStatus.Cancelled)
            {
                throw new InvalidOperationException("Cannot join a cancelled event.");
            }

            if (DateTime.UtcNow >= eventEntity.EventDate)
            {
                throw new InvalidOperationException("Cannot join an event that has already started.");
            }

            var isAlreadyParticipant = eventEntity.Participants.Any(p => p.UserId == userId);
            if (isAlreadyParticipant)
            {
                throw new InvalidOperationException("User is already a participant of this event.");
            }

            var currentParticipantCount = eventEntity.Participants.Count;
            if (currentParticipantCount >= eventEntity.MaxParticipants)
            {
                throw new InvalidOperationException("Event is full. No free slots available.");
            }

            var newParticipant = new EventParticipant
            {
                UserId = userId,
                EventId = eventId,
                JoinedAt = DateTime.UtcNow
            };

            _context.EventParticipants.Add(newParticipant);
            await _context.SaveChangesAsync();

            await transaction.CommitAsync();

            var participantCount = currentParticipantCount + 1;
            var freeSlots = Math.Max(0, eventEntity.MaxParticipants - participantCount);

            return new JoinEventResponse
            {
                EventId = eventId,
                UserId = userId,
                ParticipantCount = participantCount,
                MaxParticipants = eventEntity.MaxParticipants,
                FreeSlots = freeSlots,
                JoinedAt = newParticipant.JoinedAt
            };
        }
        catch (DbUpdateException ex) when (ex.InnerException?.Message.Contains("IX_EventParticipants_UserId_EventId") == true)
        {
            await SafeRollbackAsync(transaction);
            throw new InvalidOperationException("User is already a participant of this event.");
        }
        catch
        {
            await SafeRollbackAsync(transaction);
            throw;
        }
    }

    private static bool IsSerializationFailure(Exception exception)
    {
        for (var current = exception; current != null; current = current.InnerException)
        {
            if (current is PostgresException postgresException
                && postgresException.SqlState == PostgresErrorCodes.SerializationFailure)
            {
                return true;
            }
        }

        return false;
    }

    private static async Task SafeRollbackAsync(IDbContextTransaction transaction)
    {
        try
        {
            await transaction.RollbackAsync();
        }
        catch
        {
        }
    }

    public async Task LeaveEventAsync(int eventId, int userId)
    {
        var eventEntity = await _context.Events
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.EventId == eventId);

        if (eventEntity == null)
        {
            throw new KeyNotFoundException("Event not found.");
        }

        var user = await _context.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == userId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        if (user.IsBlocked)
        {
            throw new UnauthorizedAccessException("Blocked user cannot leave events.");
        }

        if (eventEntity.Status == EventStatus.Completed)
        {
            throw new InvalidOperationException("Cannot leave a completed event.");
        }

        if (eventEntity.Status == EventStatus.Cancelled)
        {
            throw new InvalidOperationException("Cannot leave a cancelled event.");
        }

        if (DateTime.UtcNow >= eventEntity.EventDate)
        {
            throw new InvalidOperationException("Cannot leave an event that has already started.");
        }

        if (eventEntity.OrganizerId == userId)
        {
            throw new UnauthorizedAccessException("Organizer cannot leave their own event.");
        }

        var participant = await _context.EventParticipants
            .FirstOrDefaultAsync(ep => ep.EventId == eventId && ep.UserId == userId);

        if (participant == null)
        {
            throw new InvalidOperationException("User is not a participant of this event.");
        }

        _context.EventParticipants.Remove(participant);
        await _context.SaveChangesAsync();
    }

    public async Task<List<EventParticipantResponse>> GetParticipantsAsync(int eventId)
    {
        var eventExists = await _context.Events.AnyAsync(e => e.EventId == eventId);

        if (!eventExists)
        {
            throw new KeyNotFoundException("Event not found.");
        }

        return await _context.EventParticipants
            .AsNoTracking()
            .Where(ep => ep.EventId == eventId)
            .OrderBy(ep => ep.JoinedAt)
            .Select(ep => new EventParticipantResponse
            {
                UserId = ep.UserId,
                FirstName = ep.User.FirstName,
                LastName = ep.User.LastName,
                AvatarId = ep.User.AvatarId,
                Rating = ep.User.Rating,
                JoinedAt = ep.JoinedAt
            })
            .ToListAsync();
    }
}
