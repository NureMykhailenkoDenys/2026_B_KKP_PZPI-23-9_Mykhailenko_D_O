using Microsoft.EntityFrameworkCore;
using SportMate.API.Data;
using SportMate.API.DTOs.Events;
using SportMate.API.Entities;
using SportMate.API.Entities.Enums;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Services;

public class EventService : IEventService
{
    private readonly ApplicationDbContext _context;

    public EventService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<EventResponse> CreateEventAsync(CreateEventRequest request, int organizerId)
    {
        var organizer = await _context.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == organizerId);

        if (organizer == null)
        {
            throw new KeyNotFoundException("Organizer not found.");
        }

        if (organizer.IsBlocked)
        {
            throw new UnauthorizedAccessException("Blocked users cannot create events.");
        }

        var sportCategoryExists = await _context.SportCategories
            .AnyAsync(sc => sc.SportCategoryId == request.SportCategoryId);

        if (!sportCategoryExists)
        {
            throw new KeyNotFoundException("Sport category not found.");
        }

        if (!request.Latitude.HasValue || !request.Longitude.HasValue)
        {
            throw new ArgumentException("Latitude and longitude are required to create an event.");
        }

        var newEvent = new Event
        {
            Title = request.Title,
            Description = request.Description,
            SportCategoryId = request.SportCategoryId,
            EventDate = DateTime.SpecifyKind(request.EventDate, DateTimeKind.Utc),
            DurationMinutes = request.DurationMinutes,
            MaxParticipants = request.MaxParticipants,
            Address = request.Address,
            Latitude = request.Latitude.Value,
            Longitude = request.Longitude.Value,
            OrganizerId = organizerId,
            Status = EventStatus.Planned,
            CreatedAt = DateTime.UtcNow
        };

        _context.Events.Add(newEvent);
        await _context.SaveChangesAsync();

        var organizerParticipant = new EventParticipant
        {
            UserId = organizerId,
            EventId = newEvent.EventId,
            JoinedAt = DateTime.UtcNow
        };

        _context.EventParticipants.Add(organizerParticipant);
        await _context.SaveChangesAsync();

        var createdEvent = await _context.Events
            .Include(e => e.Organizer)
            .Include(e => e.SportCategory)
            .Include(e => e.Participants)
            .FirstAsync(e => e.EventId == newEvent.EventId);

        return MapToEventResponse(createdEvent);
    }

    public async Task<List<EventListItemResponse>> GetEventsAsync(int? sportCategoryId, EventStatus? status, DateTime? date, string? address)
    {
        var query = _context.Events
            .Include(e => e.SportCategory)
            .Include(e => e.Participants)
            .AsNoTracking();

        if (sportCategoryId.HasValue)
        {
            query = query.Where(e => e.SportCategoryId == sportCategoryId.Value);
        }

        if (status.HasValue)
        {
            query = query.Where(e => e.Status == status.Value);
        }

        if (date.HasValue)
        {
            var startOfDay = DateTime.SpecifyKind(date.Value.Date, DateTimeKind.Utc);
            var endOfDay = startOfDay.AddDays(1);
            query = query.Where(e => e.EventDate >= startOfDay && e.EventDate < endOfDay);
        }

        if (!string.IsNullOrWhiteSpace(address))
        {
            query = query.Where(e => e.Address.Contains(address));
        }

        query = query.OrderByDescending(e => e.CreatedAt);

        var events = await query.ToListAsync();

        return events.Select(e => new EventListItemResponse
        {
            EventId = e.EventId,
            Title = e.Title,
            EventDate = e.EventDate,
            DurationMinutes = e.DurationMinutes,
            Address = e.Address,
            SportCategory = new SportCategoryInfo
            {
                SportCategoryId = e.SportCategory.SportCategoryId,
                Name = e.SportCategory.Name,
                ImagePath = e.SportCategory.ImagePath
            },
            Status = e.Status,
            MaxParticipants = e.MaxParticipants,
            ParticipantCount = e.Participants.Count,
            FreeSlots = Math.Max(0, e.MaxParticipants - e.Participants.Count)
        }).ToList();
    }

    public async Task<EventResponse> GetEventByIdAsync(int eventId)
    {
        var eventEntity = await _context.Events
            .Include(e => e.Organizer)
            .Include(e => e.SportCategory)
            .Include(e => e.Participants)
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.EventId == eventId);

        if (eventEntity == null)
        {
            throw new KeyNotFoundException("Event not found.");
        }

        return MapToEventResponse(eventEntity);
    }

    public async Task<EventResponse> UpdateEventAsync(int eventId, UpdateEventRequest request, int currentUserId)
    {
        var user = await _context.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == currentUserId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        if (user.IsBlocked)
        {
            throw new UnauthorizedAccessException("Blocked users cannot update events.");
        }

        var eventEntity = await _context.Events
            .Include(e => e.Organizer)
            .Include(e => e.SportCategory)
            .Include(e => e.Participants)
            .FirstOrDefaultAsync(e => e.EventId == eventId);

        if (eventEntity == null)
        {
            throw new KeyNotFoundException("Event not found.");
        }

        if (eventEntity.OrganizerId != currentUserId)
        {
            throw new UnauthorizedAccessException("You are not authorized to update this event.");
        }

        if (eventEntity.Status == EventStatus.Cancelled || eventEntity.Status == EventStatus.Completed)
        {
            throw new InvalidOperationException($"Cannot update {eventEntity.Status.ToString().ToLower()} event.");
        }

        var sportCategoryChanged = request.SportCategoryId != eventEntity.SportCategoryId;
        if (sportCategoryChanged)
        {
            var sportCategoryExists = await _context.SportCategories
                .AnyAsync(sc => sc.SportCategoryId == request.SportCategoryId);

            if (!sportCategoryExists)
            {
                throw new KeyNotFoundException("Sport category not found.");
            }
        }

        var currentParticipantCount = eventEntity.Participants.Count;
        if (request.MaxParticipants < currentParticipantCount)
        {
            throw new InvalidOperationException($"Cannot reduce maximum participants to {request.MaxParticipants}. Current participant count is {currentParticipantCount}.");
        }

        eventEntity.Title = request.Title;
        eventEntity.Description = request.Description;
        eventEntity.SportCategoryId = request.SportCategoryId;
        eventEntity.EventDate = DateTime.SpecifyKind(request.EventDate, DateTimeKind.Utc);
        eventEntity.DurationMinutes = request.DurationMinutes;
        eventEntity.MaxParticipants = request.MaxParticipants;
        eventEntity.Address = request.Address;
        eventEntity.Latitude = request.Latitude ?? eventEntity.Latitude;
        eventEntity.Longitude = request.Longitude ?? eventEntity.Longitude;

        await _context.SaveChangesAsync();

        if (sportCategoryChanged)
        {
            await _context.Entry(eventEntity)
                .Reference(e => e.SportCategory)
                .LoadAsync();
        }

        return MapToEventResponse(eventEntity);
    }

    public async Task CancelEventAsync(int eventId, int currentUserId)
    {
        var user = await _context.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == currentUserId);

        if (user == null)
        {
            throw new KeyNotFoundException("User not found.");
        }

        if (user.IsBlocked)
        {
            throw new UnauthorizedAccessException("Blocked users cannot cancel events.");
        }

        var eventEntity = await _context.Events
            .FirstOrDefaultAsync(e => e.EventId == eventId);

        if (eventEntity == null)
        {
            throw new KeyNotFoundException("Event not found.");
        }

        if (eventEntity.OrganizerId != currentUserId)
        {
            throw new UnauthorizedAccessException("You are not authorized to cancel this event.");
        }

        if (eventEntity.Status == EventStatus.Completed)
        {
            throw new InvalidOperationException("Cannot cancel a completed event.");
        }

        eventEntity.Status = EventStatus.Cancelled;

        await _context.SaveChangesAsync();
    }

    private EventResponse MapToEventResponse(Event eventEntity)
    {
        var participantCount = eventEntity.Participants.Count;

        return new EventResponse
        {
            EventId = eventEntity.EventId,
            Title = eventEntity.Title,
            Description = eventEntity.Description,
            Address = eventEntity.Address,
            Latitude = eventEntity.Latitude,
            Longitude = eventEntity.Longitude,
            EventDate = eventEntity.EventDate,
            DurationMinutes = eventEntity.DurationMinutes,
            MaxParticipants = eventEntity.MaxParticipants,
            Status = eventEntity.Status,
            CreatedAt = eventEntity.CreatedAt,
            Organizer = new OrganizerInfo
            {
                UserId = eventEntity.Organizer.Id,
                FirstName = eventEntity.Organizer.FirstName,
                LastName = eventEntity.Organizer.LastName,
                AvatarId = eventEntity.Organizer.AvatarId,
                Rating = eventEntity.Organizer.Rating
            },
            SportCategory = new SportCategoryInfo
            {
                SportCategoryId = eventEntity.SportCategory.SportCategoryId,
                Name = eventEntity.SportCategory.Name,
                ImagePath = eventEntity.SportCategory.ImagePath
            },
            ParticipantCount = participantCount,
            FreeSlots = Math.Max(0, eventEntity.MaxParticipants - participantCount)
        };
    }
}
