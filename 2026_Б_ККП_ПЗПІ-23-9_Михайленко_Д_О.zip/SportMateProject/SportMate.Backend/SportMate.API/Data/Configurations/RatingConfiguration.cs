using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SportMate.API.Entities;

namespace SportMate.API.Data.Configurations;

public class RatingConfiguration : IEntityTypeConfiguration<Rating>
{
    public void Configure(EntityTypeBuilder<Rating> builder)
    {
        builder.HasKey(r => r.RatingId);

        builder.Property(r => r.Score)
            .IsRequired();

        builder.Property(r => r.Comment)
            .HasMaxLength(1000);

        builder.Property(r => r.CreatedAt)
            .IsRequired();

        builder.Property(r => r.EventId)
            .IsRequired();

        builder.Property(r => r.AuthorId)
            .IsRequired();

        builder.Property(r => r.TargetUserId)
            .IsRequired();

        builder.ToTable(t => t.HasCheckConstraint("CK_Rating_Score", "\"Score\" >= 1 AND \"Score\" <= 5"));

        builder.HasIndex(r => new { r.EventId, r.AuthorId, r.TargetUserId })
            .IsUnique();
    }
}
