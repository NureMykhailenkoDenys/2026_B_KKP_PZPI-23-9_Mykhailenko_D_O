using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SportMate.API.Entities;

namespace SportMate.API.Data.Configurations;

public class EventParticipantConfiguration : IEntityTypeConfiguration<EventParticipant>
{
    public void Configure(EntityTypeBuilder<EventParticipant> builder)
    {
        builder.HasKey(ep => ep.EventParticipantId);

        builder.Property(ep => ep.JoinedAt)
            .IsRequired();

        builder.Property(ep => ep.UserId)
            .IsRequired();

        builder.Property(ep => ep.EventId)
            .IsRequired();

        builder.HasIndex(ep => new { ep.UserId, ep.EventId })
            .IsUnique();
    }
}
