using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SportMate.API.Entities;

namespace SportMate.API.Data.Configurations;

public class SportCategoryConfiguration : IEntityTypeConfiguration<SportCategory>
{
    public void Configure(EntityTypeBuilder<SportCategory> builder)
    {
        builder.HasKey(sc => sc.SportCategoryId);

        builder.Property(sc => sc.Name)
            .IsRequired()
            .HasMaxLength(100);

        builder.HasIndex(sc => sc.Name)
            .IsUnique();

        builder.Property(sc => sc.ImagePath)
            .HasMaxLength(500);

        builder.HasMany(sc => sc.Events)
            .WithOne(e => e.SportCategory)
            .HasForeignKey(e => e.SportCategoryId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasData(
            new SportCategory { SportCategoryId = 1, Name = "Football", ImagePath = "/images/sports/football.png" },
            new SportCategory { SportCategoryId = 2, Name = "Basketball", ImagePath = "/images/sports/basketball.png" },
            new SportCategory { SportCategoryId = 3, Name = "Volleyball", ImagePath = "/images/sports/volleyball.png" },
            new SportCategory { SportCategoryId = 4, Name = "Tennis", ImagePath = "/images/sports/tennis.png" },
            new SportCategory { SportCategoryId = 5, Name = "Running", ImagePath = "/images/sports/running.png" },
            new SportCategory { SportCategoryId = 6, Name = "Swimming", ImagePath = "/images/sports/swimming.png" },
            new SportCategory { SportCategoryId = 7, Name = "Cycling", ImagePath = "/images/sports/cycling.png" },
            new SportCategory { SportCategoryId = 8, Name = "Gym", ImagePath = "/images/sports/gym.png" },
            new SportCategory { SportCategoryId = 9, Name = "Table Tennis", ImagePath = "/images/sports/table-tennis.png" }
        );
    }
}
