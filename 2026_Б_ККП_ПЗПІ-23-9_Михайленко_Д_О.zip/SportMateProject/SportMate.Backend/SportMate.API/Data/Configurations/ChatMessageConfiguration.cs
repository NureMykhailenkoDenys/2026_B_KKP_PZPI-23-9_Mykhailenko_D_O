using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SportMate.API.Entities;

namespace SportMate.API.Data.Configurations;

public class ChatMessageConfiguration : IEntityTypeConfiguration<ChatMessage>
{
    public void Configure(EntityTypeBuilder<ChatMessage> builder)
    {
        builder.HasKey(cm => cm.ChatMessageId);

        builder.Property(cm => cm.MessageText)
            .IsRequired()
            .HasMaxLength(2000);

        builder.Property(cm => cm.SentAt)
            .IsRequired();

        builder.Property(cm => cm.UserId)
            .IsRequired();

        builder.Property(cm => cm.EventId)
            .IsRequired();
    }
}
