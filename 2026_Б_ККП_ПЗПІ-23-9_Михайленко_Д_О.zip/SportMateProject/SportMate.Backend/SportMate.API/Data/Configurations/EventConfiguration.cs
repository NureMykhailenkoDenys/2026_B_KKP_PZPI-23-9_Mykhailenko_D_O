using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SportMate.API.Entities;
using SportMate.API.Entities.Enums;

namespace SportMate.API.Data.Configurations;

public class EventConfiguration : IEntityTypeConfiguration<Event>
{
    public void Configure(EntityTypeBuilder<Event> builder)
    {
        builder.HasKey(e => e.EventId);

        builder.Property(e => e.Title)
            .IsRequired()
            .HasMaxLength(200);

        builder.Property(e => e.Description)
            .HasMaxLength(2000);

        builder.Property(e => e.Address)
            .IsRequired()
            .HasMaxLength(500);

        builder.Property(e => e.Latitude)
            .IsRequired();

        builder.Property(e => e.Longitude)
            .IsRequired();

        builder.Property(e => e.EventDate)
            .IsRequired();

        builder.Property(e => e.DurationMinutes)
            .IsRequired();

        builder.Property(e => e.MaxParticipants)
            .IsRequired();

        builder.Property(e => e.Status)
            .IsRequired()
            .HasDefaultValue(EventStatus.Planned);

        builder.Property(e => e.CreatedAt)
            .IsRequired();

        builder.Property(e => e.OrganizerId)
            .IsRequired();

        builder.Property(e => e.SportCategoryId)
            .IsRequired();

        builder.ToTable(t => t.HasCheckConstraint("CK_Event_DurationMinutes", "\"DurationMinutes\" > 0"));
        builder.ToTable(t => t.HasCheckConstraint("CK_Event_MaxParticipants", "\"MaxParticipants\" > 0"));
        builder.ToTable(t => t.HasCheckConstraint("CK_Event_Latitude", "\"Latitude\" >= -90 AND \"Latitude\" <= 90"));
        builder.ToTable(t => t.HasCheckConstraint("CK_Event_Longitude", "\"Longitude\" >= -180 AND \"Longitude\" <= 180"));

        builder.HasMany(e => e.Participants)
            .WithOne(ep => ep.Event)
            .HasForeignKey(ep => ep.EventId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasMany(e => e.ChatMessages)
            .WithOne(cm => cm.Event)
            .HasForeignKey(cm => cm.EventId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasMany(e => e.Ratings)
            .WithOne(r => r.Event)
            .HasForeignKey(r => r.EventId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
