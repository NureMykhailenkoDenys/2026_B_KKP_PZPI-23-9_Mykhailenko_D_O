namespace SportMate.API.DTOs.Users;

public class UpdateProfileRequest
{
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public int? AvatarId { get; set; }
    public string? Password { get; set; }
}
