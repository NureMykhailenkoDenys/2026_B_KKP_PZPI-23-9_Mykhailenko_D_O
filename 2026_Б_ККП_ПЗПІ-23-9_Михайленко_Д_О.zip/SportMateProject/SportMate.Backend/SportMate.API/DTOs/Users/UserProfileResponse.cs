using SportMate.API.DTOs.Events;

namespace SportMate.API.DTOs.Users;

public class UserProfileResponse
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public int? AvatarId { get; set; }
    public double Rating { get; set; }
    public string Role { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }

    /// <summary>
    /// Number of distinct events (organized or participated in) that have reached Completed status.
    /// An event where the user is both organizer and participant is counted only once.
    /// </summary>
    public int CompletedEventsCount { get; set; }

    /// <summary>
    /// Events created by this user as organizer.
    /// </summary>
    public List<EventListItemResponse> OrganizedEvents { get; set; } = new();

    /// <summary>
    /// Events this user takes part in (includes events they organize, since the organizer
    /// is automatically registered as a participant).
    /// </summary>
    public List<EventListItemResponse> ParticipatingEvents { get; set; } = new();
}
