using SportMate.API.DTOs.Events;

namespace SportMate.API.DTOs.Users;

public class PublicUserProfileResponse
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public int? AvatarId { get; set; }
    public double Rating { get; set; }

    /// <summary>
    /// Events created by this user as organizer. Same public shape as
    /// UserProfileResponse.OrganizedEvents.
    /// </summary>
    public List<EventListItemResponse> OrganizedEvents { get; set; } = new();

    /// <summary>
    /// Events this user takes part in (includes events they organize, since the organizer
    /// is automatically registered as a participant). Same public shape as
    /// UserProfileResponse.ParticipatingEvents.
    /// </summary>
    public List<EventListItemResponse> ParticipatingEvents { get; set; } = new();
}
