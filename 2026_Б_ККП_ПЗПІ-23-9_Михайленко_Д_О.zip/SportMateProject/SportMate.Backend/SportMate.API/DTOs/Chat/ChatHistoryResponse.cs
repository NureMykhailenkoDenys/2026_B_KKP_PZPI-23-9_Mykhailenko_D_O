namespace SportMate.API.DTOs.Chat;

public class ChatHistoryResponse
{
    public List<ChatMessageResponse> Items { get; set; } = new();
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
}
