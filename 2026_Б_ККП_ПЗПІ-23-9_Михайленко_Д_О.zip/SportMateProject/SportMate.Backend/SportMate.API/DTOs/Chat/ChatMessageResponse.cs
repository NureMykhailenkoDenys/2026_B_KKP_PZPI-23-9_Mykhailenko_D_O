namespace SportMate.API.DTOs.Chat;

public class ChatMessageResponse
{
    public int ChatMessageId { get; set; }
    public int EventId { get; set; }
    public int UserId { get; set; }
    public string SenderName { get; set; } = null!;
    public int? AvatarId { get; set; }
    public string MessageText { get; set; } = null!;
    public DateTime SentAt { get; set; }
}
