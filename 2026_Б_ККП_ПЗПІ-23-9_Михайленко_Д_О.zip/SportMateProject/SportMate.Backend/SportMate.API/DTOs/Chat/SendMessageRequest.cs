namespace SportMate.API.DTOs.Chat;

public class SendMessageRequest
{
    public string MessageText { get; set; } = null!;
}
