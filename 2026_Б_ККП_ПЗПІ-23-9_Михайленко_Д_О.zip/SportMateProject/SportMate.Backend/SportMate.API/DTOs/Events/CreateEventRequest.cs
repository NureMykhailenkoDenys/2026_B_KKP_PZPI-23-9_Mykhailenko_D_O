namespace SportMate.API.DTOs.Events;

public class CreateEventRequest
{
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int SportCategoryId { get; set; }
    public DateTime EventDate { get; set; }
    public int DurationMinutes { get; set; }
    public int MaxParticipants { get; set; }
    public string Address { get; set; } = string.Empty;
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
}
