using SportMate.API.Entities.Enums;

namespace SportMate.API.DTOs.Events;

public class EventResponse
{
    public int EventId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Address { get; set; } = string.Empty;
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
    public DateTime EventDate { get; set; }
    public int DurationMinutes { get; set; }
    public int MaxParticipants { get; set; }
    public EventStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
    public OrganizerInfo Organizer { get; set; } = null!;
    public SportCategoryInfo SportCategory { get; set; } = null!;
    public int ParticipantCount { get; set; }
    public int FreeSlots { get; set; }
}

public class OrganizerInfo
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public int? AvatarId { get; set; }
    public double Rating { get; set; }
}

public class SportCategoryInfo
{
    public int SportCategoryId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ImagePath { get; set; }
}
