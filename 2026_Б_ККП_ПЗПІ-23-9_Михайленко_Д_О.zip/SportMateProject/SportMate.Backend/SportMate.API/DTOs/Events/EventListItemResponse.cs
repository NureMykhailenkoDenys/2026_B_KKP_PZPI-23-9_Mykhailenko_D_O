using SportMate.API.Entities.Enums;

namespace SportMate.API.DTOs.Events;

public class EventListItemResponse
{
    public int EventId { get; set; }
    public string Title { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public int DurationMinutes { get; set; }
    public string Address { get; set; } = string.Empty;
    public SportCategoryInfo SportCategory { get; set; } = null!;
    public EventStatus Status { get; set; }
    public int MaxParticipants { get; set; }
    public int ParticipantCount { get; set; }
    public int FreeSlots { get; set; }
}
