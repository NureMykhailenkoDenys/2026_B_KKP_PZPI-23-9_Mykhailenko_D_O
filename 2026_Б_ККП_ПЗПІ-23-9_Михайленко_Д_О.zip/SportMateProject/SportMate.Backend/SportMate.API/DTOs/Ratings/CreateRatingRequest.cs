namespace SportMate.API.DTOs.Ratings;

public class CreateRatingRequest
{
    public int EventId { get; set; }
    public int TargetUserId { get; set; }
    public int Score { get; set; }
    public string? Comment { get; set; }
}
