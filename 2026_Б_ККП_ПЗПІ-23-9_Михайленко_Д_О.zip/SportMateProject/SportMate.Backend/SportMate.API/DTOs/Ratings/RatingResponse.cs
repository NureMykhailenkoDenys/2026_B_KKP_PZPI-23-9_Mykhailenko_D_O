namespace SportMate.API.DTOs.Ratings;

public class RatingResponse
{
    public int RatingId { get; set; }
    public int EventId { get; set; }
    public RatingUserInfo Author { get; set; } = null!;
    public RatingUserInfo TargetUser { get; set; } = null!;
    public int Score { get; set; }
    public string? Comment { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class RatingUserInfo
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = null!;
    public string LastName { get; set; } = null!;
    public int? AvatarId { get; set; }
    public double Rating { get; set; }
}
