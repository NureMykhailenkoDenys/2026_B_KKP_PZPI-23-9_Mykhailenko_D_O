namespace SportMate.API.DTOs.Participation;

public class JoinEventResponse
{
    public int EventId { get; set; }
    public int UserId { get; set; }
    public int ParticipantCount { get; set; }
    public int MaxParticipants { get; set; }
    public int FreeSlots { get; set; }
    public DateTime JoinedAt { get; set; }
}
