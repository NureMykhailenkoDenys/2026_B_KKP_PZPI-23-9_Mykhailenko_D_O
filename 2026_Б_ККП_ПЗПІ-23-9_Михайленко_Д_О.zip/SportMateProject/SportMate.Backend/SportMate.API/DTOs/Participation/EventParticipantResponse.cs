namespace SportMate.API.DTOs.Participation;

/// <summary>
/// Public participant info for an event's participant list.
/// Deliberately excludes Email, PasswordHash, Role, IsBlocked and any
/// other private/user-management fields — only what is safe to show
/// to anyone browsing the event (same fields already public via
/// EventResponse.Organizer).
/// </summary>
public class EventParticipantResponse
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public int? AvatarId { get; set; }
    public double Rating { get; set; }
    public DateTime JoinedAt { get; set; }
}
