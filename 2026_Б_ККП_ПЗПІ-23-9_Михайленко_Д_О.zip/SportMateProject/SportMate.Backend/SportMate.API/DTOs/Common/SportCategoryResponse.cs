namespace SportMate.API.DTOs.Common;

public class SportCategoryResponse
{
    public int SportCategoryId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ImagePath { get; set; }
}
