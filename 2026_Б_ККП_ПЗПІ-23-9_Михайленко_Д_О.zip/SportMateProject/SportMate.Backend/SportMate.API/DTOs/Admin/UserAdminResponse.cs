using SportMate.API.Entities.Enums;

namespace SportMate.API.DTOs.Admin;

public class UserAdminResponse
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = null!;
    public string LastName { get; set; } = null!;
    public string Email { get; set; } = null!;
    public int? AvatarId { get; set; }
    public string Role { get; set; } = null!;
    public double Rating { get; set; }
    public bool IsBlocked { get; set; }
    public DateTime CreatedAt { get; set; }
}
