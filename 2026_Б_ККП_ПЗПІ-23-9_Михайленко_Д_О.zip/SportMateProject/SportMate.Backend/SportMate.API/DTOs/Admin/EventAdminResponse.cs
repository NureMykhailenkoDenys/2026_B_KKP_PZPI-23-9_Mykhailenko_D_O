using SportMate.API.Entities.Enums;

namespace SportMate.API.DTOs.Admin;

public class EventAdminResponse
{
    public int EventId { get; set; }
    public string Title { get; set; } = null!;
    public DateTime EventDate { get; set; }
    public EventStatus Status { get; set; }
    public OrganizerInfo Organizer { get; set; } = null!;
    public SportCategoryInfo SportCategory { get; set; } = null!;
    public int ParticipantCount { get; set; }
    public int MaxParticipants { get; set; }
}

public class OrganizerInfo
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = null!;
    public string LastName { get; set; } = null!;
}

public class SportCategoryInfo
{
    public int SportCategoryId { get; set; }
    public string Name { get; set; } = null!;
}
