using System.Net;
using System.Text.Json;
using Npgsql;

namespace SportMate.API.Middleware;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var correlationId = context.TraceIdentifier;

        _logger.LogError(exception,
            "Unhandled exception occurred. Method: {Method}, Path: {Path}, CorrelationId: {CorrelationId}",
            context.Request.Method,
            context.Request.Path,
            correlationId);

        var (statusCode, message) = MapExceptionToResponse(exception);

        var response = new ErrorResponse
        {
            StatusCode = statusCode,
            Message = message,
            Timestamp = DateTime.UtcNow,
            CorrelationId = correlationId
        };

        context.Response.ContentType = "application/json";
        context.Response.StatusCode = statusCode;

        context.Response.Headers.Append("X-Correlation-Id", correlationId);

        var jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        await context.Response.WriteAsync(JsonSerializer.Serialize(response, jsonOptions));
    }

    private (int statusCode, string message) MapExceptionToResponse(Exception exception)
    {
        return exception switch
        {
            ArgumentException => (400, "Invalid request parameters."),
            InvalidOperationException ex when ex.Message.Contains("already rated") => (409, "You have already rated this user for this event."),
            InvalidOperationException => (400, GetSafeMessage(exception.Message)),

            UnauthorizedAccessException ex when ex.Message.Contains("User ID not found") => (401, "Authentication required."),
            UnauthorizedAccessException ex when ex.Message.Contains("Invalid email or password") => (401, "Invalid email or password."),
            UnauthorizedAccessException ex when ex.Message.Contains("Invalid credentials") => (401, "Invalid credentials."),
            UnauthorizedAccessException ex when ex.Message.Contains("blocked") || ex.Message.Contains("Blocked") => (403, "Access denied. Your account has been blocked."),

            UnauthorizedAccessException => (403, "You do not have permission to perform this action."),

            KeyNotFoundException => (404, "The requested resource was not found."),

            NpgsqlException or PostgresException => (500, "A database error occurred. Please try again later."),

            _ => (500, "An unexpected error occurred.")
        };
    }

    private string GetSafeMessage(string originalMessage)
    {
        var safePatterns = new[]
        {
            "Email already in use",
            "Sport category not found",
            "Event not found",
            "User not found",
            "Event is already cancelled",
            "Event is already full",
            "You are already a participant",
            "You are not a participant",
            "Cannot leave event after it has started",
            "Cannot cancel event after it has started",
            "Cannot update event after it has started",
            "You can only rate users who participated in the event",
            "You cannot rate yourself",
            "You cannot rate the organizer",
            "Event must be completed to rate participants",
            "Administrator cannot block themselves",
            "cannot create events",
            "cannot update events",
            "cannot cancel events",
            "cannot join events",
            "cannot leave events",
            "cannot send messages",
            "cannot rate"
        };

        foreach (var pattern in safePatterns)
        {
            if (originalMessage.Contains(pattern, StringComparison.OrdinalIgnoreCase))
            {
                return originalMessage;
            }
        }

        return "The operation could not be completed.";
    }
}

public class ErrorResponse
{
    public int StatusCode { get; set; }
    public string Message { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; }
    public string CorrelationId { get; set; } = string.Empty;
}
