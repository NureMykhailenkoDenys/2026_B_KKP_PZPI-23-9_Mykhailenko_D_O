using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using SportMate.API.DTOs.Chat;
using SportMate.API.Services.Interfaces;
using System.Security.Claims;

namespace SportMate.API.Hubs;

[Authorize]
public class EventChatHub : Hub
{
    private readonly IChatService _chatService;
    private readonly ILogger<EventChatHub> _logger;

    public EventChatHub(IChatService chatService, ILogger<EventChatHub> logger)
    {
        _chatService = chatService;
        _logger = logger;
    }

    public async Task JoinEventChat(int eventId)
    {
        var userId = GetUserId();

        if (!await _chatService.IsUserParticipantAsync(eventId, userId))
        {
            _logger.LogWarning("User {UserId} attempted to join Event {EventId} chat but is not a participant.", userId, eventId);
            throw new HubException("You are not a participant of this event.");
        }

        var groupName = GetGroupName(eventId);
        await Groups.AddToGroupAsync(Context.ConnectionId, groupName);

        _logger.LogInformation("User {UserId} joined Event {EventId} chat.", userId, eventId);
    }

    public async Task LeaveEventChat(int eventId)
    {
        var userId = GetUserId();
        var groupName = GetGroupName(eventId);

        await Groups.RemoveFromGroupAsync(Context.ConnectionId, groupName);

        _logger.LogInformation("User {UserId} left Event {EventId} chat.", userId, eventId);
    }

    public async Task SendMessage(int eventId, SendMessageRequest request)
    {
        var userId = GetUserId();

        try
        {
            if (string.IsNullOrWhiteSpace(request.MessageText))
            {
                throw new HubException("Message text cannot be empty.");
            }

            if (request.MessageText.Length > 2000)
            {
                throw new HubException("Message text cannot exceed 2000 characters.");
            }

            var messageResponse = await _chatService.SaveMessageAsync(eventId, userId, request.MessageText);

            var groupName = GetGroupName(eventId);
            await Clients.Group(groupName).SendAsync("ReceiveMessage", messageResponse);

            _logger.LogInformation("Message {MessageId} broadcasted to Event {EventId} chat.", messageResponse.ChatMessageId, eventId);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogWarning("User {UserId} unauthorized to send message to Event {EventId}: {Message}", userId, eventId, ex.Message);
            throw new HubException(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogWarning("Invalid operation for User {UserId} sending message to Event {EventId}: {Message}", userId, eventId, ex.Message);
            throw new HubException(ex.Message);
        }
    }

    public override async Task OnConnectedAsync()
    {
        var userId = GetUserId();
        _logger.LogInformation("User {UserId} connected to chat hub. ConnectionId: {ConnectionId}", userId, Context.ConnectionId);
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        var userId = GetUserId();
        if (exception != null)
        {
            _logger.LogError(exception, "User {UserId} disconnected with error. ConnectionId: {ConnectionId}", userId, Context.ConnectionId);
        }
        else
        {
            _logger.LogInformation("User {UserId} disconnected from chat hub. ConnectionId: {ConnectionId}", userId, Context.ConnectionId);
        }
        await base.OnDisconnectedAsync(exception);
    }

    private int GetUserId()
    {
        var userIdClaim = Context.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userIdClaim == null || !int.TryParse(userIdClaim, out var userId))
        {
            throw new HubException("User ID not found in token.");
        }
        return userId;
    }

    private static string GetGroupName(int eventId)
    {
        return $"event-{eventId}";
    }
}
