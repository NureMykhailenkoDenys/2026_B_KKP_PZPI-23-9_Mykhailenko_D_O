using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportMate.API.DTOs.Admin;
using SportMate.API.Services.Interfaces;
using System.Security.Claims;

namespace SportMate.API.Controllers;

/// <summary>
/// Admin panel endpoints for user and event moderation (Administrator role required)
/// </summary>
[ApiController]
[Route("api/admin")]
[Authorize(Roles = "Administrator")]
public class AdminController : ControllerBase
{
    private readonly IAdminService _adminService;

    public AdminController(IAdminService adminService)
    {
        _adminService = adminService;
    }

    /// <summary>
    /// Get list of all users with admin details
    /// </summary>
    /// <returns>List of all users</returns>
    /// <response code="200">Returns list of users</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User does not have Administrator role</response>
    [HttpGet("users")]
    [ProducesResponseType(typeof(List<UserAdminResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<List<UserAdminResponse>>> GetUsers()
    {
        var users = await _adminService.GetUsersAsync();
        return Ok(users);
    }

    /// <summary>
    /// Block a user account (prevents login and participation)
    /// </summary>
    /// <param name="id">User ID to block</param>
    /// <returns>No content on success</returns>
    /// <response code="204">User successfully blocked</response>
    /// <response code="400">Cannot block administrator or user already blocked</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User does not have Administrator role</response>
    /// <response code="404">User not found</response>
    [HttpPut("users/{id}/block")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> BlockUser(int id)
    {
        var adminId = GetUserId();
        await _adminService.BlockUserAsync(id, adminId);
        return NoContent();
    }

    /// <summary>
    /// Unblock a previously blocked user account
    /// </summary>
    /// <param name="id">User ID to unblock</param>
    /// <returns>No content on success</returns>
    /// <response code="204">User successfully unblocked</response>
    /// <response code="400">User is not blocked</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User does not have Administrator role</response>
    /// <response code="404">User not found</response>
    [HttpPut("users/{id}/unblock")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UnblockUser(int id)
    {
        await _adminService.UnblockUserAsync(id);
        return NoContent();
    }

    /// <summary>
    /// Get list of all events with admin details
    /// </summary>
    /// <returns>List of all events</returns>
    /// <response code="200">Returns list of events</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User does not have Administrator role</response>
    [HttpGet("events")]
    [ProducesResponseType(typeof(List<EventAdminResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<List<EventAdminResponse>>> GetEvents()
    {
        var events = await _adminService.GetEventsAsync();
        return Ok(events);
    }

    /// <summary>
    /// Permanently delete an event (hard delete from database)
    /// </summary>
    /// <param name="id">Event ID to delete</param>
    /// <returns>No content on success</returns>
    /// <response code="204">Event successfully deleted</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User does not have Administrator role</response>
    /// <response code="404">Event not found</response>
    [HttpDelete("events/{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        await _adminService.DeleteEventAsync(id);
        return NoContent();
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out var userId))
        {
            throw new UnauthorizedAccessException("User ID not found in token.");
        }
        return userId;
    }
}
