using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportMate.API.DTOs.Users;
using SportMate.API.Extensions;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Controllers;

/// <summary>
/// User profile management endpoints
/// </summary>
[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly IUserService _userService;
    private readonly ILogger<UsersController> _logger;

    public UsersController(IUserService userService, ILogger<UsersController> logger)
    {
        _userService = userService;
        _logger = logger;
    }

    /// <summary>
    /// Get current authenticated user's profile
    /// </summary>
    /// <returns>Current user's profile information</returns>
    /// <response code="200">Returns the current user's profile</response>
    /// <response code="401">User is not authenticated</response>
    [HttpGet("me")]
    [Authorize]
    [ProducesResponseType(typeof(UserProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UserProfileResponse>> GetCurrentUserProfile()
    {
        var userId = User.GetUserId();
        var profile = await _userService.GetCurrentUserProfileAsync(userId);
        return Ok(profile);
    }

    /// <summary>
    /// Update current authenticated user's profile
    /// </summary>
    /// <param name="request">Updated profile information</param>
    /// <returns>Updated user profile</returns>
    /// <response code="200">Profile successfully updated</response>
    /// <response code="400">Invalid request data</response>
    /// <response code="401">User is not authenticated</response>
    [HttpPut("me")]
    [Authorize]
    [ProducesResponseType(typeof(UserProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UserProfileResponse>> UpdateCurrentUserProfile([FromBody] UpdateProfileRequest request)
    {
        var userId = User.GetUserId();
        var profile = await _userService.UpdateCurrentUserProfileAsync(userId, request);
        return Ok(profile);
    }

    /// <summary>
    /// Get public profile of any user by ID
    /// </summary>
    /// <param name="id">User ID</param>
    /// <returns>Public profile information</returns>
    /// <response code="200">Returns the user's public profile</response>
    /// <response code="404">User not found</response>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(PublicUserProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<PublicUserProfileResponse>> GetPublicUserProfile(int id)
    {
        var profile = await _userService.GetPublicUserProfileAsync(id);
        return Ok(profile);
    }
}
