using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportMate.API.DTOs.Ratings;
using SportMate.API.Services.Interfaces;
using System.Security.Claims;

namespace SportMate.API.Controllers;

/// <summary>
/// Rating system endpoints for providing feedback on event participants
/// </summary>
[ApiController]
[Route("api/ratings")]
[Authorize]
public class RatingsController : ControllerBase
{
    private readonly IRatingService _ratingService;
    private readonly ILogger<RatingsController> _logger;

    public RatingsController(IRatingService ratingService, ILogger<RatingsController> logger)
    {
        _ratingService = ratingService;
        _logger = logger;
    }

    /// <summary>
    /// Create a rating for an event participant
    /// </summary>
    /// <param name="request">Rating details including event ID, target user ID, score (1-5), and optional comment</param>
    /// <returns>Created rating details</returns>
    /// <response code="201">Rating successfully created</response>
    /// <response code="400">Invalid data, user not a participant, or duplicate rating</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="404">Event or target user not found</response>
    [HttpPost]
    [ProducesResponseType(typeof(RatingResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> CreateRating([FromBody] CreateRatingRequest request)
    {
        var authorId = GetUserId();
        var rating = await _ratingService.CreateRatingAsync(authorId, request);
        return StatusCode(201, rating);
    }

    /// <summary>
    /// Get all ratings for a specific event
    /// </summary>
    /// <param name="eventId">Event ID</param>
    /// <returns>List of ratings for the event</returns>
    /// <response code="200">Returns list of event ratings</response>
    /// <response code="404">Event not found</response>
    [HttpGet("event/{eventId}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<RatingResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventRatings(int eventId)
    {
        var ratings = await _ratingService.GetEventRatingsAsync(eventId);
        return Ok(ratings);
    }

    /// <summary>
    /// Get all ratings received by a specific user
    /// </summary>
    /// <param name="userId">User ID</param>
    /// <returns>List of ratings received by the user</returns>
    /// <response code="200">Returns list of user ratings</response>
    /// <response code="404">User not found</response>
    [HttpGet("user/{userId}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<RatingResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetUserReceivedRatings(int userId)
    {
        var ratings = await _ratingService.GetUserReceivedRatingsAsync(userId);
        return Ok(ratings);
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userIdClaim == null || !int.TryParse(userIdClaim, out var userId))
        {
            throw new UnauthorizedAccessException("User ID not found in token.");
        }
        return userId;
    }
}
