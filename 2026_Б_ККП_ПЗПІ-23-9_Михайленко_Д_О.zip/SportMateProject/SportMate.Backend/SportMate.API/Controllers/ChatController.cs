using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportMate.API.DTOs.Chat;
using SportMate.API.Services.Interfaces;
using System.Security.Claims;

namespace SportMate.API.Controllers;

/// <summary>
/// Chat message history endpoints. Real-time messaging is handled via SignalR at /hubs/event-chat
/// </summary>
[ApiController]
[Route("api/events/{eventId}/chat")]
[Authorize]
public class ChatController : ControllerBase
{
    private readonly IChatService _chatService;
    private readonly ILogger<ChatController> _logger;

    public ChatController(IChatService chatService, ILogger<ChatController> logger)
    {
        _chatService = chatService;
        _logger = logger;
    }

    /// <summary>
    /// Get paginated chat message history for an event (participant-only access)
    /// </summary>
    /// <param name="eventId">Event ID</param>
    /// <param name="page">Page number (default: 1)</param>
    /// <param name="pageSize">Messages per page (default: 50, max: 100)</param>
    /// <returns>Paginated chat history</returns>
    /// <response code="200">Returns chat message history</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User is not a participant of this event</response>
    /// <response code="404">Event not found</response>
    /// <remarks>
    /// For real-time messaging, connect to SignalR hub at /hubs/event-chat
    /// </remarks>
    [HttpGet("messages")]
    [ProducesResponseType(typeof(ChatHistoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetChatHistory(
        int eventId,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50)
    {
        var userId = GetUserId();
        var history = await _chatService.GetChatHistoryAsync(eventId, userId, page, pageSize);
        return Ok(history);
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userIdClaim == null || !int.TryParse(userIdClaim, out var userId))
        {
            throw new UnauthorizedAccessException("User ID not found in token.");
        }
        return userId;
    }
}
