using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportMate.API.DTOs.Events;
using SportMate.API.Entities.Enums;
using SportMate.API.Extensions;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Controllers;

/// <summary>
/// Event management endpoints for creating, browsing, and managing sports events
/// </summary>
[ApiController]
[Route("api/events")]
public class EventsController : ControllerBase
{
    private readonly IEventService _eventService;
    private readonly ILogger<EventsController> _logger;

    public EventsController(IEventService eventService, ILogger<EventsController> logger)
    {
        _eventService = eventService;
        _logger = logger;
    }

    /// <summary>
    /// Create a new sports event
    /// </summary>
    /// <param name="request">Event details including sport category, date, location, and participant limits</param>
    /// <returns>Created event details</returns>
    /// <response code="201">Event successfully created</response>
    /// <response code="400">Invalid request data</response>
    /// <response code="401">User is not authenticated</response>
    [HttpPost]
    [Authorize]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<EventResponse>> CreateEvent([FromBody] CreateEventRequest request)
    {
        var organizerId = User.GetUserId();
        var eventResponse = await _eventService.CreateEventAsync(request, organizerId);
        return CreatedAtAction(nameof(GetEventById), new { id = eventResponse.EventId }, eventResponse);
    }

    /// <summary>
    /// Get list of events with optional filters
    /// </summary>
    /// <param name="sportCategoryId">Filter by sport category ID</param>
    /// <param name="status">Filter by event status (Planned=0, Active=1, Completed=2, Cancelled=3)</param>
    /// <param name="date">Filter by event date</param>
    /// <param name="address">Filter by location address</param>
    /// <returns>List of events matching the filters</returns>
    /// <response code="200">Returns filtered list of events</response>
    [HttpGet]
    [ProducesResponseType(typeof(List<EventListItemResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<EventListItemResponse>>> GetEvents(
        [FromQuery] int? sportCategoryId,
        [FromQuery] EventStatus? status,
        [FromQuery] DateTime? date,
        [FromQuery] string? address)
    {
        var events = await _eventService.GetEventsAsync(sportCategoryId, status, date, address);
        return Ok(events);
    }

    /// <summary>
    /// Get detailed information about a specific event
    /// </summary>
    /// <param name="id">Event ID</param>
    /// <returns>Detailed event information including organizer and participants</returns>
    /// <response code="200">Returns event details</response>
    /// <response code="404">Event not found</response>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> GetEventById(int id)
    {
        var eventResponse = await _eventService.GetEventByIdAsync(id);
        return Ok(eventResponse);
    }

    /// <summary>
    /// Update an existing event (organizer only)
    /// </summary>
    /// <param name="id">Event ID</param>
    /// <param name="request">Updated event information</param>
    /// <returns>Updated event details</returns>
    /// <response code="200">Event successfully updated</response>
    /// <response code="400">Invalid request data</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User is not the event organizer</response>
    /// <response code="404">Event not found</response>
    [HttpPut("{id}")]
    [Authorize]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> UpdateEvent(int id, [FromBody] UpdateEventRequest request)
    {
        var currentUserId = User.GetUserId();
        var eventResponse = await _eventService.UpdateEventAsync(id, request, currentUserId);
        return Ok(eventResponse);
    }

    /// <summary>
    /// Cancel an event (organizer only)
    /// </summary>
    /// <param name="id">Event ID</param>
    /// <returns>No content on success</returns>
    /// <response code="204">Event successfully cancelled</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User is not the event organizer</response>
    /// <response code="404">Event not found</response>
    [HttpDelete("{id}")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> CancelEvent(int id)
    {
        var currentUserId = User.GetUserId();
        await _eventService.CancelEventAsync(id, currentUserId);
        return NoContent();
    }
}
