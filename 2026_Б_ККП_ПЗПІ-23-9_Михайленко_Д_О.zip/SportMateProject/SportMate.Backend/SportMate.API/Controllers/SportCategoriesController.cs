using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportMate.API.DTOs.Common;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Controllers;

/// <summary>
/// Sport categories endpoints for browsing available sports
/// </summary>
[ApiController]
[Route("api/sport-categories")]
public class SportCategoriesController : ControllerBase
{
    private readonly ISportCategoryService _sportCategoryService;
    private readonly ILogger<SportCategoriesController> _logger;

    public SportCategoriesController(
        ISportCategoryService sportCategoryService,
        ILogger<SportCategoriesController> logger)
    {
        _sportCategoryService = sportCategoryService;
        _logger = logger;
    }

    /// <summary>
    /// Get list of all available sport categories
    /// </summary>
    /// <returns>List of sport categories</returns>
    /// <response code="200">Returns list of all sport categories</response>
    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<SportCategoryResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<SportCategoryResponse>>> GetAllCategories()
    {
        var categories = await _sportCategoryService.GetAllAsync();
        return Ok(categories);
    }
}
