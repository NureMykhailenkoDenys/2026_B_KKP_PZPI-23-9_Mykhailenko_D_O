using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportMate.API.DTOs.Participation;
using SportMate.API.Extensions;
using SportMate.API.Services.Interfaces;

namespace SportMate.API.Controllers;

/// <summary>
/// Event participation endpoints for joining and leaving events
/// </summary>
[ApiController]
[Route("api/events")]
public class ParticipationController : ControllerBase
{
    private readonly IParticipationService _participationService;

    public ParticipationController(IParticipationService participationService)
    {
        _participationService = participationService;
    }

    /// <summary>
    /// Join an event as a participant
    /// </summary>
    /// <param name="id">Event ID to join</param>
    /// <returns>Participation confirmation with event details</returns>
    /// <response code="200">Successfully joined the event</response>
    /// <response code="400">Event is full, already joined, or event is not in valid status</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="404">Event not found</response>
    [HttpPost("{id}/join")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> JoinEvent(int id)
    {
        var userId = User.GetUserId();
        var response = await _participationService.JoinEventAsync(id, userId);
        return Ok(response);
    }

    /// <summary>
    /// Leave an event as a participant
    /// </summary>
    /// <param name="id">Event ID to leave</param>
    /// <returns>No content on success</returns>
    /// <response code="204">Successfully left the event</response>
    /// <response code="400">User is not a participant or is the event organizer</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="404">Event not found</response>
    [HttpDelete("{id}/leave")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> LeaveEvent(int id)
    {
        var userId = User.GetUserId();
        await _participationService.LeaveEventAsync(id, userId);
        return NoContent();
    }

    /// <summary>
    /// Get the list of participants for an event
    /// </summary>
    /// <param name="id">Event ID</param>
    /// <returns>List of event participants (public info only: no email, role, or block status)</returns>
    /// <response code="200">Returns list of participants</response>
    /// <response code="404">Event not found</response>
    /// <remarks>
    /// Anonymous access, consistent with GET /api/events/{id} which already exposes
    /// the same public fields (FirstName, LastName, AvatarId, Rating) for the organizer.
    /// </remarks>
    [HttpGet("{id}/participants")]
    [ProducesResponseType(typeof(List<EventParticipantResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<List<EventParticipantResponse>>> GetParticipants(int id)
    {
        var participants = await _participationService.GetParticipantsAsync(id);
        return Ok(participants);
    }
}
