import apiClient from './client';
import {SportCategoryResponse} from '../types/api.types';
import {API_ENDPOINTS} from '../utils/constants';

export const SportCategoriesAPI = {
  async getSportCategories(): Promise<SportCategoryResponse[]> {
    const response = await apiClient.get<SportCategoryResponse[]>(
      API_ENDPOINTS.SPORT_CATEGORIES,
    );
    return response.data;
  },
};
