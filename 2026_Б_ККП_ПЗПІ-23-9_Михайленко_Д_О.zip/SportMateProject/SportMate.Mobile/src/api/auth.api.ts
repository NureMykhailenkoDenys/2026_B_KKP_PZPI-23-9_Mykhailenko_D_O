import apiClient from './client';
import {
  AuthResponse,
  LoginRequest,
  RegisterRequest,
} from '../types/api.types';
import {API_ENDPOINTS} from '../utils/constants';

export const AuthAPI = {
  async register(data: RegisterRequest): Promise<AuthResponse> {
    const response = await apiClient.post<AuthResponse>(
      API_ENDPOINTS.REGISTER,
      data,
    );
    return response.data;
  },

  async login(data: LoginRequest): Promise<AuthResponse> {
    const response = await apiClient.post<AuthResponse>(
      API_ENDPOINTS.LOGIN,
      data,
    );
    return response.data;
  },
};
