import apiClient from './client';
import {
  EventResponse,
  EventListItemResponse,
  CreateEventRequest,
  UpdateEventRequest,
  EventStatus,
  EventParticipantResponse,
} from '../types/api.types';
import {API_ENDPOINTS} from '../utils/constants';

export const EventsAPI = {
  async getEvents(params?: {
    sportCategoryId?: number;
    status?: EventStatus;
    date?: string;
    address?: string;
  }): Promise<EventListItemResponse[]> {
    const response = await apiClient.get<EventListItemResponse[]>(
      API_ENDPOINTS.EVENTS,
      {params},
    );
    return response.data;
  },

  async getEventById(eventId: number): Promise<EventResponse> {
    const response = await apiClient.get<EventResponse>(
      API_ENDPOINTS.EVENT_BY_ID(eventId),
    );
    return response.data;
  },

  async createEvent(data: CreateEventRequest): Promise<EventResponse> {
    const response = await apiClient.post<EventResponse>(
      API_ENDPOINTS.EVENTS,
      data,
    );
    return response.data;
  },

  async updateEvent(
    eventId: number,
    data: UpdateEventRequest,
  ): Promise<EventResponse> {
    const response = await apiClient.put<EventResponse>(
      API_ENDPOINTS.EVENT_BY_ID(eventId),
      data,
    );
    return response.data;
  },

  async cancelEvent(eventId: number): Promise<void> {
    await apiClient.delete(API_ENDPOINTS.EVENT_BY_ID(eventId));
  },

  async joinEvent(eventId: number): Promise<void> {
    await apiClient.post(API_ENDPOINTS.JOIN_EVENT(eventId));
  },

  async leaveEvent(eventId: number): Promise<void> {
    await apiClient.delete(API_ENDPOINTS.LEAVE_EVENT(eventId));
  },

  async getParticipants(eventId: number): Promise<EventParticipantResponse[]> {
    const response = await apiClient.get<EventParticipantResponse[]>(
      API_ENDPOINTS.EVENT_PARTICIPANTS(eventId),
    );
    return response.data;
  },
};
