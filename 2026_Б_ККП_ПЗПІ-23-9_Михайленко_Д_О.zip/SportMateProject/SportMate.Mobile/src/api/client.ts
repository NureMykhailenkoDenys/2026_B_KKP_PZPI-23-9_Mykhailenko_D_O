import axios, {AxiosError, AxiosInstance} from 'axios';
import {AuthService} from '../services/auth.service';
import {config} from '../utils/config';
import {useAuthStore} from '../store/auth.store';

const apiClient: AxiosInstance = axios.create({
  baseURL: config.apiBaseUrl,
  timeout: config.apiTimeout,
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use(
  async (config: any) => {
    const token = await AuthService.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: any) => {
    return Promise.reject(error);
  },
);

apiClient.interceptors.response.use(
  (response: any) => response,
  async (error: AxiosError) => {
    if (error.response?.status === 401) {
      const authState = useAuthStore.getState();

      if (authState.isAuthenticated) {
        await authState.logout();
      }
    }
    return Promise.reject(error);
  },
);

export default apiClient;
