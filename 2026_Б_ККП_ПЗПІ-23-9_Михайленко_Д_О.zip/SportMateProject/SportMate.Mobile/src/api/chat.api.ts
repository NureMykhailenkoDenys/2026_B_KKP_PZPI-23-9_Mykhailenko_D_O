import apiClient from './client';
import {ChatHistoryResponse} from '../types/api.types';

const API_ENDPOINTS = {
  EVENT_CHAT_MESSAGES: (eventId: number) =>
    `/api/events/${eventId}/chat/messages`,
};

export const ChatAPI = {
  async getChatHistory(
    eventId: number,
    page: number = 1,
    pageSize: number = 50,
  ): Promise<ChatHistoryResponse> {
    const response = await apiClient.get<ChatHistoryResponse>(
      API_ENDPOINTS.EVENT_CHAT_MESSAGES(eventId),
      {
        params: {page, pageSize},
      },
    );
    return response.data;
  },
};
