import apiClient from './client';
import {
  UserProfileResponse,
  PublicUserProfileResponse,
  UpdateProfileRequest,
} from '../types/api.types';
import {API_ENDPOINTS} from '../utils/constants';

export const UsersAPI = {
  async getMyProfile(): Promise<UserProfileResponse> {
    const response = await apiClient.get<UserProfileResponse>(
      API_ENDPOINTS.ME,
    );
    return response.data;
  },

  async updateMyProfile(
    data: UpdateProfileRequest,
  ): Promise<UserProfileResponse> {
    const response = await apiClient.put<UserProfileResponse>(
      API_ENDPOINTS.ME,
      data,
    );
    return response.data;
  },

  async getUserProfile(userId: number): Promise<PublicUserProfileResponse> {
    const response = await apiClient.get<PublicUserProfileResponse>(
      API_ENDPOINTS.USER_BY_ID(userId),
    );
    return response.data;
  },
};
