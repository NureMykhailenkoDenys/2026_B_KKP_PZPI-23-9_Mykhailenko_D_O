import apiClient from './client';
import {
  RatingResponse,
  CreateRatingRequest,
} from '../types/api.types';
import {API_ENDPOINTS} from '../utils/constants';

export const RatingsAPI = {
  async createRating(data: CreateRatingRequest): Promise<RatingResponse> {
    const response = await apiClient.post<RatingResponse>(
      API_ENDPOINTS.RATINGS,
      data,
    );
    return response.data;
  },

  async getEventRatings(eventId: number): Promise<RatingResponse[]> {
    const response = await apiClient.get<RatingResponse[]>(
      API_ENDPOINTS.EVENT_RATINGS(eventId),
    );
    return response.data;
  },

  async getUserRatings(userId: number): Promise<RatingResponse[]> {
    const response = await apiClient.get<RatingResponse[]>(
      API_ENDPOINTS.USER_RATINGS(userId),
    );
    return response.data;
  },
};
