import {config} from '../utils/config';

const ANDROID_PACKAGE = 'com.sportmatemobile';

const ANDROID_CERT_SHA1 = '5E8F16062EA3CD2C4A0D547876BAA6F38CABF625';

export const GeocodingAPI = {
  async reverseGeocode(
    latitude: number,
    longitude: number,
  ): Promise<string | null> {
    const url =
      'https://maps.googleapis.com/maps/api/geocode/json' +
      `?latlng=${latitude},${longitude}&language=uk&region=ua` +
      `&key=${config.googleMapsApiKey}`;

    const response = await fetch(url, {
      headers: {
        'X-Android-Package': ANDROID_PACKAGE,
        'X-Android-Cert': ANDROID_CERT_SHA1,
      },
    });

    const data = await response.json();
    const formattedAddress = data?.results?.[0]?.formatted_address;

    if (data?.status === 'OK' && typeof formattedAddress === 'string') {
      return formattedAddress;
    }
    return null;
  },
};
