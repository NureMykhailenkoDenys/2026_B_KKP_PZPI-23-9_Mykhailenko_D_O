import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {RatingResponse} from '../../types/api.types';
import {Card, Avatar, StarRating} from '../common';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {format} from 'date-fns';
import {uk} from 'date-fns/locale';

interface RatingCardProps {
  rating: RatingResponse;
  onAuthorPress?: (userId: number) => void;
  showTargetUser?: boolean;
}

export const RatingCard: React.FC<RatingCardProps> = ({
  rating,
  onAuthorPress,
  showTargetUser = false,
}) => {
  const displayUser = showTargetUser ? rating.targetUser : rating.author;
  const displayLabel = showTargetUser ? 'Оцінений користувач' : 'Автор оцінки';

  const formattedDate = format(new Date(rating.createdAt), 'dd MMM yyyy', {
    locale: uk,
  });

  return (
    <Card style={styles.card}>
      <TouchableOpacity
        onPress={() => onAuthorPress?.(displayUser.userId)}
        disabled={!onAuthorPress}
        style={styles.userContainer}>
        <Avatar
          size={40}
          firstName={displayUser.firstName}
          lastName={displayUser.lastName}
          avatarId={displayUser.avatarId}
        />
        <View style={styles.userInfo}>
          <Text style={styles.userName}>
            {displayUser.firstName} {displayUser.lastName}
          </Text>
          <Text style={styles.userLabel}>{displayLabel}</Text>
        </View>
      </TouchableOpacity>

      <View style={styles.ratingContainer}>
        <StarRating rating={rating.score} readonly size={20} />
        <Text style={styles.date}>{formattedDate}</Text>
      </View>

      {rating.comment && (
        <View style={styles.commentContainer}>
          <Text style={styles.comment}>{rating.comment}</Text>
        </View>
      )}
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    marginBottom: spacing.md,
  },
  userContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  userInfo: {
    marginLeft: spacing.sm,
    flex: 1,
  },
  userName: {
    ...typography.bodyBold,
    color: colors.textPrimary,
  },
  userLabel: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  date: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  commentContainer: {
    marginTop: spacing.xs,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  comment: {
    ...typography.body,
    color: colors.textPrimary,
  },
});
