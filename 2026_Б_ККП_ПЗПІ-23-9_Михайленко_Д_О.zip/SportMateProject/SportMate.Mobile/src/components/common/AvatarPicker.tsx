import React from 'react';
import {View, TouchableOpacity, Text, StyleSheet, ViewStyle} from 'react-native';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {AVATAR_IDS} from '../../utils/avatars';
import {Avatar} from './Avatar';

interface AvatarPickerProps {
  value: number | null;
  onChange: (avatarId: number) => void;
  size?: number;
  style?: ViewStyle;
}

const DEFAULT_OPTION_SIZE = 64;

export const AvatarPicker: React.FC<AvatarPickerProps> = ({
  value,
  onChange,
  size = DEFAULT_OPTION_SIZE,
  style,
}) => {
  return (
    <View style={[styles.grid, style]}>
      {AVATAR_IDS.map(avatarId => {
        const isSelected = value === avatarId;

        return (
          <TouchableOpacity
            key={avatarId}
            onPress={() => onChange(avatarId)}
            activeOpacity={0.7}
            style={[
              styles.option,
              {
                width: size + spacing.sm,
                height: size + spacing.sm,
                borderRadius: (size + spacing.sm) / 2,
              },
              isSelected && styles.optionSelected,
            ]}
            accessibilityRole="button"
            accessibilityState={{selected: isSelected}}
            accessibilityLabel={`Аватар ${avatarId}`}>
            <Avatar avatarId={avatarId} size={size} />
            {isSelected && (
              <View style={styles.checkmarkBadge}>
                <Text style={styles.checkmarkText}>✓</Text>
              </View>
            )}
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: spacing.sm,
  },
  option: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  optionSelected: {
    borderColor: colors.accentLime,
    backgroundColor: colors.accentLime + '20',
  },
  checkmarkBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.accentLime,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.surface,
  },
  checkmarkText: {
    color: colors.background,
    fontSize: 12,
    fontWeight: '700',
  },
});
