import React from 'react';
import {View, Text, Image, StyleSheet, ViewStyle} from 'react-native';
import {colors} from '../../theme/colors';
import {typography} from '../../theme/typography';
import {getAvatarImageSource} from '../../utils/avatars';

interface AvatarProps {
  size?: number;
  firstName?: string;
  lastName?: string;
  avatarId?: number | null;
  style?: ViewStyle;
}

export const Avatar: React.FC<AvatarProps> = ({
  size = 40,
  firstName = '',
  lastName = '',
  avatarId,
  style,
}) => {
  const getInitials = () => {
    const firstInitial = firstName.charAt(0).toUpperCase();
    const lastInitial = lastName.charAt(0).toUpperCase();
    return `${firstInitial}${lastInitial}` || '?';
  };

  const imageSource = getAvatarImageSource(avatarId);

  return (
    <View
      style={[
        styles.container,
        {width: size, height: size, borderRadius: size / 2},
        style,
      ]}>
      {imageSource ? (
        <Image
          source={imageSource}
          style={{width: size, height: size}}
          resizeMode="cover"
        />
      ) : (
        <Text style={[styles.initials, {fontSize: size * 0.4}]}>
          {getInitials()}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.accentLime,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  initials: {
    ...typography.bodyBold,
    color: colors.primaryNavy,
  },
});
