import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
} from 'react-native';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {shadows} from '../../theme/shadows';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'danger' | 'text';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
  style?: ViewStyle;
  numberOfLines?: number;
  adjustsFontSizeToFit?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  disabled = false,
  loading = false,
  fullWidth = false,
  style,
  numberOfLines,
  adjustsFontSizeToFit,
}) => {
  const buttonStyle: ViewStyle[] = [
    styles.button,
    styles[variant],
    ...(fullWidth ? [styles.fullWidth] : []),
    ...((disabled || loading) ? [styles.disabled] : []),
    ...(style ? [style] : []),
  ].filter(Boolean);

  const textStyle: TextStyle[] = [
    styles.buttonText,
    styles[`${variant}Text` as keyof typeof styles] as TextStyle,
    ...((disabled || loading) ? [styles.disabledText] : []),
  ].filter(Boolean);

  return (
    <TouchableOpacity
      style={buttonStyle}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}>
      {loading ? (
        <ActivityIndicator
          color={variant === 'primary' ? colors.primaryNavy : colors.surface}
        />
      ) : (
        <Text
          style={textStyle}
          numberOfLines={numberOfLines}
          adjustsFontSizeToFit={adjustsFontSizeToFit}>
          {title}
        </Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
    ...shadows.sm,
  },
  fullWidth: {
    width: '100%',
  },
  primary: {
    backgroundColor: colors.accentLime,
  },
  secondary: {
    backgroundColor: colors.primaryNavy,
  },
  outline: {
    backgroundColor: colors.transparent,
    borderWidth: 1,
    borderColor: colors.primaryNavy,
  },
  danger: {
    backgroundColor: colors.danger,
  },
  text: {
    backgroundColor: colors.transparent,
  },
  disabled: {
    opacity: 0.5,
  },
  buttonText: {
    ...typography.button,
    textAlign: 'center',
    textAlignVertical: 'center',
    includeFontPadding: false,
  },
  primaryText: {
    color: colors.primaryNavy,
  },
  secondaryText: {
    color: colors.surface,
  },
  outlineText: {
    color: colors.primaryNavy,
  },
  dangerText: {
    color: colors.surface,
  },
  textText: {
    color: colors.accentLime,
  },
  disabledText: {
    opacity: 0.7,
  },
});
