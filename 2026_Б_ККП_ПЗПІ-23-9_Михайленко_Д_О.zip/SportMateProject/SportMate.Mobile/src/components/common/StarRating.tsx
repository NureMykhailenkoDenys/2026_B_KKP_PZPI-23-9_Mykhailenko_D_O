import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, ViewStyle} from 'react-native';
import {colors} from '../../theme/colors';

interface StarRatingProps {
  rating: number;
  onRatingChange?: (rating: number) => void;
  size?: number;
  readonly?: boolean;
  style?: ViewStyle;
}

export const StarRating: React.FC<StarRatingProps> = ({
  rating,
  onRatingChange,
  size = 24,
  readonly = false,
  style,
}) => {
  const stars = [1, 2, 3, 4, 5];

  const handlePress = (star: number) => {
    if (!readonly && onRatingChange) {
      onRatingChange(star);
    }
  };

  return (
    <View style={[styles.container, style]}>
      {stars.map(star => {
        const isFilled = star <= rating;
        const StarComponent = readonly ? View : TouchableOpacity;

        return (
          <StarComponent
            key={star}
            onPress={() => handlePress(star)}
            disabled={readonly}
            style={styles.starButton}>
            <Text style={[styles.star, {fontSize: size}]}>
              {isFilled ? '⭐' : '☆'}
            </Text>
          </StarComponent>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  starButton: {
    marginHorizontal: 2,
  },
  star: {
    color: colors.warning,
  },
});
