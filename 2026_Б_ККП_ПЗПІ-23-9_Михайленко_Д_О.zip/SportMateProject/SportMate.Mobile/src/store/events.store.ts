import {create} from 'zustand';
import {EventListItemResponse, EventResponse} from '../types/api.types';

interface EventsState {
  events: EventListItemResponse[];
  selectedEvent: EventResponse | null;
  isLoading: boolean;
  error: string | null;

  setEvents: (events: EventListItemResponse[]) => void;
  setSelectedEvent: (event: EventResponse | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearEvents: () => void;
}

export const useEventsStore = create<EventsState>(set => ({
  events: [],
  selectedEvent: null,
  isLoading: false,
  error: null,

  setEvents: events => set({events}),

  setSelectedEvent: event => set({selectedEvent: event}),

  setLoading: loading => set({isLoading: loading}),

  setError: error => set({error}),

  clearEvents: () =>
    set({
      events: [],
      selectedEvent: null,
      error: null,
    }),
}));
