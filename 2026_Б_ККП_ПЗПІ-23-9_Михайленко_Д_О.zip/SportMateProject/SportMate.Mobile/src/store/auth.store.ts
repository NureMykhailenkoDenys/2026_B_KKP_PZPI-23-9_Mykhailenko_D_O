import {create} from 'zustand';
import {AuthResponse} from '../types/api.types';
import {AuthService} from '../services/auth.service';
import {AuthAPI} from '../api/auth.api';
import signalRService from '../services/signalr.service';

interface AuthState {
  user: AuthResponse | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  setUser: (user: AuthResponse | null) => void;
  updateUser: (user: AuthResponse) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  login: (email: string, password: string) => Promise<void>;
  register: (
    email: string,
    password: string,
    firstName: string,
    lastName: string,
    avatarId?: number,
  ) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthState>(set => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,

  setUser: user =>
    set({
      user,
      isAuthenticated: user !== null,
    }),

  updateUser: user => {
    set({user, isAuthenticated: true});
    AuthService.setUser(user).catch(error =>
      console.error('Failed to persist user update:', error),
    );
  },

  setLoading: loading => set({isLoading: loading}),

  setError: error => set({error}),

  login: async (email, password) => {
    try {
      set({isLoading: true, error: null});

      const response = await AuthAPI.login({email, password});

      await AuthService.setToken(response.accessToken);
      await AuthService.setUser(response);

      set({
        user: response,
        isAuthenticated: true,
        isLoading: false,
      });
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message ||
        error.message ||
        'Помилка входу. Спробуйте ще раз.';
      set({
        error: errorMessage,
        isLoading: false,
      });
      throw error;
    }
  },

  register: async (email, password, firstName, lastName, avatarId) => {
    try {
      set({isLoading: true, error: null});

      const response = await AuthAPI.register({
        email,
        password,
        firstName,
        lastName,
        avatarId,
      });

      await AuthService.setToken(response.accessToken);
      await AuthService.setUser(response);

      set({
        user: response,
        isAuthenticated: true,
        isLoading: false,
      });
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message ||
        error.message ||
        'Помилка реєстрації. Спробуйте ще раз.';
      set({
        error: errorMessage,
        isLoading: false,
      });
      throw error;
    }
  },

  logout: async () => {
    await signalRService.disconnect();
    await AuthService.clearAuth();
    set({
      user: null,
      isAuthenticated: false,
      error: null,
    });
  },

  checkAuth: async () => {
    try {
      set({isLoading: true});

      const user = await AuthService.getUser();
      const token = await AuthService.getToken();

      if (user && token) {
        set({
          user,
          isAuthenticated: true,
        });
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      await AuthService.clearAuth();
    } finally {
      set({isLoading: false});
    }
  },
}));
