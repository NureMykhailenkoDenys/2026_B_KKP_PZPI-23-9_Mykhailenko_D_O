export const colors = {
  primaryNavy: '#172554',
  dark: '#0F172A',
  accentLime: '#84CC16',

  background: '#F8FAFC',
  surface: '#FFFFFF',

  textPrimary: '#172554',
  textSecondary: '#64748B',

  success: '#22C55E',
  warning: '#F59E0B',
  danger: '#EF4444',

  border: '#E2E8F0',
  disabled: '#CBD5E1',
  overlay: 'rgba(15, 23, 42, 0.5)',

  transparent: 'transparent',
} as const;

export type ColorKey = keyof typeof colors;
