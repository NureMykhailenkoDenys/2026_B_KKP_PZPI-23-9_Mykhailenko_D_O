export const API_BASE_URL = 'http://10.0.2.2:5243';

export const config = {
  apiBaseUrl: API_BASE_URL,
  apiTimeout: 10000,

  signalRHubUrl: `${API_BASE_URL}/hubs/event-chat`,

  googleMapsApiKey: 'AIzaSyCMUvo7osbHNqTlUY_M_xVhL7_G-ADe2DU',
} as const;
