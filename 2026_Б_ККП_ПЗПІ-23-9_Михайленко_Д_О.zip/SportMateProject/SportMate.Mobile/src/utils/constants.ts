export const STORAGE_KEYS = {
  AUTH_TOKEN: 'auth_token',
  USER_DATA: 'user_data',
} as const;

export const API_ENDPOINTS = {
  REGISTER: '/api/auth/register',
  LOGIN: '/api/auth/login',

  ME: '/api/users/me',
  USER_BY_ID: (id: number) => `/api/users/${id}`,

  EVENTS: '/api/events',
  EVENT_BY_ID: (id: number) => `/api/events/${id}`,
  JOIN_EVENT: (id: number) => `/api/events/${id}/join`,
  LEAVE_EVENT: (id: number) => `/api/events/${id}/leave`,
  EVENT_PARTICIPANTS: (id: number) => `/api/events/${id}/participants`,

  CHAT_HISTORY: (eventId: number) => `/api/events/${eventId}/chat/messages`,

  RATINGS: '/api/ratings',
  EVENT_RATINGS: (eventId: number) => `/api/ratings/event/${eventId}`,
  USER_RATINGS: (userId: number) => `/api/ratings/user/${userId}`,

  SPORT_CATEGORIES: '/api/sport-categories',
} as const;

export const VALIDATION = {
  MIN_PASSWORD_LENGTH: 6,
  MAX_MESSAGE_LENGTH: 2000,
  MIN_EVENT_PARTICIPANTS: 2,
  MAX_EVENT_PARTICIPANTS: 100,
} as const;
