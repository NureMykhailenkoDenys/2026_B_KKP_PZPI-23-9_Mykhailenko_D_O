import {ImageSourcePropType} from 'react-native';

export const MIN_AVATAR_ID = 1;
export const MAX_AVATAR_ID = 10;

export const AVATAR_IDS: number[] = Array.from(
  {length: MAX_AVATAR_ID - MIN_AVATAR_ID + 1},
  (_, index) => MIN_AVATAR_ID + index,
);

const AVATAR_IMAGES: Record<number, ImageSourcePropType> = {
  1: require('../assets/avatars/avatar-1.png'),
  2: require('../assets/avatars/avatar-2.png'),
  3: require('../assets/avatars/avatar-3.png'),
  4: require('../assets/avatars/avatar-4.png'),
  5: require('../assets/avatars/avatar-5.png'),
  6: require('../assets/avatars/avatar-6.png'),
  7: require('../assets/avatars/avatar-7.png'),
  8: require('../assets/avatars/avatar-8.png'),
  9: require('../assets/avatars/avatar-9.png'),
  10: require('../assets/avatars/avatar-10.png'),
};

function isValidAvatarId(avatarId: number): boolean {
  return (
    Number.isInteger(avatarId) &&
    avatarId >= MIN_AVATAR_ID &&
    avatarId <= MAX_AVATAR_ID
  );
}

export function getAvatarImageSource(
  avatarId: number | null | undefined,
): ImageSourcePropType | null {
  if (avatarId == null || !isValidAvatarId(avatarId)) {
    return null;
  }

  return AVATAR_IMAGES[avatarId] ?? null;
}
