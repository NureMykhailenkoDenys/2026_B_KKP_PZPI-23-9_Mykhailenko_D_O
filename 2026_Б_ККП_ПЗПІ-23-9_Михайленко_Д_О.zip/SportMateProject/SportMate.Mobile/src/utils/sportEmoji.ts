const NEUTRAL_FALLBACK_EMOJI = '🏅';

const SPORT_EMOJI: Record<string, string> = {
  Football: '⚽',
  Basketball: '🏀',
  Volleyball: '🏐',
  Tennis: '🎾',
  Running: '🏃',
  Swimming: '🏊',
  Cycling: '🚴',
  Gym: '🏋️',
  'Table Tennis': '🏓',
};

export function getSportEmoji(sportCategoryName: string | null | undefined): string {
  if (!sportCategoryName) {
    return NEUTRAL_FALLBACK_EMOJI;
  }

  return SPORT_EMOJI[sportCategoryName] ?? NEUTRAL_FALLBACK_EMOJI;
}
