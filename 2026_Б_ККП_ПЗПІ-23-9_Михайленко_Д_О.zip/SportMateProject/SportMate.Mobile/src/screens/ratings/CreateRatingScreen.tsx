import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Alert,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {EventsStackParamList} from '../../types/navigation.types';
import {RatingsAPI} from '../../api/ratings.api';
import {Button, StarRating, Card} from '../../components/common';
import {useAuthStore} from '../../store/auth.store';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';

type CreateRatingRouteProp = RouteProp<EventsStackParamList, 'CreateRating'>;
type CreateRatingNavigationProp = NativeStackNavigationProp<
  EventsStackParamList,
  'CreateRating'
>;

export const CreateRatingScreen: React.FC = () => {
  const route = useRoute<CreateRatingRouteProp>();
  const navigation = useNavigation<CreateRatingNavigationProp>();
  const {eventId, targetUserId} = route.params;
  const {user} = useAuthStore();

  const [score, setScore] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (score === 0) {
      Alert.alert('Помилка', 'Будь ласка, оберіть оцінку від 1 до 5');
      return;
    }

    if (user && user.userId === targetUserId) {
      Alert.alert('Помилка', 'Ви не можете оцінити самого себе');
      return;
    }

    try {
      setIsSubmitting(true);
      await RatingsAPI.createRating({
        eventId,
        targetUserId,
        score,
        comment: comment.trim() || undefined,
      });

      Alert.alert('Успіх', 'Рейтинг успішно додано', [
        {
          text: 'OK',
          onPress: () => navigation.goBack(),
        },
      ]);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося додати рейтинг';
      Alert.alert('Помилка', errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Card style={styles.card}>
          <Text style={styles.title}>Оцініть учасника</Text>
          <Text style={styles.subtitle}>
            Як ви оцінюєте цього учасника після завершення події?
          </Text>

          <View style={styles.ratingSection}>
            <Text style={styles.label}>Оцінка *</Text>
            <StarRating
              rating={score}
              onRatingChange={setScore}
              size={40}
              style={styles.stars}
            />
            {score > 0 && (
              <Text style={styles.scoreText}>{score} з 5 зірок</Text>
            )}
          </View>

          <View style={styles.commentSection}>
            <Text style={styles.label}>Коментар (необов'язково)</Text>
            <TextInput
              style={styles.textInput}
              placeholder="Напишіть ваш відгук про цього учасника..."
              placeholderTextColor={colors.textSecondary}
              multiline
              numberOfLines={4}
              value={comment}
              onChangeText={setComment}
              maxLength={500}
              textAlignVertical="top"
            />
            <Text style={styles.charCount}>{comment.length} / 500</Text>
          </View>

          <Button
            title="Надіслати оцінку"
            onPress={handleSubmit}
            loading={isSubmitting}
            disabled={score === 0 || isSubmitting}
            fullWidth
            style={styles.submitButton}
          />
        </Card>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  card: {
    padding: spacing.lg,
  },
  title: {
    ...typography.h2,
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  ratingSection: {
    marginBottom: spacing.xl,
  },
  label: {
    ...typography.bodyBold,
    marginBottom: spacing.sm,
  },
  stars: {
    justifyContent: 'center',
    marginVertical: spacing.md,
  },
  scoreText: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.xs,
  },
  commentSection: {
    marginBottom: spacing.lg,
  },
  textInput: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: spacing.md,
    ...typography.body,
    color: colors.textPrimary,
    minHeight: 100,
  },
  charCount: {
    ...typography.caption,
    color: colors.textSecondary,
    textAlign: 'right',
    marginTop: spacing.xs,
  },
  submitButton: {
    marginTop: spacing.md,
  },
});
