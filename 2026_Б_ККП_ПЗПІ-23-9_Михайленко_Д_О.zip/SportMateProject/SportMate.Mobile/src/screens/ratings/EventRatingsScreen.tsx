import React, {useState, useEffect, useCallback} from 'react';
import {View, Text, StyleSheet, ScrollView, RefreshControl} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {EventsStackParamList} from '../../types/navigation.types';
import {RatingsAPI} from '../../api/ratings.api';
import {RatingResponse} from '../../types/api.types';
import {RatingCard} from '../../components/ratings/RatingCard';
import {Loading} from '../../components/common';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';

type EventRatingsRouteProp = RouteProp<EventsStackParamList, 'EventRatings'>;
type EventRatingsNavigationProp = NativeStackNavigationProp<
  EventsStackParamList,
  'EventRatings'
>;

export const EventRatingsScreen: React.FC = () => {
  const route = useRoute<EventRatingsRouteProp>();
  const navigation = useNavigation<EventRatingsNavigationProp>();
  const {eventId} = route.params;

  const [ratings, setRatings] = useState<RatingResponse[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadRatings = useCallback(async () => {
    try {
      setError(null);
      const data = await RatingsAPI.getEventRatings(eventId);
      setRatings(data);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося завантажити рейтинги події';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [eventId]);

  useEffect(() => {
    loadRatings();
  }, [loadRatings]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadRatings();
  };

  const handleUserPress = (userId: number) => {
    navigation.push('PublicProfile', {userId});
  };

  if (isLoading) {
    return <Loading />;
  }

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.accentLime}
          />
        }>
        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}

        {!error && ratings.length === 0 && (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>⭐</Text>
            <Text style={styles.emptyTitle}>Немає рейтингів</Text>
            <Text style={styles.emptySubtitle}>
              Учасники ще не залишили оцінок для цієї події
            </Text>
          </View>
        )}

        {!error && ratings.length > 0 && (
          <>
            <Text style={styles.header}>
              Рейтинги події ({ratings.length})
            </Text>
            {ratings.map(rating => (
              <RatingCard
                key={rating.ratingId}
                rating={rating}
                onAuthorPress={handleUserPress}
                showTargetUser={false}
              />
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  header: {
    ...typography.h2,
    marginBottom: spacing.md,
  },
  errorContainer: {
    padding: spacing.lg,
    backgroundColor: colors.danger + '20',
    borderRadius: 8,
    marginBottom: spacing.md,
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    textAlign: 'center',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: spacing.xl * 2,
  },
  emptyText: {
    fontSize: 64,
    marginBottom: spacing.md,
  },
  emptyTitle: {
    ...typography.h3,
    marginBottom: spacing.xs,
  },
  emptySubtitle: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});
