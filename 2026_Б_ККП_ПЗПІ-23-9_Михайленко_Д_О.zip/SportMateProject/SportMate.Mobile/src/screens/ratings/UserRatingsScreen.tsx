import React, {useState, useEffect, useCallback} from 'react';
import {View, Text, StyleSheet, ScrollView, RefreshControl} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {EventsStackParamList} from '../../types/navigation.types';
import {RatingsAPI} from '../../api/ratings.api';
import {RatingResponse} from '../../types/api.types';
import {RatingCard} from '../../components/ratings/RatingCard';
import {Loading, StarRating} from '../../components/common';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';

type UserRatingsNavigationProp = NativeStackNavigationProp<
  EventsStackParamList,
  'PublicProfile'
>;

interface UserRatingsScreenProps {
  userId: number;
}

export const UserRatingsScreen: React.FC<UserRatingsScreenProps> = ({
  userId,
}) => {
  const navigation = useNavigation<UserRatingsNavigationProp>();
  const [ratings, setRatings] = useState<RatingResponse[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadRatings = useCallback(async () => {
    try {
      setError(null);
      const data = await RatingsAPI.getUserRatings(userId);
      setRatings(data);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося завантажити рейтинги';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [userId]);

  useEffect(() => {
    loadRatings();
  }, [loadRatings]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadRatings();
  };

  const handleAuthorPress = (authorId: number) => {
    navigation.push('PublicProfile', {userId: authorId});
  };

  const calculateAverageRating = () => {
    if (ratings.length === 0) return 0;
    const sum = ratings.reduce((acc, rating) => acc + rating.score, 0);
    return sum / ratings.length;
  };

  if (isLoading) {
    return <Loading />;
  }

  const averageRating = calculateAverageRating();

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.accentLime}
          />
        }>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Середній рейтинг</Text>
          <View style={styles.averageContainer}>
            <Text style={styles.averageText}>{averageRating.toFixed(1)}</Text>
            <StarRating rating={Math.round(averageRating)} readonly size={28} />
          </View>
          <Text style={styles.totalRatings}>
            {ratings.length} {ratings.length === 1 ? 'оцінка' : 'оцінок'}
          </Text>
        </View>

        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}

        {!error && ratings.length === 0 && (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>⭐</Text>
            <Text style={styles.emptyTitle}>Немає оцінок</Text>
            <Text style={styles.emptySubtitle}>
              Цей користувач ще не отримав жодної оцінки
            </Text>
          </View>
        )}

        {!error && ratings.length > 0 && (
          <View style={styles.ratingsSection}>
            <Text style={styles.sectionTitle}>Всі оцінки</Text>
            {ratings.map(rating => (
              <RatingCard
                key={rating.ratingId}
                rating={rating}
                onAuthorPress={handleAuthorPress}
                showTargetUser={false}
              />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  summaryCard: {
    backgroundColor: colors.surface,
    padding: spacing.lg,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  summaryTitle: {
    ...typography.h3,
    marginBottom: spacing.sm,
  },
  averageContainer: {
    alignItems: 'center',
    marginVertical: spacing.sm,
  },
  averageText: {
    ...typography.h1,
    color: colors.warning,
    marginBottom: spacing.xs,
  },
  totalRatings: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: spacing.sm,
  },
  errorContainer: {
    padding: spacing.lg,
    backgroundColor: colors.danger + '20',
    borderRadius: 8,
    marginBottom: spacing.md,
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    textAlign: 'center',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: spacing.xl * 2,
  },
  emptyText: {
    fontSize: 64,
    marginBottom: spacing.md,
  },
  emptyTitle: {
    ...typography.h3,
    marginBottom: spacing.xs,
  },
  emptySubtitle: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  ratingsSection: {
    marginTop: spacing.sm,
  },
  sectionTitle: {
    ...typography.h3,
    marginBottom: spacing.md,
  },
});

export const UserRatingsRouteScreen: React.FC<{
  route: {params: {userId: number}};
}> = ({route}) => <UserRatingsScreen userId={route.params.userId} />;
