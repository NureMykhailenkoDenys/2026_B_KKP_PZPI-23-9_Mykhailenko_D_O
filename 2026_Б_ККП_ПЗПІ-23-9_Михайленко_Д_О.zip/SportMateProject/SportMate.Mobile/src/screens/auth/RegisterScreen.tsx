import React, {useState} from 'react';
import {View, Text, StyleSheet, Alert, ScrollView} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {Button, Input, AvatarPicker} from '../../components/common';
import {useAuthStore} from '../../store/auth.store';
import type {AuthStackParamList} from '../../types/navigation.types';

type RegisterScreenNavigationProp = NativeStackNavigationProp<
  AuthStackParamList,
  'Register'
>;

export const RegisterScreen: React.FC = () => {
  const navigation = useNavigation<RegisterScreenNavigationProp>();
  const {register, isLoading} = useAuthStore();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [avatarId, setAvatarId] = useState<number | null>(null);

  const [firstNameError, setFirstNameError] = useState('');
  const [lastNameError, setLastNameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [avatarError, setAvatarError] = useState('');

  const validateFirstName = (value: string): boolean => {
    if (!value.trim()) {
      setFirstNameError('Ім\'я обов\'язкове');
      return false;
    }
    if (value.trim().length < 2) {
      setFirstNameError('Ім\'я має містити мінімум 2 символи');
      return false;
    }
    setFirstNameError('');
    return true;
  };

  const validateLastName = (value: string): boolean => {
    if (!value.trim()) {
      setLastNameError('Прізвище обов\'язкове');
      return false;
    }
    if (value.trim().length < 2) {
      setLastNameError('Прізвище має містити мінімум 2 символи');
      return false;
    }
    setLastNameError('');
    return true;
  };

  const validateEmail = (value: string): boolean => {
    if (!value.trim()) {
      setEmailError('Електронна пошта обов\'язкова');
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      setEmailError('Невірний формат електронної пошти');
      return false;
    }
    setEmailError('');
    return true;
  };

  const validatePassword = (value: string): boolean => {
    if (!value) {
      setPasswordError('Пароль обов\'язковий');
      return false;
    }
    if (value.length < 6) {
      setPasswordError('Пароль має містити мінімум 6 символів');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const validateAvatar = (): boolean => {
    if (avatarId === null) {
      setAvatarError('Оберіть аватар');
      return false;
    }
    setAvatarError('');
    return true;
  };

  const handleAvatarChange = (id: number) => {
    setAvatarId(id);
    if (avatarError) {
      setAvatarError('');
    }
  };

  const handleRegister = async () => {
    const isFirstNameValid = validateFirstName(firstName);
    const isLastNameValid = validateLastName(lastName);
    const isEmailValid = validateEmail(email);
    const isPasswordValid = validatePassword(password);
    const isAvatarValid = validateAvatar();

    if (
      !isFirstNameValid ||
      !isLastNameValid ||
      !isEmailValid ||
      !isPasswordValid ||
      !isAvatarValid ||
      avatarId === null
    ) {
      return;
    }

    try {
      await register(
        email.trim(),
        password,
        firstName.trim(),
        lastName.trim(),
        avatarId,
      );
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Помилка реєстрації. Спробуйте знову.';
      Alert.alert('Помилка реєстрації', errorMessage);
    }
  };

  const handleNavigateToLogin = () => {
    navigation.navigate('Login');
  };

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>SportMate</Text>
        <Text style={styles.subtitle}>Реєстрація</Text>

        <View style={styles.form}>
          <Input
            label="Ім'я"
            placeholder="Введіть ім'я"
            value={firstName}
            onChangeText={(text) => {
              setFirstName(text);
              if (firstNameError) validateFirstName(text);
            }}
            onBlur={() => validateFirstName(firstName)}
            error={firstNameError}
            autoCapitalize="words"
            editable={!isLoading}
          />
          <Input
            label="Прізвище"
            placeholder="Введіть прізвище"
            value={lastName}
            onChangeText={(text) => {
              setLastName(text);
              if (lastNameError) validateLastName(text);
            }}
            onBlur={() => validateLastName(lastName)}
            error={lastNameError}
            autoCapitalize="words"
            editable={!isLoading}
          />
          <Input
            label="Електронна пошта"
            placeholder="Введіть електронну пошту"
            value={email}
            onChangeText={(text) => {
              setEmail(text);
              if (emailError) validateEmail(text);
            }}
            onBlur={() => validateEmail(email)}
            error={emailError}
            keyboardType="email-address"
            autoCapitalize="none"
            editable={!isLoading}
          />
          <Input
            label="Пароль"
            placeholder="Введіть пароль"
            value={password}
            onChangeText={(text) => {
              setPassword(text);
              if (passwordError) validatePassword(text);
            }}
            onBlur={() => validatePassword(password)}
            error={passwordError}
            secureTextEntry
            editable={!isLoading}
          />

          <View style={styles.avatarSection}>
            <Text style={styles.avatarLabel}>Оберіть аватар</Text>
            <AvatarPicker value={avatarId} onChange={handleAvatarChange} />
            {avatarError && (
              <Text style={styles.avatarError}>{avatarError}</Text>
            )}
          </View>

          <Button
            title="Зареєструватися"
            onPress={handleRegister}
            fullWidth
            loading={isLoading}
            disabled={isLoading}
          />
        </View>

        <Button
          title="Вже є акаунт? Увійти"
          onPress={handleNavigateToLogin}
          variant="text"
          disabled={isLoading}
          style={styles.linkButton}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    flexGrow: 1,
    padding: spacing.lg,
    justifyContent: 'center',
  },
  title: {
    ...typography.h1,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...typography.h2,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  form: {
    marginBottom: spacing.lg,
  },
  avatarSection: {
    marginBottom: spacing.md,
    alignItems: 'center',
  },
  avatarLabel: {
    ...typography.body,
    color: colors.textPrimary,
    fontWeight: '600',
    alignSelf: 'flex-start',
    marginBottom: spacing.sm,
  },
  avatarError: {
    ...typography.caption,
    color: colors.danger,
    marginTop: spacing.xs,
  },
  footer: {
    ...typography.caption,
    textAlign: 'center',
    marginTop: spacing.lg,
  },
  linkButton: {
    elevation: 0,
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {width: 0, height: 0},
  },
});
