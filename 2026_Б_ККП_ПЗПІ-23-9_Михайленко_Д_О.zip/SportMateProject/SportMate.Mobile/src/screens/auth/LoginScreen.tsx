import React, {useState} from 'react';
import {View, Text, StyleSheet, Alert} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {Button, Input} from '../../components/common';
import {useAuthStore} from '../../store/auth.store';
import type {AuthStackParamList} from '../../types/navigation.types';

type LoginScreenNavigationProp = NativeStackNavigationProp<
  AuthStackParamList,
  'Login'
>;

export const LoginScreen: React.FC = () => {
  const navigation = useNavigation<LoginScreenNavigationProp>();
  const {login, isLoading} = useAuthStore();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const validateEmail = (value: string): boolean => {
    if (!value.trim()) {
      setEmailError('Електронна пошта обов\'язкова');
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      setEmailError('Невірний формат електронної пошти');
      return false;
    }
    setEmailError('');
    return true;
  };

  const validatePassword = (value: string): boolean => {
    if (!value) {
      setPasswordError('Пароль обов\'язковий');
      return false;
    }
    if (value.length < 6) {
      setPasswordError('Пароль має містити мінімум 6 символів');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const handleLogin = async () => {
    const isEmailValid = validateEmail(email);
    const isPasswordValid = validatePassword(password);

    if (!isEmailValid || !isPasswordValid) {
      return;
    }

    try {
      await login(email.trim(), password);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Помилка входу. Перевірте дані та спробуйте знову.';
      Alert.alert('Помилка входу', errorMessage);
    }
  };

  const handleNavigateToRegister = () => {
    navigation.navigate('Register');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SportMate</Text>
      <Text style={styles.subtitle}>Вхід</Text>

      <View style={styles.form}>
        <Input
          label="Електронна пошта"
          placeholder="Введіть електронну пошту"
          value={email}
          onChangeText={(text) => {
            setEmail(text);
            if (emailError) validateEmail(text);
          }}
          onBlur={() => validateEmail(email)}
          error={emailError}
          keyboardType="email-address"
          autoCapitalize="none"
          editable={!isLoading}
        />
        <Input
          label="Пароль"
          placeholder="Введіть пароль"
          value={password}
          onChangeText={(text) => {
            setPassword(text);
            if (passwordError) validatePassword(text);
          }}
          onBlur={() => validatePassword(password)}
          error={passwordError}
          secureTextEntry
          editable={!isLoading}
        />
        <Button
          title="Увійти"
          onPress={handleLogin}
          fullWidth
          loading={isLoading}
          disabled={isLoading}
        />
      </View>

      <Button
        title="Ще немає акаунту? Зареєструватися"
        onPress={handleNavigateToRegister}
        variant="text"
        disabled={isLoading}
        style={styles.linkButton}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.lg,
    justifyContent: 'center',
  },
  title: {
    ...typography.h1,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...typography.h2,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  form: {
    marginBottom: spacing.lg,
  },
  footer: {
    ...typography.caption,
    textAlign: 'center',
    marginTop: spacing.lg,
  },
  linkButton: {
    elevation: 0,
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {width: 0, height: 0},
  },
});
