import React from 'react';
import {View, StyleSheet} from 'react-native';
import {useAuthStore} from '../../store/auth.store';
import {UserRatingsScreen} from '../ratings/UserRatingsScreen';
import {colors} from '../../theme/colors';

export const MyRatingsScreen: React.FC = () => {
  const {user} = useAuthStore();

  if (!user) {
    return <View style={styles.container} />;
  }

  return (
    <View style={styles.container}>
      <UserRatingsScreen userId={user.userId} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
});
