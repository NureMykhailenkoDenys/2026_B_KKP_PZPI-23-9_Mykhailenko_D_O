import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {ProfileStackParamList} from '../../types/navigation.types';
import {UsersAPI} from '../../api/users.api';
import {useAuthStore} from '../../store/auth.store';
import {Button, Input, Card, AvatarPicker} from '../../components/common';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';

type EditProfileNavigationProp = NativeStackNavigationProp<
  ProfileStackParamList,
  'EditProfile'
>;

export const EditProfileScreen: React.FC = () => {
  const navigation = useNavigation<EditProfileNavigationProp>();
  const {user, updateUser} = useAuthStore();

  const [firstName, setFirstName] = useState(user?.firstName || '');
  const [lastName, setLastName] = useState(user?.lastName || '');
  const [avatarId, setAvatarId] = useState<number | null>(
    user?.avatarId ?? null,
  );
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validatePassword = (value: string): boolean => {
    if (!value) {
      setPasswordError('');
      return true;
    }
    if (value.length < 6) {
      setPasswordError('Пароль має містити мінімум 6 символів');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const handleSave = async () => {
    if (!firstName.trim() || !lastName.trim()) {
      Alert.alert('Помилка', "Ім'я та прізвище не можуть бути порожніми");
      return;
    }

    if (!validatePassword(password)) {
      return;
    }

    try {
      setIsSubmitting(true);
      const updatedProfile = await UsersAPI.updateMyProfile({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        avatarId: avatarId ?? undefined,
        password: password.length > 0 ? password : undefined,
      });

      if (user) {
        updateUser({
          ...user,
          firstName: updatedProfile.firstName,
          lastName: updatedProfile.lastName,
          avatarId: updatedProfile.avatarId,
        });
      }

      Alert.alert('Успіх', 'Профіль оновлено', [
        {
          text: 'OK',
          onPress: () => navigation.goBack(),
        },
      ]);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося оновити профіль';
      Alert.alert('Помилка', errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Card style={styles.card}>
          <Text style={styles.title}>Редагування профілю</Text>
          <Text style={styles.subtitle}>
            Оновіть ваше ім'я та прізвище
          </Text>

          <View style={styles.formSection}>
            <Input
              label="Ім'я *"
              value={firstName}
              onChangeText={setFirstName}
              placeholder="Введіть ваше ім'я"
              autoCapitalize="words"
              maxLength={50}
            />

            <Input
              label="Прізвище *"
              value={lastName}
              onChangeText={setLastName}
              placeholder="Введіть ваше прізвище"
              autoCapitalize="words"
              maxLength={50}
            />

            <Input
              label="Новий пароль (необов'язково)"
              value={password}
              onChangeText={(text) => {
                setPassword(text);
                if (passwordError) validatePassword(text);
              }}
              onBlur={() => validatePassword(password)}
              error={passwordError}
              placeholder="Залиште порожнім, щоб не змінювати"
              secureTextEntry
              autoCapitalize="none"
              editable={!isSubmitting}
            />
          </View>

          <View style={styles.avatarSection}>
            <Text style={styles.avatarLabel}>Оберіть аватар</Text>
            <AvatarPicker value={avatarId} onChange={setAvatarId} />
          </View>

          <View style={styles.buttonContainer}>
            <Button
              title="Зберегти зміни"
              onPress={handleSave}
              loading={isSubmitting}
              disabled={isSubmitting || !firstName.trim() || !lastName.trim()}
              fullWidth
            />
            <Button
              title="Скасувати"
              onPress={() => navigation.goBack()}
              variant="secondary"
              disabled={isSubmitting}
              fullWidth
              style={styles.cancelButton}
            />
          </View>
        </Card>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  card: {
    padding: spacing.lg,
  },
  title: {
    ...typography.h2,
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  formSection: {
    marginBottom: spacing.lg,
  },
  avatarSection: {
    marginBottom: spacing.lg,
  },
  avatarLabel: {
    ...typography.body,
    color: colors.textPrimary,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  buttonContainer: {
    marginTop: spacing.md,
  },
  cancelButton: {
    marginTop: spacing.md,
  },
});
