import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {EventsStackParamList} from '../../types/navigation.types';
import {UsersAPI} from '../../api/users.api';
import {PublicUserProfileResponse, EventListItemResponse} from '../../types/api.types';
import {Loading, Avatar, Card, Button} from '../../components/common';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {format} from 'date-fns';
import {uk} from 'date-fns/locale';

type PublicProfileRouteProp = RouteProp<EventsStackParamList, 'PublicProfile'>;
type PublicProfileNavigationProp = NativeStackNavigationProp<
  EventsStackParamList,
  'PublicProfile'
>;

export const PublicProfileScreen: React.FC = () => {
  const route = useRoute<PublicProfileRouteProp>();
  const navigation = useNavigation<PublicProfileNavigationProp>();
  const {userId} = route.params;

  const [profile, setProfile] = useState<PublicUserProfileResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadProfile = useCallback(async () => {
    try {
      setError(null);
      const data = await UsersAPI.getUserProfile(userId);
      setProfile(data);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося завантажити профіль';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [userId]);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadProfile();
  };

  const handleEventPress = (eventId: number) => {
    navigation.navigate('EventDetails', {eventId});
  };

  const handleViewRatings = () => {
    navigation.navigate('UserRatings', {userId});
  };

  if (isLoading) {
    return <Loading />;
  }

  if (error || !profile) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error || 'Профіль не знайдено'}</Text>
      </View>
    );
  }

  const renderEventCard = (event: EventListItemResponse) => {
    const eventDate = format(new Date(event.eventDate), 'dd MMM yyyy, HH:mm', {
      locale: uk,
    });

    return (
      <TouchableOpacity
        key={event.eventId}
        onPress={() => handleEventPress(event.eventId)}>
        <Card style={styles.eventCard}>
          <View style={styles.eventHeader}>
            <Text style={styles.eventTitle}>{event.title}</Text>
            <Text style={styles.eventSport}>{event.sportCategory.name}</Text>
          </View>
          <Text style={styles.eventDate}>📅 {eventDate}</Text>
          <Text style={styles.eventAddress}>📍 {event.address}</Text>
          <View style={styles.eventFooter}>
            <Text style={styles.eventParticipants}>
              👥 {event.participantCount}/{event.maxParticipants}
            </Text>
          </View>
        </Card>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.accentLime}
          />
        }>
        <View style={styles.header}>
          <Avatar
            size={80}
            firstName={profile.firstName}
            lastName={profile.lastName}
            avatarId={profile.avatarId}
          />
          <Text style={styles.name}>
            {profile.firstName} {profile.lastName}
          </Text>
          <View style={styles.ratingContainer}>
            <Text style={styles.rating}>⭐ {profile.rating.toFixed(1)}</Text>
          </View>
        </View>

        <Card style={styles.sectionCard}>
          <Button
            title="⭐ Відгуки"
            onPress={handleViewRatings}
            variant="secondary"
            fullWidth
          />
        </Card>

        {profile.organizedEvents.length > 0 && (
          <View style={styles.eventsSection}>
            <Text style={styles.sectionTitle}>
              📅 Організовані події ({profile.organizedEvents.length})
            </Text>
            {profile.organizedEvents.map(renderEventCard)}
          </View>
        )}

        {profile.participatingEvents.length > 0 && (
          <View style={styles.eventsSection}>
            <Text style={styles.sectionTitle}>
              🏃 Участь у подіях ({profile.participatingEvents.length})
            </Text>
            {profile.participatingEvents.map(renderEventCard)}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xl,
    paddingVertical: spacing.lg,
  },
  name: {
    ...typography.h2,
    marginTop: spacing.md,
  },
  ratingContainer: {
    marginTop: spacing.sm,
  },
  rating: {
    ...typography.bodyBold,
    color: colors.warning,
    fontSize: 18,
  },
  sectionCard: {
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    ...typography.h3,
    marginBottom: spacing.md,
  },
  eventsSection: {
    marginBottom: spacing.lg,
  },
  eventCard: {
    marginBottom: spacing.md,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.xs,
  },
  eventTitle: {
    ...typography.bodyBold,
    flex: 1,
    marginRight: spacing.sm,
  },
  eventSport: {
    ...typography.caption,
    color: colors.accentLime,
    backgroundColor: colors.accentLime + '20',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 4,
  },
  eventDate: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  eventAddress: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  eventFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  eventParticipants: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    textAlign: 'center',
  },
});
