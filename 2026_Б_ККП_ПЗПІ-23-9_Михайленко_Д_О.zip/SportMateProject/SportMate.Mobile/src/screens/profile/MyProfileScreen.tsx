import React, {useState, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';
import {useNavigation, useFocusEffect} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {ProfileStackParamList} from '../../types/navigation.types';
import {UsersAPI} from '../../api/users.api';
import {UserProfileResponse, EventListItemResponse} from '../../types/api.types';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {Button, Card, Avatar, Loading} from '../../components/common';
import {useAuthStore} from '../../store/auth.store';
import {format} from 'date-fns';
import {uk} from 'date-fns/locale';

type MyProfileNavigationProp = NativeStackNavigationProp<
  ProfileStackParamList,
  'MyProfile'
>;

export const MyProfileScreen: React.FC = () => {
  const navigation = useNavigation<MyProfileNavigationProp>();
  const {user, logout, updateUser} = useAuthStore();

  const [profile, setProfile] = useState<UserProfileResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadProfile = useCallback(async () => {
    try {
      setError(null);
      const data = await UsersAPI.getMyProfile();
      setProfile(data);
      const currentUser = useAuthStore.getState().user;
      if (currentUser) {
        updateUser({
          ...currentUser,
          firstName: data.firstName,
          lastName: data.lastName,
          rating: data.rating,
          avatarId: data.avatarId,
        });
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося завантажити профіль';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [updateUser]);

  useFocusEffect(
    useCallback(() => {
      loadProfile();
    }, [loadProfile]),
  );

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadProfile();
  };

  const handleLogout = async () => {
    await logout();
  };

  const handleEditProfile = () => {
    navigation.navigate('EditProfile');
  };

  const handleViewRatings = () => {
    navigation.navigate('MyRatings');
  };

  const handleEventPress = () => {
    navigation.navigate('PublicProfile', {userId: user?.userId || 0});
  };

  if (isLoading) {
    return <Loading />;
  }

  if (error || !profile) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>
          {error || 'Не вдалося завантажити профіль'}
        </Text>
        <Button title="Спробувати знову" onPress={loadProfile} />
      </View>
    );
  }

  const renderEventCard = (event: EventListItemResponse) => {
    const eventDate = format(new Date(event.eventDate), 'dd MMM yyyy, HH:mm', {
      locale: uk,
    });

    return (
      <TouchableOpacity
        key={event.eventId}
        onPress={handleEventPress}>
        <Card style={styles.eventCard}>
          <View style={styles.eventHeader}>
            <Text style={styles.eventTitle}>{event.title}</Text>
            <Text style={styles.eventSport}>{event.sportCategory.name}</Text>
          </View>
          <Text style={styles.eventDate}>📅 {eventDate}</Text>
          <Text style={styles.eventAddress}>📍 {event.address}</Text>
          <View style={styles.eventFooter}>
            <Text style={styles.eventParticipants}>
              👥 {event.participantCount}/{event.maxParticipants}
            </Text>
          </View>
        </Card>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.accentLime}
          />
        }>
        <View style={styles.header}>
          <Avatar
            size={80}
            firstName={profile.firstName}
            lastName={profile.lastName}
            avatarId={profile.avatarId}
          />
          <Text style={styles.name}>
            {profile.firstName} {profile.lastName}
          </Text>
          <Text style={styles.email}>{profile.email}</Text>
          <View style={styles.ratingContainer}>
            <Text style={styles.rating}>⭐ {profile.rating.toFixed(1)}</Text>
          </View>
        </View>

        <Card style={styles.statsCard}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{profile.completedEventsCount}</Text>
            <Text style={styles.statLabel}>Завершені події</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{profile.organizedEvents.length}</Text>
            <Text style={styles.statLabel}>Організовано</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>
              {profile.participatingEvents.length}
            </Text>
            <Text style={styles.statLabel}>Участь</Text>
          </View>
        </Card>

        <Card style={styles.actionsCard}>
          <Button
            title="✏️ Редагувати профіль"
            onPress={handleEditProfile}
            variant="secondary"
            fullWidth
          />
          <Button
            title="⭐ Мої рейтинги"
            onPress={handleViewRatings}
            variant="secondary"
            fullWidth
            style={styles.actionButton}
          />
        </Card>

        {profile.organizedEvents.length > 0 && (
          <View style={styles.eventsSection}>
            <Text style={styles.sectionTitle}>
              📅 Організовані події ({profile.organizedEvents.length})
            </Text>
            {profile.organizedEvents.map(renderEventCard)}
          </View>
        )}

        {profile.participatingEvents.length > 0 && (
          <View style={styles.eventsSection}>
            <Text style={styles.sectionTitle}>
              🏃 Участь у подіях ({profile.participatingEvents.length})
            </Text>
            {profile.participatingEvents.map(renderEventCard)}
          </View>
        )}

        <Button
          title="Вийти"
          variant="danger"
          onPress={handleLogout}
          fullWidth
          style={styles.logoutButton}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.lg,
    paddingVertical: spacing.lg,
  },
  name: {
    ...typography.h2,
    marginTop: spacing.md,
  },
  email: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  ratingContainer: {
    marginTop: spacing.sm,
  },
  rating: {
    ...typography.bodyBold,
    color: colors.warning,
    fontSize: 18,
  },
  statsCard: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    ...typography.h2,
    color: colors.accentLime,
    marginBottom: spacing.xs,
  },
  statLabel: {
    ...typography.caption,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  statDivider: {
    width: 1,
    backgroundColor: colors.border,
    marginHorizontal: spacing.sm,
  },
  actionsCard: {
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  actionButton: {
    marginTop: spacing.sm,
  },
  sectionTitle: {
    ...typography.h3,
    marginBottom: spacing.md,
  },
  eventsSection: {
    marginBottom: spacing.lg,
  },
  eventCard: {
    marginBottom: spacing.md,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.xs,
  },
  eventTitle: {
    ...typography.bodyBold,
    flex: 1,
    marginRight: spacing.sm,
  },
  eventSport: {
    ...typography.caption,
    color: colors.accentLime,
    backgroundColor: colors.accentLime + '20',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 4,
  },
  eventDate: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  eventAddress: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  eventFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  eventParticipants: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  logoutButton: {
    marginTop: spacing.lg,
    marginBottom: spacing.xl,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
});
