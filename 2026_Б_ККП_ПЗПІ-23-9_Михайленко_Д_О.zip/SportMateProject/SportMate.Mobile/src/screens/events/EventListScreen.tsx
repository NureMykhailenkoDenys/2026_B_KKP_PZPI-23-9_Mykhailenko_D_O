import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  TextInput,
  TouchableOpacity,
  Modal,
  ScrollView,
  Platform,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import {useNavigation, useFocusEffect} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {EventsStackParamList} from '../../types/navigation.types';
import {EventsAPI} from '../../api/events.api';
import {SportCategoriesAPI} from '../../api/sport-categories.api';
import {getSportEmoji} from '../../utils/sportEmoji';
import {useEventsStore} from '../../store/events.store';
import {
  EventListItemResponse,
  EventStatus,
  SportCategoryResponse,
} from '../../types/api.types';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {Card, Button, Loading} from '../../components/common';

type EventListNavigationProp = NativeStackNavigationProp<
  EventsStackParamList,
  'EventList'
>;

const EVENT_STATUS_LABELS: Record<EventStatus, string> = {
  [EventStatus.Planned]: 'Заплановано',
  [EventStatus.Active]: 'Активно',
  [EventStatus.Completed]: 'Завершено',
  [EventStatus.Cancelled]: 'Скасовано',
};

const formatDateForApi = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const formatDateForDisplay = (isoDate: string): string => {
  const [year, month, day] = isoDate.split('-').map(Number);
  const localDate = new Date(year, month - 1, day);
  return localDate.toLocaleDateString('uk-UA', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
};

export const EventListScreen: React.FC = () => {
  const navigation = useNavigation<EventListNavigationProp>();
  const {setEvents} = useEventsStore();

  const [events, setLocalEvents] = useState<EventListItemResponse[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<
    EventListItemResponse[]
  >([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');

  const [showFilters, setShowFilters] = useState(false);
  const [sportCategories, setSportCategories] = useState<
    SportCategoryResponse[]
  >([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<
    number | undefined
  >();
  const [selectedStatus, setSelectedStatus] = useState<EventStatus | undefined>(
    undefined,
  );
  const [selectedDate, setSelectedDate] = useState<string | undefined>();
  const [selectedAddress, setSelectedAddress] = useState<string | undefined>();

  const [draftCategoryId, setDraftCategoryId] = useState<
    number | undefined
  >();
  const [draftStatus, setDraftStatus] = useState<EventStatus | undefined>(
    undefined,
  );
  const [draftDate, setDraftDate] = useState<string | undefined>();
  const [draftAddress, setDraftAddress] = useState<string | undefined>();
  const [showDatePicker, setShowDatePicker] = useState(false);

  const loadEvents = useCallback(async (refresh = false) => {
    try {
      if (refresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      const filters: {
        sportCategoryId?: number;
        status?: EventStatus;
        date?: string;
        address?: string;
      } = {};

      if (selectedCategoryId) {
        filters.sportCategoryId = selectedCategoryId;
      }
      if (selectedStatus !== undefined) {
        filters.status = selectedStatus;
      }
      if (selectedDate) {
        filters.date = selectedDate;
      }
      if (selectedAddress) {
        filters.address = selectedAddress;
      }

      const data = await EventsAPI.getEvents(filters);
      setLocalEvents(data);
      setEvents(data);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося завантажити події';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [selectedCategoryId, selectedStatus, selectedDate, selectedAddress, setEvents]);

  const loadSportCategories = useCallback(async () => {
    try {
      const categories = await SportCategoriesAPI.getSportCategories();
      setSportCategories(categories);
    } catch (err) {
      console.log('Failed to load sport categories:', err);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadEvents();
      loadSportCategories();
    }, [loadEvents, loadSportCategories]),
  );

  const applySearch = useCallback(
    (eventsList: EventListItemResponse[], query: string) => {
      if (!query.trim()) {
        setFilteredEvents(eventsList);
        return;
      }

      const lowerQuery = query.toLowerCase();
      const filtered = eventsList.filter(
        event =>
          event.title.toLowerCase().includes(lowerQuery) ||
          event.sportCategory.name.toLowerCase().includes(lowerQuery) ||
          event.address.toLowerCase().includes(lowerQuery),
      );
      setFilteredEvents(filtered);
    },
    [],
  );

  useEffect(() => {
    applySearch(events, searchQuery);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchQuery, events]);

  const handleRefresh = () => {
    loadEvents(true);
  };

  const handleRetry = () => {
    loadEvents();
  };

  const handleEventPress = (eventId: number) => {
    navigation.navigate('EventDetails', {eventId});
  };

  const handleCreateEvent = () => {
    navigation.navigate('CreateEvent');
  };

  const openFilters = () => {
    setDraftCategoryId(selectedCategoryId);
    setDraftStatus(selectedStatus);
    setDraftDate(selectedDate);
    setDraftAddress(selectedAddress);
    setShowFilters(true);
  };

  const clearDraftFilters = () => {
    setDraftCategoryId(undefined);
    setDraftStatus(undefined);
    setDraftDate(undefined);
    setDraftAddress(undefined);
  };

  const handleApplyFilters = () => {
    setSelectedCategoryId(draftCategoryId);
    setSelectedStatus(draftStatus);
    setSelectedDate(draftDate);
    setSelectedAddress(draftAddress);
    setShowFilters(false);
  };

  const hasActiveFilters =
    selectedCategoryId !== undefined ||
    selectedStatus !== undefined ||
    selectedDate !== undefined ||
    selectedAddress !== undefined;

  const hasActiveDraftFilters =
    draftCategoryId !== undefined ||
    draftStatus !== undefined ||
    draftDate !== undefined ||
    draftAddress !== undefined;

  const handleDateChange = (event: any, date?: Date) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (date) {
      setDraftDate(formatDateForApi(date));
    }
  };

  const renderEventCard = ({item}: {item: EventListItemResponse}) => {
    const eventDate = new Date(item.eventDate);
    const formattedDate = eventDate.toLocaleDateString('uk-UA', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    const formattedTime = eventDate.toLocaleTimeString('uk-UA', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return (
      <TouchableOpacity
        onPress={() => handleEventPress(item.eventId)}
        activeOpacity={0.7}>
        <Card style={styles.eventCard}>
          <View style={styles.eventHeader}>
            <Text style={styles.eventTitle} numberOfLines={2}>
              {item.title}
            </Text>
            <View
              style={[
                styles.statusBadge,
                item.status === EventStatus.Cancelled && styles.statusCancelled,
                item.status === EventStatus.Completed && styles.statusCompleted,
              ]}>
              <Text style={styles.statusText}>
                {EVENT_STATUS_LABELS[item.status]}
              </Text>
            </View>
          </View>

          <View style={styles.eventInfo}>
            <Text style={styles.infoLabel}>
              {getSportEmoji(item.sportCategory.name)} {item.sportCategory.name}
            </Text>
          </View>

          <View style={styles.eventInfo}>
            <Text style={styles.infoLabel}>📅 {formattedDate}</Text>
          </View>

          <View style={styles.eventInfo}>
            <Text style={styles.infoLabel}>🕐 {formattedTime}</Text>
            <Text style={styles.infoValue}>
              {item.durationMinutes} хв
            </Text>
          </View>

          <View style={styles.eventInfo}>
            <Text style={styles.infoLabel} numberOfLines={1}>
              📍 {item.address}
            </Text>
          </View>

          <View style={styles.eventFooter}>
            <Text style={styles.participants}>
              👥 {item.participantCount} / {item.maxParticipants}
            </Text>
            <Text
              style={[
                styles.freeSlots,
                item.freeSlots === 0 && styles.freeSlotsZero,
              ]}>
              {item.freeSlots > 0
                ? `Вільно: ${item.freeSlots}`
                : 'Немає вільних місць'}
            </Text>
          </View>
        </Card>
      </TouchableOpacity>
    );
  };

  if (isLoading && !isRefreshing) {
    return <Loading fullScreen message="Завантаження подій..." />;
  }

  if (error && events.length === 0) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>❌ {error}</Text>
        <Button title="Повторити" onPress={handleRetry} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Пошук подій..."
          placeholderTextColor={colors.textSecondary}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <TouchableOpacity
          style={[styles.filterButton, hasActiveFilters && styles.filterActive]}
          onPress={openFilters}>
          <Text style={styles.filterButtonText}>
            {hasActiveFilters ? '🔍 Фільтри ✓' : '🔍 Фільтри'}
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.createButtonContainer}>
        <Button
          title="+ Створити подію"
          onPress={handleCreateEvent}
          fullWidth
        />
      </View>

      <FlatList
        data={filteredEvents}
        renderItem={renderEventCard}
        keyExtractor={item => item.eventId.toString()}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.accentLime}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>📭 Немає подій</Text>
            <Text style={styles.emptySubtext}>
              {searchQuery
                ? 'Спробуйте змінити пошуковий запит'
                : 'Створіть першу подію або змініть фільтри'}
            </Text>
          </View>
        }
      />

      <Modal
        visible={showFilters}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowFilters(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Фільтри</Text>
              <TouchableOpacity onPress={() => setShowFilters(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalBody}>
              <Text style={styles.filterLabel}>Спортивна категорія</Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.categoryScroll}>
                <TouchableOpacity
                  style={[
                    styles.categoryChip,
                    draftCategoryId === undefined && styles.categoryChipActive,
                  ]}
                  onPress={() => setDraftCategoryId(undefined)}>
                  <Text
                    style={[
                      styles.categoryChipText,
                      draftCategoryId === undefined &&
                        styles.categoryChipTextActive,
                    ]}>
                    Всі
                  </Text>
                </TouchableOpacity>
                {sportCategories.map(cat => (
                  <TouchableOpacity
                    key={cat.sportCategoryId}
                    style={[
                      styles.categoryChip,
                      draftCategoryId === cat.sportCategoryId &&
                        styles.categoryChipActive,
                    ]}
                    onPress={() => setDraftCategoryId(cat.sportCategoryId)}>
                    <Text
                      style={[
                        styles.categoryChipText,
                        draftCategoryId === cat.sportCategoryId &&
                          styles.categoryChipTextActive,
                      ]}>
                      {cat.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.filterLabel}>Статус</Text>
              <View style={styles.statusGrid}>
                <TouchableOpacity
                  style={[
                    styles.statusChip,
                    draftStatus === undefined && styles.statusChipActive,
                  ]}
                  onPress={() => setDraftStatus(undefined)}>
                  <Text
                    style={[
                      styles.statusChipText,
                      draftStatus === undefined &&
                        styles.statusChipTextActive,
                    ]}>
                    Всі
                  </Text>
                </TouchableOpacity>
                {Object.entries(EVENT_STATUS_LABELS).map(([key, label]) => (
                  <TouchableOpacity
                    key={key}
                    style={[
                      styles.statusChip,
                      draftStatus === Number(key) && styles.statusChipActive,
                    ]}
                    onPress={() => setDraftStatus(Number(key) as EventStatus)}>
                    <Text
                      style={[
                        styles.statusChipText,
                        draftStatus === Number(key) &&
                          styles.statusChipTextActive,
                      ]}>
                      {label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.filterLabel}>Дата</Text>
              <TouchableOpacity
                style={styles.dateButton}
                onPress={() => setShowDatePicker(true)}>
                <Text style={styles.dateButtonText}>
                  {draftDate
                    ? formatDateForDisplay(draftDate)
                    : 'Будь-яка дата'}
                </Text>
                <Text style={styles.dateButtonIcon}>📅</Text>
              </TouchableOpacity>
              {draftDate && (
                <TouchableOpacity onPress={() => setDraftDate(undefined)}>
                  <Text style={styles.dateResetText}>Скинути дату</Text>
                </TouchableOpacity>
              )}
              {showDatePicker && (
                <DateTimePicker
                  value={draftDate ? new Date(draftDate) : new Date()}
                  mode="date"
                  display="default"
                  onChange={handleDateChange}
                />
              )}

              <Text style={styles.filterLabel}>Адреса</Text>
              <TextInput
                style={styles.addressInput}
                placeholder="Наприклад: вул. Хрещатик"
                placeholderTextColor={colors.textSecondary}
                value={draftAddress ?? ''}
                onChangeText={text =>
                  setDraftAddress(text.trim() ? text : undefined)
                }
              />
            </ScrollView>

            <View style={styles.modalFooter}>
              {hasActiveDraftFilters && (
                <Button
                  title="Очистити фільтри"
                  onPress={clearDraftFilters}
                  variant="outline"
                  fullWidth
                  style={styles.clearFiltersButton}
                />
              )}
              <Button
                title="Застосувати"
                onPress={handleApplyFilters}
                fullWidth
              />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  searchContainer: {
    flexDirection: 'row',
    padding: spacing.md,
    gap: spacing.sm,
    backgroundColor: colors.surface,
  },
  searchInput: {
    flex: 1,
    height: 44,
    backgroundColor: colors.background,
    borderRadius: 8,
    paddingHorizontal: spacing.md,
    color: colors.textPrimary,
    ...typography.body,
  },
  filterButton: {
    paddingHorizontal: spacing.md,
    justifyContent: 'center',
    borderRadius: 8,
    backgroundColor: colors.background,
  },
  filterActive: {
    backgroundColor: colors.accentLime,
  },
  filterButtonText: {
    ...typography.body,
    color: colors.textPrimary,
  },
  createButtonContainer: {
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  listContent: {
    padding: spacing.md,
  },
  eventCard: {
    marginBottom: spacing.md,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.sm,
  },
  eventTitle: {
    ...typography.h3,
    flex: 1,
    marginRight: spacing.sm,
  },
  statusBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: 4,
    backgroundColor: colors.accentLime,
  },
  statusCancelled: {
    backgroundColor: colors.danger,
  },
  statusCompleted: {
    backgroundColor: colors.textSecondary,
  },
  statusText: {
    ...typography.caption,
    color: colors.background,
    fontWeight: '600',
  },
  eventInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  infoLabel: {
    ...typography.body,
    color: colors.textSecondary,
    flex: 1,
  },
  infoValue: {
    ...typography.body,
    color: colors.textPrimary,
  },
  eventFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.sm,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  participants: {
    ...typography.body,
    color: colors.textPrimary,
  },
  freeSlots: {
    ...typography.body,
    color: colors.accentLime,
    fontWeight: '600',
  },
  freeSlotsZero: {
    color: colors.danger,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: spacing.xl * 2,
  },
  emptyText: {
    ...typography.h2,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  emptySubtext: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    ...typography.h2,
  },
  modalClose: {
    ...typography.h2,
    color: colors.textSecondary,
  },
  modalBody: {
    padding: spacing.lg,
  },
  modalFooter: {
    padding: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    gap: spacing.sm,
  },
  filterLabel: {
    ...typography.h3,
    marginBottom: spacing.sm,
    marginTop: spacing.md,
  },
  categoryScroll: {
    marginBottom: spacing.md,
  },
  categoryChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    backgroundColor: colors.background,
    marginRight: spacing.sm,
  },
  categoryChipActive: {
    backgroundColor: colors.accentLime,
  },
  categoryChipText: {
    ...typography.body,
    color: colors.textPrimary,
  },
  categoryChipTextActive: {
    color: colors.background,
    fontWeight: '600',
  },
  statusGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  statusChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    backgroundColor: colors.background,
  },
  statusChipActive: {
    backgroundColor: colors.accentLime,
  },
  statusChipText: {
    ...typography.body,
    color: colors.textPrimary,
  },
  statusChipTextActive: {
    color: colors.background,
    fontWeight: '600',
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.background,
    borderRadius: 8,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
  },
  dateButtonText: {
    ...typography.body,
    color: colors.textPrimary,
  },
  dateButtonIcon: {
    ...typography.body,
  },
  dateResetText: {
    ...typography.caption,
    color: colors.accentLime,
    marginTop: spacing.xs,
    fontWeight: '600',
  },
  addressInput: {
    backgroundColor: colors.background,
    borderRadius: 8,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
    color: colors.textPrimary,
    ...typography.body,
  },
  clearFiltersButton: {
    backgroundColor: colors.surface,
    elevation: 0,
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {width: 0, height: 0},
  },
});
