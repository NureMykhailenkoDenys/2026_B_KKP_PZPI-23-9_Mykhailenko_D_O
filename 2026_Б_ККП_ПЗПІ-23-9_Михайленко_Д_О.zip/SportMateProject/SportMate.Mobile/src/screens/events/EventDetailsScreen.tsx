import React, {useState, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  TouchableOpacity,
} from 'react-native';
import {
  useNavigation,
  useRoute,
  useFocusEffect,
  RouteProp,
  CompositeNavigationProp,
} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {BottomTabNavigationProp} from '@react-navigation/bottom-tabs';
import MapView, {Marker, PROVIDER_GOOGLE} from 'react-native-maps';
import {
  EventsStackParamList,
  MainTabParamList,
} from '../../types/navigation.types';
import {EventsAPI} from '../../api/events.api';
import {
  EventResponse,
  EventStatus,
  EventParticipantResponse,
} from '../../types/api.types';
import {useAuthStore} from '../../store/auth.store';
import {getSportEmoji} from '../../utils/sportEmoji';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {Card, Button, Loading, Avatar} from '../../components/common';

type EventDetailsRouteProp = RouteProp<EventsStackParamList, 'EventDetails'>;
type EventDetailsNavigationProp = CompositeNavigationProp<
  NativeStackNavigationProp<EventsStackParamList, 'EventDetails'>,
  BottomTabNavigationProp<MainTabParamList>
>;

const EVENT_STATUS_LABELS: Record<EventStatus, string> = {
  [EventStatus.Planned]: 'Заплановано',
  [EventStatus.Active]: 'Активно',
  [EventStatus.Completed]: 'Завершено',
  [EventStatus.Cancelled]: 'Скасовано',
};

export const EventDetailsScreen: React.FC = () => {
  const navigation = useNavigation<EventDetailsNavigationProp>();
  const route = useRoute<EventDetailsRouteProp>();
  const {eventId} = route.params;
  const {user} = useAuthStore();

  const [event, setEvent] = useState<EventResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isJoining, setIsJoining] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [participants, setParticipants] = useState<EventParticipantResponse[]>(
    [],
  );
  const [isLoadingParticipants, setIsLoadingParticipants] = useState(true);
  const [participantsError, setParticipantsError] = useState<string | null>(
    null,
  );

  const loadEvent = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await EventsAPI.getEventById(eventId);
      setEvent(data);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося завантажити подію';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [eventId]);

  const loadParticipants = useCallback(async () => {
    try {
      setIsLoadingParticipants(true);
      setParticipantsError(null);
      const data = await EventsAPI.getParticipants(eventId);
      setParticipants(data);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося завантажити учасників';
      setParticipantsError(errorMessage);
    } finally {
      setIsLoadingParticipants(false);
    }
  }, [eventId]);

  useFocusEffect(
    useCallback(() => {
      loadEvent();
      loadParticipants();
    }, [loadEvent, loadParticipants]),
  );

  const currentUserId = user?.userId;
  const isParticipant =
    currentUserId !== undefined &&
    participants.some(p => p.userId === currentUserId);

  const handleJoin = async () => {
    if (!event) return;

    try {
      setIsJoining(true);
      await EventsAPI.joinEvent(event.eventId);
      Alert.alert('Успіх', 'Ви приєдналися до події');
      await Promise.all([loadEvent(), loadParticipants()]);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося приєднатися до події';
      Alert.alert('Помилка', errorMessage);
    } finally {
      setIsJoining(false);
    }
  };

  const handleLeave = async () => {
    if (!event) return;

    Alert.alert(
      'Підтвердження',
      'Ви дійсно хочете вийти з події?',
      [
        {text: 'Скасувати', style: 'cancel'},
        {
          text: 'Вийти',
          style: 'destructive',
          onPress: async () => {
            try {
              setIsLeaving(true);
              await EventsAPI.leaveEvent(event.eventId);
              Alert.alert('Успіх', 'Ви вийшли з події');
              await Promise.all([loadEvent(), loadParticipants()]);
            } catch (err: any) {
              const errorMessage =
                err.response?.data?.message ||
                err.message ||
                'Не вдалося вийти з події';
              Alert.alert('Помилка', errorMessage);
            } finally {
              setIsLeaving(false);
            }
          },
        },
      ],
    );
  };

  const handleCancel = async () => {
    if (!event) return;

    Alert.alert(
      'Підтвердження',
      'Ви дійсно хочете скасувати подію? Цю дію не можна скасувати.',
      [
        {text: 'Ні', style: 'cancel'},
        {
          text: 'Так, скасувати',
          style: 'destructive',
          onPress: async () => {
            try {
              setIsCancelling(true);
              await EventsAPI.cancelEvent(event.eventId);
              Alert.alert('Успіх', 'Подію скасовано');
              await loadEvent();
            } catch (err: any) {
              const errorMessage =
                err.response?.data?.message ||
                err.message ||
                'Не вдалося скасувати подію';
              Alert.alert('Помилка', errorMessage);
            } finally {
              setIsCancelling(false);
            }
          },
        },
      ],
    );
  };

  const handleEdit = () => {
    if (!event) return;
    navigation.navigate('EditEvent', {eventId: event.eventId});
  };

  const handleOpenChat = () => {
    if (!event) return;
    navigation.navigate('EventChat', {eventId: event.eventId});
  };

  const handleOpenEventRatings = () => {
    if (!event) return;
    navigation.navigate('EventRatings', {eventId: event.eventId});
  };

  const handleRateParticipant = (targetUserId: number) => {
    if (!event) return;
    navigation.navigate('CreateRating', {
      eventId: event.eventId,
      targetUserId,
    });
  };

  const handleOpenProfile = (targetUserId: number) => {
    if (currentUserId !== undefined && targetUserId === currentUserId) {
      navigation.getParent<BottomTabNavigationProp<MainTabParamList>>()?.navigate(
        'Profile',
        {screen: 'MyProfile'},
      );
      return;
    }
    navigation.navigate('PublicProfile', {userId: targetUserId});
  };

  const handleRetry = () => {
    loadEvent();
    loadParticipants();
  };

  const handleRetryParticipants = () => {
    loadParticipants();
  };

  if (isLoading) {
    return <Loading fullScreen message="Завантаження події..." />;
  }

  if (error || !event) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>{'❌ ' + (error || 'Подію не знайдено')}</Text>
        <Button title="Повторити" onPress={handleRetry} />
      </View>
    );
  }

  const {latitude, longitude} = event;

  const eventDate = new Date(event.eventDate);
  const formattedDate = eventDate.toLocaleDateString('uk-UA', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const formattedTime = eventDate.toLocaleTimeString('uk-UA', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const isOrganizer = user?.userId === event.organizer.userId;
  const isCancelled = event.status === EventStatus.Cancelled;
  const isCompleted = event.status === EventStatus.Completed;

  const participantsReady = !isLoadingParticipants;

  const canJoin = participantsReady && !isOrganizer && !isCancelled && !isCompleted && event.freeSlots > 0 && !isParticipant;

  const canLeave = participantsReady && !isOrganizer && !isCancelled && !isCompleted && isParticipant;

  const canEdit = isOrganizer && !isCancelled && !isCompleted;
  const canCancel = isOrganizer && !isCancelled && !isCompleted;

  const canAccessChat = participantsReady && (isOrganizer || isParticipant) && !isCancelled;

  const canViewEventRatings = isCompleted;
  const canRateParticipants =
    participantsReady && isCompleted && (isOrganizer || isParticipant);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View
        style={[
          styles.statusBadge,
          isCancelled && styles.statusCancelled,
          isCompleted && styles.statusCompleted,
        ]}>
        <Text style={styles.statusText}>
          {EVENT_STATUS_LABELS[event.status]}
        </Text>
      </View>

      <Text style={styles.title}>{event.title}</Text>

      <Card style={styles.section}>
        <Text style={styles.sectionLabel}>Вид спорту</Text>
        <Text style={styles.sectionValue}>
          {getSportEmoji(event.sportCategory.name) + ' ' + event.sportCategory.name}
        </Text>
      </Card>

      <Card style={styles.section}>
        <Text style={styles.sectionLabel}>Дата та час</Text>
        <Text style={styles.sectionValue}>{'📅 ' + formattedDate}</Text>
        <Text style={styles.sectionValue}>{'🕐 ' + formattedTime}</Text>
        <Text style={styles.sectionValue}>{'⏱️ ' + event.durationMinutes + ' хвилин'}</Text>
      </Card>

      <Card style={styles.section}>
        <Text style={styles.sectionLabel}>Місце проведення</Text>
        <Text style={styles.sectionValue}>{'📍 ' + event.address}</Text>
        {latitude && longitude ? (
          <MapView
            style={styles.map}
            provider={PROVIDER_GOOGLE}
            initialRegion={{
              latitude,
              longitude,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01,
            }}
            scrollEnabled={false}
            zoomEnabled={false}
            pitchEnabled={false}
            rotateEnabled={false}>
            <Marker coordinate={{latitude, longitude}} />
          </MapView>
        ) : (
          <Text style={styles.coordinates}>
            Координати місця не вказані
          </Text>
        )}
      </Card>

      <Card style={styles.section}>
        <Text style={styles.sectionLabel}>Учасники</Text>
        <View style={styles.participantsRow}>
          <Text style={styles.sectionValue}>
            {'👥 ' + event.participantCount + ' / ' + event.maxParticipants}
          </Text>
          <Text
            style={[
              styles.freeSlots,
              event.freeSlots === 0 && styles.freeSlotsZero,
            ]}>
            {event.freeSlots > 0
              ? 'Вільно: ' + event.freeSlots
              : 'Немає вільних місць'}
          </Text>
        </View>

        <View style={styles.participantsListDivider} />

        {isLoadingParticipants && participants.length === 0 ? (
          <Loading message="Завантаження учасників..." />
        ) : participantsError ? (
          <View>
            <Text style={styles.errorTextInline}>
              {'❌ ' + participantsError}
            </Text>
            <Button
              title="Повторити"
              onPress={handleRetryParticipants}
              variant="outline"
            />
          </View>
        ) : participants.length === 0 ? (
          <Text style={styles.emptyParticipantsText}>
            Поки немає учасників
          </Text>
        ) : (
          <View style={styles.participantsList}>
            {participants.map(participant => {
              const canRateThisParticipant =
                canRateParticipants && participant.userId !== currentUserId;

              return (
                <View key={participant.userId} style={styles.participantRow}>
                  <TouchableOpacity
                    style={styles.participantTouchable}
                    activeOpacity={0.6}
                    onPress={() => handleOpenProfile(participant.userId)}>
                    <Avatar
                      firstName={participant.firstName}
                      lastName={participant.lastName}
                      avatarId={participant.avatarId}
                      size={40}
                    />
                    <View style={styles.participantInfo}>
                      <Text style={styles.participantName} numberOfLines={1}>
                        {participant.firstName + ' ' + participant.lastName}
                      </Text>
                      <Text style={styles.participantRating}>
                        {'⭐ ' + participant.rating.toFixed(1)}
                      </Text>
                    </View>
                  </TouchableOpacity>
                  {canRateThisParticipant && (
                    <TouchableOpacity
                      style={styles.rateButton}
                      activeOpacity={0.6}
                      onPress={() => handleRateParticipant(participant.userId)}>
                      <Text style={styles.rateButtonText}>⭐ Оцінити</Text>
                    </TouchableOpacity>
                  )}
                </View>
              );
            })}
          </View>
        )}
      </Card>

      {event.description && (
        <Card style={styles.section}>
          <Text style={styles.sectionLabel}>Опис</Text>
          <Text style={styles.description}>{event.description}</Text>
        </Card>
      )}

      <Card style={styles.section}>
        <Text style={styles.sectionLabel}>Організатор</Text>
        <TouchableOpacity
          style={styles.organizerRow}
          activeOpacity={0.6}
          onPress={() => handleOpenProfile(event.organizer.userId)}>
          <Avatar
            firstName={event.organizer.firstName}
            lastName={event.organizer.lastName}
            avatarId={event.organizer.avatarId}
            size={48}
          />
          <View style={styles.organizerInfo}>
            <Text style={styles.organizerName}>
              {event.organizer.firstName + ' ' + event.organizer.lastName}
            </Text>
            <Text style={styles.organizerRating}>
              {'⭐ Рейтинг: ' + event.organizer.rating.toFixed(1)}
            </Text>
          </View>
        </TouchableOpacity>
      </Card>

      <View style={styles.actions}>
        {canJoin && (
          <Button
            title="Приєднатися"
            onPress={handleJoin}
            loading={isJoining}
            disabled={isJoining}
            fullWidth
          />
        )}

        {canLeave && (
          <Button
            title="Вийти"
            onPress={handleLeave}
            loading={isLeaving}
            disabled={isLeaving}
            variant="outline"
            fullWidth
            style={styles.leaveEventButton}
            numberOfLines={1}
            adjustsFontSizeToFit
          />
        )}

        {canAccessChat && (
          <Button
            title="Чат події"
            onPress={handleOpenChat}
            variant="secondary"
            fullWidth
            style={styles.chatButton}
            numberOfLines={1}
            adjustsFontSizeToFit
          />
        )}

        {canEdit && (
          <Button
            title="Редагувати"
            onPress={handleEdit}
            variant="secondary"
            fullWidth
          />
        )}

        {canCancel && (
          <Button
            title="Скасувати подію"
            onPress={handleCancel}
            loading={isCancelling}
            disabled={isCancelling}
            variant="danger"
            fullWidth
          />
        )}

        {canViewEventRatings && (
          <Button
            title="Відгуки про подію"
            onPress={handleOpenEventRatings}
            variant="outline"
            fullWidth
            style={styles.eventRatingsButton}
          />
        )}
      </View>

      <Text style={styles.createdAt}>
        {'Створено: ' + new Date(event.createdAt).toLocaleDateString('uk-UA')}
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 8,
    backgroundColor: colors.accentLime,
    marginBottom: spacing.md,
  },
  statusCancelled: {
    backgroundColor: colors.danger,
  },
  statusCompleted: {
    backgroundColor: colors.textSecondary,
  },
  statusText: {
    ...typography.body,
    color: colors.background,
    fontWeight: '600',
  },
  title: {
    ...typography.h1,
    marginBottom: spacing.lg,
  },
  section: {
    marginBottom: spacing.md,
  },
  sectionLabel: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    textTransform: 'uppercase',
  },
  sectionValue: {
    ...typography.body,
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  coordinates: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  map: {
    width: '100%',
    height: 180,
    borderRadius: 8,
    marginTop: spacing.xs,
  },
  participantsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  freeSlots: {
    ...typography.body,
    color: colors.accentLime,
    fontWeight: '600',
  },
  freeSlotsZero: {
    color: colors.danger,
  },
  participantsListDivider: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    marginTop: spacing.sm,
    marginBottom: spacing.sm,
  },
  participantsList: {
    gap: spacing.sm,
  },
  participantRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.xs,
  },
  participantTouchable: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  participantInfo: {
    marginLeft: spacing.sm,
    flex: 1,
  },
  rateButton: {
    marginLeft: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 8,
    backgroundColor: colors.accentLime + '20',
  },
  rateButtonText: {
    ...typography.caption,
    color: colors.accentLime,
    fontWeight: '600',
  },
  participantName: {
    ...typography.body,
    color: colors.textPrimary,
  },
  participantRating: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  emptyParticipantsText: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingVertical: spacing.sm,
  },
  errorTextInline: {
    ...typography.body,
    color: colors.danger,
    marginBottom: spacing.sm,
  },
  description: {
    ...typography.body,
    color: colors.textPrimary,
    lineHeight: 22,
  },
  organizerRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  organizerInfo: {
    marginLeft: spacing.md,
    flex: 1,
  },
  organizerName: {
    ...typography.h3,
    marginBottom: spacing.xs,
  },
  organizerRating: {
    ...typography.body,
    color: colors.textSecondary,
  },
  actions: {
    gap: spacing.md,
    marginTop: spacing.md,
  },
  leaveEventButton: {
    minHeight: 52,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.surface,
    elevation: 0,
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {width: 0, height: 0},
  },
  chatButton: {
    minHeight: 52,
    paddingHorizontal: spacing.md,
  },
  eventRatingsButton: {
    backgroundColor: colors.surface,
    elevation: 0,
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {width: 0, height: 0},
  },
  createdAt: {
    ...typography.caption,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.lg,
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
});
