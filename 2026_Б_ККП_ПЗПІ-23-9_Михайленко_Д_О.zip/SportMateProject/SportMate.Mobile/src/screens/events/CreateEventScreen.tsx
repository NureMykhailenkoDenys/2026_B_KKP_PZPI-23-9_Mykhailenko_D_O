import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  TouchableOpacity,
  Modal,
  Platform,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import MapView, {
  Marker,
  PROVIDER_GOOGLE,
  MapPressEvent,
  MarkerDragStartEndEvent,
} from 'react-native-maps';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {EventsStackParamList} from '../../types/navigation.types';
import {EventsAPI} from '../../api/events.api';
import {SportCategoriesAPI} from '../../api/sport-categories.api';
import {GeocodingAPI} from '../../api/geocoding.api';
import {SportCategoryResponse} from '../../types/api.types';
import {VALIDATION} from '../../utils/constants';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';
import {typography} from '../../theme/typography';
import {Input, Button, Card} from '../../components/common';

type CreateEventNavigationProp = NativeStackNavigationProp<
  EventsStackParamList,
  'CreateEvent'
>;

const DEFAULT_MAP_REGION = {
  latitude: 50.4501,
  longitude: 30.5234,
  latitudeDelta: 5,
  longitudeDelta: 5,
};

export const CreateEventScreen: React.FC = () => {
  const navigation = useNavigation<CreateEventNavigationProp>();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [sportCategoryId, setSportCategoryId] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [durationMinutes, setDurationMinutes] = useState('');
  const [maxParticipants, setMaxParticipants] = useState('');
  const [address, setAddress] = useState('');
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [location, setLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);

  const geocodeRequestIdRef = useRef(0);

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);

  const [titleError, setTitleError] = useState('');
  const [sportCategoryError, setSportCategoryError] = useState('');
  const [dateError, setDateError] = useState('');
  const [durationError, setDurationError] = useState('');
  const [participantsError, setParticipantsError] = useState('');
  const [locationError, setLocationError] = useState('');

  const [sportCategories, setSportCategories] = useState<
    SportCategoryResponse[]
  >([]);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);

  useEffect(() => {
    loadSportCategories();
  }, []);

  const loadSportCategories = async () => {
    try {
      setIsLoadingCategories(true);
      const categories = await SportCategoriesAPI.getSportCategories();
      setSportCategories(categories);
    } catch {
      Alert.alert(
        'Помилка',
        'Не вдалося завантажити спортивні категорії. Спробуйте ще раз.',
      );
    } finally {
      setIsLoadingCategories(false);
    }
  };

  const validateTitle = (value: string): boolean => {
    if (!value.trim()) {
      setTitleError('Назва обов\'язкова');
      return false;
    }
    if (value.trim().length < 3) {
      setTitleError('Назва має містити мінімум 3 символи');
      return false;
    }
    setTitleError('');
    return true;
  };

  const validateSportCategory = (): boolean => {
    if (!sportCategoryId) {
      setSportCategoryError('Виберіть спортивну категорію');
      return false;
    }
    setSportCategoryError('');
    return true;
  };

  const validateDate = (): boolean => {
    if (selectedDate < new Date()) {
      setDateError('Дата не може бути в минулому');
      return false;
    }
    setDateError('');
    return true;
  };

  const validateDuration = (value: string): boolean => {
    if (!value.trim()) {
      setDurationError('Тривалість обов\'язкова');
      return false;
    }
    const duration = parseInt(value, 10);
    if (isNaN(duration) || duration < 15) {
      setDurationError('Мінімум 15 хвилин');
      return false;
    }
    if (duration > 480) {
      setDurationError('Максимум 480 хвилин (8 годин)');
      return false;
    }
    setDurationError('');
    return true;
  };

  const validateParticipants = (value: string): boolean => {
    if (!value.trim()) {
      setParticipantsError('Кількість учасників обов\'язкова');
      return false;
    }
    const count = parseInt(value, 10);
    if (isNaN(count) || count < VALIDATION.MIN_EVENT_PARTICIPANTS) {
      setParticipantsError(
        `Мінімум ${VALIDATION.MIN_EVENT_PARTICIPANTS} учасники`,
      );
      return false;
    }
    if (count > VALIDATION.MAX_EVENT_PARTICIPANTS) {
      setParticipantsError(
        `Максимум ${VALIDATION.MAX_EVENT_PARTICIPANTS} учасників`,
      );
      return false;
    }
    setParticipantsError('');
    return true;
  };

  const validateLocation = (): boolean => {
    if (!location) {
      setLocationError('Оберіть місце проведення на карті');
      return false;
    }
    if (isGeocoding) {
      setLocationError('Зачекайте, поки визначається адреса');
      return false;
    }
    if (!address) {
      setLocationError(
        'Не вдалося визначити адресу для цієї точки. Спробуйте іншу точку на карті.',
      );
      return false;
    }
    setLocationError('');
    return true;
  };

  const reverseGeocode = async (latitude: number, longitude: number) => {
    const requestId = ++geocodeRequestIdRef.current;
    setIsGeocoding(true);
    setAddress('');
    setLocationError('');

    try {
      const formattedAddress = await GeocodingAPI.reverseGeocode(
        latitude,
        longitude,
      );

      if (requestId !== geocodeRequestIdRef.current) {
        return;
      }

      if (formattedAddress) {
        setAddress(formattedAddress);
      } else {
        setLocationError(
          'Не вдалося визначити адресу для цієї точки. Спробуйте іншу точку на карті.',
        );
      }
    } catch {
      if (requestId === geocodeRequestIdRef.current) {
        setLocationError(
          'Не вдалося визначити адресу. Перевірте інтернет-з\'єднання.',
        );
      }
    } finally {
      if (requestId === geocodeRequestIdRef.current) {
        setIsGeocoding(false);
      }
    }
  };

  const handleDateChange = (event: any, date?: Date) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (date) {
      setSelectedDate(date);
      setDateError('');
    }
  };

  const handleTimeChange = (event: any, date?: Date) => {
    setShowTimePicker(Platform.OS === 'ios');
    if (date) {
      const newDate = new Date(selectedDate);
      newDate.setHours(date.getHours());
      newDate.setMinutes(date.getMinutes());
      setSelectedDate(newDate);
    }
  };

  const handleMapPress = (event: MapPressEvent) => {
    const {latitude, longitude} = event.nativeEvent.coordinate;
    setLocation({latitude, longitude});
    reverseGeocode(latitude, longitude);
  };

  const handleMarkerDragEnd = (event: MarkerDragStartEndEvent) => {
    const {latitude, longitude} = event.nativeEvent.coordinate;
    setLocation({latitude, longitude});
    reverseGeocode(latitude, longitude);
  };

  const handleCreate = async () => {
    const isTitleValid = validateTitle(title);
    const isCategoryValid = validateSportCategory();
    const isDateValid = validateDate();
    const isDurationValid = validateDuration(durationMinutes);
    const isParticipantsValid = validateParticipants(maxParticipants);
    const isLocationValid = validateLocation();

    if (
      !isTitleValid ||
      !isCategoryValid ||
      !isDateValid ||
      !isDurationValid ||
      !isParticipantsValid ||
      !isLocationValid ||
      !location
    ) {
      return;
    }

    try {
      setIsLoading(true);

      const data = {
        title: title.trim(),
        description: description.trim() || undefined,
        sportCategoryId: sportCategoryId!,
        eventDate: selectedDate.toISOString(),
        durationMinutes: parseInt(durationMinutes, 10),
        maxParticipants: parseInt(maxParticipants, 10),
        address: address.trim(),
        latitude: location.latitude,
        longitude: location.longitude,
      };

      const createdEvent = await EventsAPI.createEvent(data);

      Alert.alert('Успіх', 'Подію створено', [
        {
          text: 'OK',
          onPress: () => {
            navigation.replace('EventDetails', {eventId: createdEvent.eventId});
          },
        },
      ]);
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.message ||
        err.message ||
        'Не вдалося створити подію';
      Alert.alert('Помилка', errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const selectedCategory = sportCategories.find(
    cat => cat.sportCategoryId === sportCategoryId,
  );

  const formattedDate = selectedDate.toLocaleDateString('uk-UA', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const formattedTime = selectedDate.toLocaleTimeString('uk-UA', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Card style={styles.form}>
        <Input
          label="Назва події"
          placeholder="Наприклад: Вечірній футбол"
          value={title}
          onChangeText={text => {
            setTitle(text);
            if (titleError) validateTitle(text);
          }}
          onBlur={() => validateTitle(title)}
          error={titleError}
          editable={!isLoading}
        />

        <Input
          label="Опис (необов'язково)"
          placeholder="Додайте деталі про подію..."
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={4}
          editable={!isLoading}
        />

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Спортивна категорія</Text>
          <TouchableOpacity
            style={[
              styles.picker,
              sportCategoryError && styles.pickerError,
            ]}
            onPress={() => setShowCategoryPicker(true)}
            disabled={isLoading || isLoadingCategories}>
            <Text
              style={[
                styles.pickerText,
                !selectedCategory && styles.pickerPlaceholder,
              ]}>
              {selectedCategory?.name || 'Виберіть категорію'}
            </Text>
            <Text style={styles.pickerArrow}>▼</Text>
          </TouchableOpacity>
          {sportCategoryError && (
            <Text style={styles.errorText}>{sportCategoryError}</Text>
          )}
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Дата події</Text>
          <TouchableOpacity
            style={[styles.picker, dateError && styles.pickerError]}
            onPress={() => setShowDatePicker(true)}
            disabled={isLoading}>
            <Text style={styles.pickerText}>{formattedDate}</Text>
            <Text style={styles.pickerArrow}>📅</Text>
          </TouchableOpacity>
          {dateError && <Text style={styles.errorText}>{dateError}</Text>}
        </View>

        {showDatePicker && (
          <DateTimePicker
            value={selectedDate}
            mode="date"
            display="default"
            onChange={handleDateChange}
            minimumDate={new Date()}
          />
        )}

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Час події</Text>
          <TouchableOpacity
            style={styles.picker}
            onPress={() => setShowTimePicker(true)}
            disabled={isLoading}>
            <Text style={styles.pickerText}>{formattedTime}</Text>
            <Text style={styles.pickerArrow}>🕐</Text>
          </TouchableOpacity>
        </View>

        {showTimePicker && (
          <DateTimePicker
            value={selectedDate}
            mode="time"
            display="default"
            onChange={handleTimeChange}
          />
        )}

        <Input
          label="Тривалість (хвилини)"
          placeholder="Наприклад: 90"
          value={durationMinutes}
          onChangeText={text => {
            setDurationMinutes(text);
            if (durationError) validateDuration(text);
          }}
          onBlur={() => validateDuration(durationMinutes)}
          error={durationError}
          keyboardType="numeric"
          editable={!isLoading}
        />

        <Input
          label="Максимальна кількість учасників"
          placeholder={`Від ${VALIDATION.MIN_EVENT_PARTICIPANTS} до ${VALIDATION.MAX_EVENT_PARTICIPANTS}`}
          value={maxParticipants}
          onChangeText={text => {
            setMaxParticipants(text);
            if (participantsError) validateParticipants(text);
          }}
          onBlur={() => validateParticipants(maxParticipants)}
          error={participantsError}
          keyboardType="numeric"
          editable={!isLoading}
        />

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Місце на карті</Text>
          <MapView
            style={styles.map}
            provider={PROVIDER_GOOGLE}
            initialRegion={DEFAULT_MAP_REGION}
            onPress={handleMapPress}>
            {location && (
              <Marker
                coordinate={location}
                draggable
                onDragEnd={handleMarkerDragEnd}
              />
            )}
          </MapView>
          <Text style={styles.mapHint}>
            Натисніть на карту або перетягніть маркер, щоб обрати місце
            проведення
          </Text>

          <Text style={[styles.label, styles.addressLabel]}>Адреса</Text>
          {isGeocoding ? (
            <Text style={styles.mapHint}>Визначення адреси...</Text>
          ) : address ? (
            <Text style={styles.addressValue}>{address}</Text>
          ) : (
            <Text style={styles.mapHint}>
              Адреса з'явиться після вибору точки на карті
            </Text>
          )}

          {locationError && (
            <Text style={styles.errorText}>{locationError}</Text>
          )}
        </View>

        <Button
          title="Створити подію"
          onPress={handleCreate}
          loading={isLoading}
          disabled={isLoading || isLoadingCategories}
          fullWidth
        />
      </Card>

      <Modal
        visible={showCategoryPicker}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowCategoryPicker(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Виберіть категорію</Text>
              <TouchableOpacity onPress={() => setShowCategoryPicker(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalBody}>
              {sportCategories.map(category => (
                <TouchableOpacity
                  key={category.sportCategoryId}
                  style={[
                    styles.categoryOption,
                    sportCategoryId === category.sportCategoryId &&
                      styles.categoryOptionSelected,
                  ]}
                  onPress={() => {
                    setSportCategoryId(category.sportCategoryId);
                    setSportCategoryError('');
                    setShowCategoryPicker(false);
                  }}>
                  <Text
                    style={[
                      styles.categoryOptionText,
                      sportCategoryId === category.sportCategoryId &&
                        styles.categoryOptionTextSelected,
                    ]}>
                    {category.name}
                  </Text>
                  {sportCategoryId === category.sportCategoryId && (
                    <Text style={styles.checkmark}>✓</Text>
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
  },
  form: {
    gap: spacing.md,
  },
  inputContainer: {
    marginBottom: spacing.md,
  },
  label: {
    ...typography.body,
    color: colors.textPrimary,
    marginBottom: spacing.xs,
    fontWeight: '600',
  },
  picker: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
  },
  pickerError: {
    borderColor: colors.danger,
  },
  pickerText: {
    ...typography.body,
    color: colors.textPrimary,
    flex: 1,
  },
  pickerPlaceholder: {
    color: colors.textSecondary,
  },
  pickerArrow: {
    ...typography.body,
    color: colors.textSecondary,
  },
  errorText: {
    ...typography.caption,
    color: colors.danger,
    marginTop: spacing.xs,
  },
  map: {
    width: '100%',
    height: 220,
    borderRadius: 8,
  },
  mapHint: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  addressLabel: {
    marginTop: spacing.md,
  },
  addressValue: {
    ...typography.body,
    color: colors.textPrimary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    maxHeight: '70%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    ...typography.h2,
  },
  modalClose: {
    ...typography.h2,
    color: colors.textSecondary,
  },
  modalBody: {
    padding: spacing.md,
  },
  categoryOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.md,
    borderRadius: 8,
    marginBottom: spacing.xs,
    backgroundColor: colors.background,
  },
  categoryOptionSelected: {
    backgroundColor: colors.accentLime,
  },
  categoryOptionText: {
    ...typography.body,
    color: colors.textPrimary,
  },
  categoryOptionTextSelected: {
    color: colors.background,
    fontWeight: '600',
  },
  checkmark: {
    ...typography.h3,
    color: colors.background,
  },
});
