import React, {useState, useEffect, useRef, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import {EventsStackScreenProps} from '../../types/navigation.types';
import {ChatMessageResponse} from '../../types/api.types';
import {ChatAPI} from '../../api/chat.api';
import signalRService from '../../services/signalr.service';
import {useAuthStore} from '../../store/auth.store';
import {colors} from '../../theme/colors';
import {spacing} from '../../theme/spacing';

type Props = EventsStackScreenProps<'EventChat'>;

const MAX_MESSAGE_LENGTH = 2000;

const isParticipationError = (err: unknown): boolean => {
  const message = err instanceof Error ? err.message : String(err);
  return message.toLowerCase().includes('is not a participant');
};

export const EventChatScreen: React.FC<Props> = ({route, navigation}) => {
  const {eventId} = route.params;
  const currentUser = useAuthStore((state: any) => state.user);

  const [messages, setMessages] = useState<ChatMessageResponse[]>([]);
  const [messageText, setMessageText] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loadingMore, setLoadingMore] = useState(false);

  const flatListRef = useRef<FlatList>(null);

  const loadMessages = useCallback(async () => {
    try {
      setError(null);
      const data = await ChatAPI.getChatHistory(eventId, 1, 50);
      setMessages(data.items.reverse()); // Reverse to show newest at bottom
      setCurrentPage(data.page);
      setTotalPages(data.totalPages);
    } catch (err: any) {
      if (err.response?.status === 403) {
        setError('Доступ заборонено. Тільки учасники можуть бачити чат.');
      } else {
        setError('Не вдалося завантажити повідомлення');
      }
      console.error('Load messages error:', err);
    } finally {
      setLoading(false);
    }
  }, [eventId]);

  const loadMoreMessages = useCallback(async () => {
    if (loadingMore || currentPage >= totalPages) {
      return;
    }

    try {
      setLoadingMore(true);
      const nextPage = currentPage + 1;
      const data = await ChatAPI.getChatHistory(eventId, nextPage, 50);
      setMessages(prev => [...data.items.reverse(), ...prev]);
      setCurrentPage(data.page);
      setTotalPages(data.totalPages);
    } catch (err) {
      console.error('Load more messages error:', err);
    } finally {
      setLoadingMore(false);
    }
  }, [eventId, currentPage, totalPages, loadingMore]);

  useEffect(() => {
    let mounted = true;

    const setupSignalR = async () => {
      try {
        await signalRService.connect();
        await signalRService.joinEventChat(eventId);

        signalRService.onReceiveMessage((message: ChatMessageResponse) => {
          if (mounted && message.eventId === eventId) {
            setMessages(prev => [...prev, message]);
            setTimeout(() => {
              flatListRef.current?.scrollToEnd({animated: true});
            }, 100);
          }
        });
      } catch (err) {
        console.error('SignalR setup error:', err);
        if (mounted && isParticipationError(err)) {
          Alert.alert(
            'Немає доступу',
            'Ви більше не є учасником цієї події',
            [{text: 'OK', onPress: () => navigation.goBack()}],
          );
        }
      }
    };

    setupSignalR();

    return () => {
      mounted = false;
      signalRService.offReceiveMessage();
      signalRService.leaveEventChat(eventId).catch(err => {
        console.error('Leave event chat error:', err);
      });
    };
  }, [eventId, navigation]);

  useEffect(() => {
    loadMessages();
  }, [loadMessages]);

  const handleSend = async () => {
    const trimmed = messageText.trim();
    if (!trimmed || sending) {
      return;
    }

    if (trimmed.length > MAX_MESSAGE_LENGTH) {
      return;
    }

    try {
      setSending(true);
      await signalRService.sendMessage(eventId, trimmed);
      setMessageText('');
    } catch (err) {
      console.error('Send message error:', err);
      if (isParticipationError(err)) {
        Alert.alert(
          'Немає доступу',
          'Ви більше не є учасником цієї події',
          [{text: 'OK', onPress: () => navigation.goBack()}],
        );
      } else {
        setError('Не вдалося надіслати повідомлення');
      }
    } finally {
      setSending(false);
    }
  };

  const handleRetry = () => {
    setLoading(true);
    loadMessages();
  };

  const renderMessage = ({item}: {item: ChatMessageResponse}) => {
    const isOwn = item.userId === currentUser?.userId;
    const messageDate = new Date(item.sentAt);
    const timeStr = messageDate.toLocaleTimeString('uk-UA', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return (
      <View
        style={[
          styles.messageContainer,
          isOwn ? styles.ownMessageContainer : styles.otherMessageContainer,
        ]}>
        {!isOwn && (
          <Text style={styles.senderName}>{item.senderName}</Text>
        )}
        <View
          style={[
            styles.messageBubble,
            isOwn ? styles.ownMessageBubble : styles.otherMessageBubble,
          ]}>
          <Text
            style={[
              styles.messageText,
              isOwn ? styles.ownMessageText : styles.otherMessageText,
            ]}>
            {item.messageText}
          </Text>
          <Text
            style={[
              styles.messageTime,
              isOwn ? styles.ownMessageTime : styles.otherMessageTime,
            ]}>
            {timeStr}
          </Text>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={colors.primaryNavy} />
        <Text style={styles.loadingText}>Завантаження чату...</Text>
      </View>
    );
  }

  if (error && messages.length === 0) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryButton} onPress={handleRetry}>
          <Text style={styles.retryButtonText}>Спробувати ще раз</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}>
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={item => item.chatMessageId.toString()}
        renderItem={renderMessage}
        contentContainerStyle={styles.messagesList}
        onEndReached={loadMoreMessages}
        onEndReachedThreshold={0.5}
        ListHeaderComponent={
          loadingMore ? (
            <View style={styles.loadingMoreContainer}>
              <ActivityIndicator size="small" color={colors.primaryNavy} />
            </View>
          ) : undefined
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Поки що немає повідомлень</Text>
            <Text style={styles.emptySubtext}>
              Будьте першим, хто напише!
            </Text>
          </View>
        }
      />

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={messageText}
          onChangeText={setMessageText}
          placeholder="Введіть повідомлення..."
          placeholderTextColor={colors.textSecondary}
          multiline
          maxLength={MAX_MESSAGE_LENGTH}
          editable={!sending}
        />
        <TouchableOpacity
          style={[
            styles.sendButton,
            (!messageText.trim() || sending) && styles.sendButtonDisabled,
          ]}
          onPress={handleSend}
          disabled={!messageText.trim() || sending}>
          {sending ? (
            <ActivityIndicator size="small" color={colors.surface} />
          ) : (
            <Text style={styles.sendButtonText}>{'➤'}</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
    padding: spacing.lg,
  },
  loadingText: {
    marginTop: spacing.md,
    fontSize: 16,
    color: colors.textSecondary,
  },
  errorText: {
    fontSize: 16,
    color: colors.danger,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  retryButton: {
    backgroundColor: colors.primaryNavy,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: 8,
  },
  retryButtonText: {
    color: colors.surface,
    fontSize: 16,
    fontWeight: '600',
  },
  messagesList: {
    padding: spacing.md,
    flexGrow: 1,
  },
  loadingMoreContainer: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.xl * 2,
  },
  emptyText: {
    fontSize: 18,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  emptySubtext: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  messageContainer: {
    marginBottom: spacing.md,
    maxWidth: '80%',
  },
  ownMessageContainer: {
    alignSelf: 'flex-end',
  },
  otherMessageContainer: {
    alignSelf: 'flex-start',
  },
  senderName: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    marginLeft: spacing.sm,
  },
  messageBubble: {
    borderRadius: 16,
    padding: spacing.md,
  },
  ownMessageBubble: {
    backgroundColor: colors.primaryNavy,
  },
  otherMessageBubble: {
    backgroundColor: colors.surface,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
  },
  ownMessageText: {
    color: colors.surface,
  },
  otherMessageText: {
    color: colors.textPrimary,
  },
  messageTime: {
    fontSize: 12,
    marginTop: spacing.xs,
  },
  ownMessageTime: {
    color: 'rgba(255, 255, 255, 0.7)',
    textAlign: 'right',
  },
  otherMessageTime: {
    color: colors.textSecondary,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    alignItems: 'flex-end',
  },
  input: {
    flex: 1,
    backgroundColor: colors.background,
    borderRadius: 20,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginRight: spacing.sm,
    fontSize: 16,
    color: colors.textPrimary,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: colors.primaryNavy,
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: colors.textSecondary,
    opacity: 0.5,
  },
  sendButtonText: {
    color: colors.surface,
    fontSize: 20,
    fontWeight: 'bold',
  },
});
