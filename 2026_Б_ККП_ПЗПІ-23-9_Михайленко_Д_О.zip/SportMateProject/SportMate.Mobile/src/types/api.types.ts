export interface AuthResponse {
  accessToken: string;
  userId: number;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  avatarId?: number;
  rating: number;
}

export interface RegisterRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  avatarId?: number;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface UserProfileResponse {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  avatarId?: number;
  rating: number;
  role: string;
  createdAt: string;
  completedEventsCount: number;
  organizedEvents: EventListItemResponse[];
  participatingEvents: EventListItemResponse[];
}

export interface PublicUserProfileResponse {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId?: number;
  rating: number;
  organizedEvents: EventListItemResponse[];
  participatingEvents: EventListItemResponse[];
}

export interface UpdateProfileRequest {
  firstName?: string;
  lastName?: string;
  avatarId?: number;
  password?: string;
}

export enum EventStatus {
  Planned = 0,
  Active = 1,
  Completed = 2,
  Cancelled = 3,
}

export interface EventResponse {
  eventId: number;
  title: string;
  description?: string;
  address: string;
  latitude?: number;
  longitude?: number;
  eventDate: string;
  durationMinutes: number;
  maxParticipants: number;
  status: EventStatus;
  createdAt: string;
  organizer: OrganizerInfo;
  sportCategory: SportCategoryInfo;
  participantCount: number;
  freeSlots: number;
}

export interface EventListItemResponse {
  eventId: number;
  title: string;
  address: string;
  eventDate: string;
  durationMinutes: number;
  maxParticipants: number;
  status: EventStatus;
  sportCategory: SportCategoryInfo;
  participantCount: number;
  freeSlots: number;
}

export interface CreateEventRequest {
  title: string;
  description?: string;
  sportCategoryId: number;
  eventDate: string;
  durationMinutes: number;
  maxParticipants: number;
  address: string;
  latitude?: number;
  longitude?: number;
}

export interface UpdateEventRequest {
  title: string;
  description?: string;
  sportCategoryId: number;
  eventDate: string;
  durationMinutes: number;
  maxParticipants: number;
  address: string;
  latitude?: number;
  longitude?: number;
}

export interface OrganizerInfo {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId?: number;
  rating: number;
}

export interface SportCategoryInfo {
  sportCategoryId: number;
  name: string;
  imagePath?: string;
}

export interface SportCategoryResponse {
  sportCategoryId: number;
  name: string;
  imagePath?: string;
}

export interface ChatMessageResponse {
  chatMessageId: number;
  eventId: number;
  userId: number;
  senderName: string;
  avatarId?: number;
  messageText: string;
  sentAt: string;
}

export interface SendMessageRequest {
  messageText: string;
}

export interface ChatHistoryResponse {
  items: ChatMessageResponse[];
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export interface RatingUserInfo {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId?: number;
  rating: number;
}

export interface RatingResponse {
  ratingId: number;
  eventId: number;
  author: RatingUserInfo;
  targetUser: RatingUserInfo;
  score: number;
  comment?: string;
  createdAt: string;
}

export interface CreateRatingRequest {
  eventId: number;
  targetUserId: number;
  score: number;
  comment?: string;
}

export interface JoinEventResponse {
  message: string;
  eventId: number;
  participantCount: number;
}

export interface EventParticipantResponse {
  userId: number;
  firstName: string;
  lastName: string;
  avatarId?: number;
  rating: number;
  joinedAt: string;
}
