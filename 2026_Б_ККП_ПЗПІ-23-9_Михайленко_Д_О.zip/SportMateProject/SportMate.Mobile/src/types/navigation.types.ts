import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {BottomTabScreenProps} from '@react-navigation/bottom-tabs';
import {NavigatorScreenParams} from '@react-navigation/native';

export type AuthStackParamList = {
  Login: undefined;
  Register: undefined;
};

export type AuthStackScreenProps<T extends keyof AuthStackParamList> =
  NativeStackScreenProps<AuthStackParamList, T>;

export type MainTabParamList = {
  Events: undefined;
  Profile: NavigatorScreenParams<ProfileStackParamList> | undefined;
};

export type MainTabScreenProps<T extends keyof MainTabParamList> =
  BottomTabScreenProps<MainTabParamList, T>;

export type EventsStackParamList = {
  EventList: undefined;
  EventDetails: {eventId: number};
  CreateEvent: undefined;
  EditEvent: {eventId: number};
  EventChat: {eventId: number};
  EventRatings: {eventId: number};
  CreateRating: {eventId: number; targetUserId: number};
  PublicProfile: {userId: number};
  UserRatings: {userId: number};
};

export type EventsStackScreenProps<T extends keyof EventsStackParamList> =
  NativeStackScreenProps<EventsStackParamList, T>;

export type ProfileStackParamList = {
  MyProfile: undefined;
  EditProfile: undefined;
  MyRatings: undefined;
  PublicProfile: {userId: number};
  UserRatings: {userId: number};
};

export type ProfileStackScreenProps<T extends keyof ProfileStackParamList> =
  NativeStackScreenProps<ProfileStackParamList, T>;

export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
};

export type RootStackScreenProps<T extends keyof RootStackParamList> =
  NativeStackScreenProps<RootStackParamList, T>;
