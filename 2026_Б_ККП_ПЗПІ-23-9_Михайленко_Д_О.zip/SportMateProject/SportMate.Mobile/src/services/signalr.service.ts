import * as signalR from '@microsoft/signalr';
import {AuthService} from './auth.service';
import {ChatMessageResponse} from '../types/api.types';
import {config} from '../utils/config';

class SignalRService {
  private connection: signalR.HubConnection | null = null;
  private currentEventId: number | null = null;

  async connect(): Promise<void> {
    if (this.connection?.state === signalR.HubConnectionState.Connected) {
      console.log('SignalR: Already connected');
      return;
    }

    const token = await AuthService.getToken();
    if (!token) {
      throw new Error('SignalR: No auth token available');
    }

    this.connection = new signalR.HubConnectionBuilder()
      .withUrl(config.signalRHubUrl, {
        accessTokenFactory: () => token,
        transport: signalR.HttpTransportType.WebSockets,
      })
      .withAutomaticReconnect()
      .configureLogging(signalR.LogLevel.Information)
      .build();

    this.connection.onreconnecting((error?: Error) => {
      console.log('SignalR: Reconnecting...', error);
    });

    this.connection.onreconnected((connectionId?: string) => {
      console.log('SignalR: Reconnected', connectionId);
      if (this.currentEventId) {
        this.joinEventChat(this.currentEventId);
      }
    });

    this.connection.onclose((error?: Error) => {
      console.log('SignalR: Connection closed', error);
    });

    await this.connection.start();
    console.log('SignalR: Connected');
  }

  async joinEventChat(eventId: number): Promise<void> {
    if (!this.connection) {
      throw new Error('SignalR: Not connected');
    }

    await this.connection.invoke('JoinEventChat', eventId);
    this.currentEventId = eventId;
    console.log(`SignalR: Joined event ${eventId} chat`);
  }

  async leaveEventChat(eventId: number): Promise<void> {
    if (!this.connection) {
      throw new Error('SignalR: Not connected');
    }

    await this.connection.invoke('LeaveEventChat', eventId);
    this.currentEventId = null;
    console.log(`SignalR: Left event ${eventId} chat`);
  }

  async sendMessage(eventId: number, messageText: string): Promise<void> {
    if (!this.connection) {
      throw new Error('SignalR: Not connected');
    }

    if (this.connection.state !== signalR.HubConnectionState.Connected) {
      throw new Error(
        `SignalR: Cannot send message. Connection state: ${signalR.HubConnectionState[this.connection.state]}`,
      );
    }

    await this.connection.invoke('SendMessage', eventId, {messageText});
  }

  onReceiveMessage(callback: (message: ChatMessageResponse) => void): void {
    if (!this.connection) {
      throw new Error('SignalR: Not connected');
    }

    this.connection.on('ReceiveMessage', callback);
  }

  offReceiveMessage(): void {
    if (this.connection) {
      this.connection.off('ReceiveMessage');
    }
  }

  async disconnect(): Promise<void> {
    if (this.connection) {
      await this.connection.stop();
      this.connection = null;
      this.currentEventId = null;
      console.log('SignalR: Disconnected');
    }
  }

  getState(): signalR.HubConnectionState | null {
    return this.connection?.state || null;
  }
}

export default new SignalRService();
