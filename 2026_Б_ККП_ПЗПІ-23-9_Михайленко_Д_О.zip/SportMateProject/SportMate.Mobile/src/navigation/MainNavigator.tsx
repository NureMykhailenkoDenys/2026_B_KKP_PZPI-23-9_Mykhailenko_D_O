import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {EventsNavigator} from './EventsNavigator';
import {ProfileNavigator} from './ProfileNavigator';
import {MainTabParamList} from '../types/navigation.types';
import {colors} from '../theme/colors';
import {Text} from 'react-native';

const Tab = createBottomTabNavigator<MainTabParamList>();

export const MainNavigator: React.FC = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.accentLime,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
        },
      }}>
      <Tab.Screen
        name="Events"
        component={EventsNavigator}
        options={{
          tabBarLabel: 'Події',
          tabBarIcon: () => <Text style={{fontSize: 24}}>🏃</Text>,
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileNavigator}
        options={{
          tabBarLabel: 'Профіль',
          tabBarIcon: () => <Text style={{fontSize: 24}}>👤</Text>,
        }}
      />
    </Tab.Navigator>
  );
};
