import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {EventListScreen} from '../screens/events/EventListScreen';
import {EventDetailsScreen} from '../screens/events/EventDetailsScreen';
import {CreateEventScreen} from '../screens/events/CreateEventScreen';
import {EditEventScreen} from '../screens/events/EditEventScreen';
import {EventChatScreen} from '../screens/events/EventChatScreen';
import {EventRatingsScreen} from '../screens/ratings/EventRatingsScreen';
import {CreateRatingScreen} from '../screens/ratings/CreateRatingScreen';
import {UserRatingsRouteScreen} from '../screens/ratings/UserRatingsScreen';
import {PublicProfileScreen} from '../screens/profile/PublicProfileScreen';
import {EventsStackParamList} from '../types/navigation.types';
import {colors} from '../theme/colors';

const Stack = createNativeStackNavigator<EventsStackParamList>();

export const EventsNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: true,
        headerStyle: {
          backgroundColor: colors.surface,
        },
        headerTintColor: colors.textPrimary,
        headerTitleStyle: {
          fontWeight: '600',
        },
      }}>
      <Stack.Screen
        name="EventList"
        component={EventListScreen}
        options={{title: 'Події'}}
      />
      <Stack.Screen
        name="EventDetails"
        component={EventDetailsScreen}
        options={{title: 'Деталі події'}}
      />
      <Stack.Screen
        name="CreateEvent"
        component={CreateEventScreen}
        options={{title: 'Створити подію'}}
      />
      <Stack.Screen
        name="EditEvent"
        component={EditEventScreen}
        options={{title: 'Редагувати подію'}}
      />
      <Stack.Screen
        name="EventChat"
        component={EventChatScreen}
        options={{title: 'Чат події'}}
      />
      <Stack.Screen
        name="EventRatings"
        component={EventRatingsScreen}
        options={{title: 'Рейтинги події'}}
      />
      <Stack.Screen
        name="CreateRating"
        component={CreateRatingScreen}
        options={{title: 'Оцінити учасника'}}
      />
      <Stack.Screen
        name="PublicProfile"
        component={PublicProfileScreen}
        options={{title: 'Профіль користувача'}}
      />
      <Stack.Screen
        name="UserRatings"
        component={UserRatingsRouteScreen}
        options={{title: 'Відгуки'}}
      />
    </Stack.Navigator>
  );
};
