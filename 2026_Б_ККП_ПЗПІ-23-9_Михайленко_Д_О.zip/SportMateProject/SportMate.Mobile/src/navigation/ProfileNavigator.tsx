import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {ProfileStackParamList} from '../types/navigation.types';
import {MyProfileScreen} from '../screens/profile/MyProfileScreen';
import {EditProfileScreen} from '../screens/profile/EditProfileScreen';
import {MyRatingsScreen} from '../screens/profile/MyRatingsScreen';
import {PublicProfileScreen} from '../screens/profile/PublicProfileScreen';
import {UserRatingsRouteScreen} from '../screens/ratings/UserRatingsScreen';
import {colors} from '../theme/colors';

const Stack = createNativeStackNavigator<ProfileStackParamList>();

export const ProfileNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.surface,
        },
        headerTintColor: colors.textPrimary,
        headerTitleStyle: {
          fontWeight: '600',
        },
      }}>
      <Stack.Screen
        name="MyProfile"
        component={MyProfileScreen}
        options={{title: 'Мій профіль'}}
      />
      <Stack.Screen
        name="EditProfile"
        component={EditProfileScreen}
        options={{title: 'Редагувати профіль'}}
      />
      <Stack.Screen
        name="MyRatings"
        component={MyRatingsScreen}
        options={{title: 'Мої рейтинги'}}
      />
      <Stack.Screen
        name="PublicProfile"
        component={PublicProfileScreen}
        options={{title: 'Профіль користувача'}}
      />
      <Stack.Screen
        name="UserRatings"
        component={UserRatingsRouteScreen}
        options={{title: 'Відгуки'}}
      />
    </Stack.Navigator>
  );
};
